import React, {useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import {getElectionResults} from "../../services/electionService";
import {Layout} from "../../components/layout/Layout";
import {ResultsContent} from "../../components/common/ResultsContent";

export function Results() {
  const {electionId}=useParams();
  const [data,setData]=useState(null);
  const [error,setError]=useState("");
  useEffect(()=>{
    getElectionResults(electionId)
      .then(setData)
      .catch(e=>setError(e.message));
  },[electionId]);

  return <Layout>
    <main className="dashboard">
      <div className="result-title">
        <h1>Election Results</h1>
        <p>Official results calculated from recorded votes.</p>
      </div>
      {error && <div className="error">{error}</div>}
      {data && <ResultsContent data={data}/>}
    </main>
  </Layout>;
}
