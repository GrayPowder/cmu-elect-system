import React, {useEffect, useState} from "react";
import {Link} from "react-router-dom";
import {listElections} from "../../services/electionService";
import {Layout} from "../../components/layout/Layout";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import studentIcon from "../../assets/Student Male@2x.png";
import teacherIcon from "../../assets/Teacher.png";
import dashboardBg from "../../assets/grey cover.png";

export function Dashboard() {
  const [elections, setElections] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const {user} = useAuth();

  useEffect(() => {
    setLoading(true);
    listElections()
      .then(setElections)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  function statusLabel(status) {
    if (status === "not_started") return "NOT STARTED";
    if (status === "ended") return "ENDED";
    return "ACTIVE";
  }

  return (
    <Layout>
      <div className="dashboard-background" style={{backgroundImage: `url("${dashboardBg}")`}}>
        <main className="dashboard">
          <div className="hero">
            <div>
              <h1>VOTER DASHBOARD</h1>
              <p>Welcome, {user.username || "Voter"}. View elections you are eligible to participate in.</p>
            </div>
            <img src={user.role === "faculty" || user.role === "alumni" ? teacherIcon : studentIcon} />
          </div>

          {error && <div className="error">{error}</div>}
          {loading && <div className="loading-state"><span className="spinner" /> Loading elections...</div>}

          {!loading && !error && elections.length === 0 && (
            <div className="message">No elections are currently available for your voter category.</div>
          )}

          {!loading && !error && elections.length > 0 && (
            <div className="section-heading voter-elections-heading">
              <div>
                <span className="eyebrow">ELECTIONS</span>
                <h2>Available Elections</h2>
                <p>Choose an election to review its details and voting options.</p>
              </div>
            </div>
          )}

          <div className="election-list">
            {elections.map(election => (
              <section className="election-card" key={election.id}>
                <div className="election-heading">
                  <div>
                    <h2>{election.name}</h2>
                    <span className={election.status === "active" && election.is_open ? "open" : "closed"}>
                      {statusLabel(election.status)}
                    </span>
                  </div>
                  {election.status === "ended" && (
                    <Link className="results-link" to={`/results/${election.id}`}>Results</Link>
                  )}
                </div>

                {election.description && <p>{election.description}</p>}

                <div className="election-meta">
                  <span><strong>Voting period:</strong> {new Date(election.start_datetime).toLocaleString()} — {new Date(election.end_datetime).toLocaleString()}</span>
                  <span><strong>Availability:</strong> {
                    election.voting_availability === "available"
                      ? "Voting Available"
                      : election.voting_availability === "not_started"
                        ? "Voting Not Yet Available"
                        : "Voting Ended"
                  }</span>
                </div>

                <div className="modal-actions election-card-actions">
                  <Link className="primary election-details-button" to={`/elections/${election.id}`}>View Election Details</Link>
                  <Link className="secondary" to={`/analytics/${election.id}`}>Live Analytics</Link>
                </div>
              </section>
            ))}
          </div>
        </main>
      </div>
    </Layout>
  );
}
