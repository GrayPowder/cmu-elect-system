import React, {useEffect, useState} from "react";
import {Link, useParams} from "react-router-dom";
import {getElection} from "../../services/electionService";
import {Layout} from "../../components/layout/Layout";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";

export function ElectionDetails() {
  const { electionId } = useParams();
  const [election, setElection] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getElection(electionId)
      .then(setElection)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [electionId]);

  if (loading) return <Layout><main className="dashboard"><div className="loading-state"><span className="spinner" /> Loading election...</div></main></Layout>;

  return (
    <Layout>
      <main className="dashboard">
        <div className="result-title">
          <h1>{election?.name || "Election Details"}</h1>
          <p>Review the election information, positions, and candidates.</p>
        </div>

        {error && <div className="error">{error}</div>}

        {election && (
          <>
            <section className="election-card">
              <h2>{election.name}</h2>
              <p>{election.description || "No description provided."}</p>
              <div className="election-meta">
                <span><strong>Status:</strong> {election.status === "not_started" ? "Not Started" : election.status === "ended" ? "Ended" : "Active"}</span>
                <span><strong>Voting period:</strong> {new Date(election.start_datetime).toLocaleString()} — {new Date(election.end_datetime).toLocaleString()}</span>
                <span><strong>Availability:</strong> {
                  election.voting_availability === "available"
                    ? "Voting Available"
                    : election.voting_availability === "not_started"
                      ? "Voting Not Yet Available"
                      : "Voting Ended"
                }</span>
              </div>
            </section>

            <div className="position-grid">
              {election.positions.map(position => (
                <section className="position election-detail-position" key={position.id}>
                  <div>
                    <h2>{position.name}</h2>
                    {position.candidates.length === 0
                      ? <p>No candidates are available.</p>
                      : <ul>
                          {position.candidates.map(candidate => (
                            <li key={candidate.id}><strong>{candidate.name}</strong>{candidate.party_list ? ` · ${candidate.party_list}` : ""}</li>
                          ))}
                        </ul>}
                  </div>
                </section>
              ))}
            </div>

            <div className="modal-actions">
              <Link className="secondary" to="/dashboard">Back to Dashboard</Link>
              {election.is_open && election.positions.some(position => position.candidates.length > 0) && (
                <Link className="primary proceed-ballot-button" to={`/vote/${election.id}`}>Proceed to Ballot</Link>
              )}
            </div>
          </>
        )}
      </main>
    </Layout>
  );
}
