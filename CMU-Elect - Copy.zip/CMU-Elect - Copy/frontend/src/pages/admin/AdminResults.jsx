import React, {useEffect, useState} from "react";
import {NavLink} from "react-router-dom";
import {listAdminElections} from "../../services/adminService";
import {getElectionResults} from "../../services/electionService";
import {useAuth} from "../../context/AuthContext";
import {ResultsContent} from "../../components/common/ResultsContent";
import logo from "../../assets/cmu-elect-logo.png";

export function AdminResults() {
  const {user, logout} = useAuth();
  const [elections,setElections]=useState([]);
  const [selectedId,setSelectedId]=useState("");
  const [data,setData]=useState(null);
  const [error,setError]=useState("");
  const [loading,setLoading]=useState(false);

  useEffect(()=>{
    listAdminElections()
      .then(items=>{
        setElections(items);
        if (items.length) setSelectedId(String(items[0].id));
      })
      .catch(e=>setError(e.message));
  },[]);

  useEffect(()=>{
    if (!selectedId) return;
    setLoading(true);
    setError("");
    getElectionResults(selectedId)
      .then(setData)
      .catch(e=>{setData(null);setError(e.message);})
      .finally(()=>setLoading(false));
  },[selectedId]);

  async function handleLogout() {
    await logout();
    window.location.href = "/login";
  }

  return <div>
    <header className="topbar">
      <div className="topbar-brand">
        <img src={logo} alt="CMU-ELECT Logo" />
        <span>CMU-ELECT ADMIN</span>
      </div>
      <nav className="admin-nav">
        <NavLink
          to="/admin"
          end
          className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}
        >
          Dashboard
        </NavLink>

        <NavLink
          to="/admin/users"
          className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}
        >
          Users
        </NavLink>

        <NavLink
          to="/admin/elections"
          className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}
        >
          Elections
        </NavLink>

        <NavLink
          to="/admin/results"
          className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}
        >
          Results
        </NavLink>

        <NavLink
          to="/admin/analytics"
          className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}
        >
          Analytics
        </NavLink>

        <NavLink
          to="/admin/audit-logs"
          className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}
        >
          Audit Logs
        </NavLink>
        <span className="user-chip">{user?.email}</span>
        <button onClick={handleLogout}>Logout</button>
      </nav>
    </header>
    <main className="dashboard">
      <div className="result-title">
        <h1>Election Results</h1>
        <p>Accurate results calculated from actual vote records.</p>
      </div>
      <section className="result-selector">
        <label htmlFor="result-election">Select election</label>
        <select id="result-election" className="standalone-input" value={selectedId} onChange={e=>setSelectedId(e.target.value)}>
          {elections.map(e=><option key={e.id} value={e.id}>{e.name} — {e.status}</option>)}
        </select>
      </section>
      {loading && <div className="loading-state"><span className="spinner" /> Loading results...</div>}
      {error && <div className="error">{error}</div>}
      {data && <ResultsContent data={data}/>}
      {!loading && !error && !data && elections.length === 0 && <div className="message">No elections are available yet.</div>}
    </main>
  </div>;
}
