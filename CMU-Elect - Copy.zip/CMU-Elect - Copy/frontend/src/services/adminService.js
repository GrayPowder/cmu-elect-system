import {api} from "./api";

export function getAdminDashboard() {
  return api("/admin/dashboard/");
}

export function listAdminElections() {
  return api("/admin/elections/");
}

export function createElection(payload) {
  return api("/admin/elections/", {method: "POST", body: JSON.stringify(payload)});
}

export function updateElection(electionId, payload) {
  return api(`/admin/elections/${electionId}/`, {method: "PATCH", body: JSON.stringify(payload)});
}

export function getAdminElection(electionId) {
  return api(`/admin/elections/${electionId}/`);
}

export function deleteElection(electionId) {
  return api(`/admin/elections/${electionId}/`, {method: "DELETE"});
}

export function listPositions(electionId) {
  return api(`/admin/elections/${electionId}/positions/`);
}

export function createPosition(electionId, payload) {
  return api(`/admin/elections/${electionId}/positions/`, {method: "POST", body: JSON.stringify(payload)});
}

export function updatePosition(positionId, payload) {
  return api(`/admin/positions/${positionId}/`, {method: "PATCH", body: JSON.stringify(payload)});
}

export function deletePosition(positionId) {
  return api(`/admin/positions/${positionId}/`, {method: "DELETE"});
}

export function listCandidates(electionId, positionId) {
  return api(`/admin/elections/${electionId}/positions/${positionId}/candidates/`);
}

export function createCandidate(electionId, positionId, payload) {
  return api(`/admin/elections/${electionId}/positions/${positionId}/candidates/`, {method: "POST", body: payload});
}

export function updateCandidate(candidateId, payload) {
  return api(`/admin/candidates/${candidateId}/`, {method: "PATCH", body: payload});
}

export function deleteCandidate(candidateId) {
  return api(`/admin/candidates/${candidateId}/`, {method: "DELETE"});
}

export function listVoters(query = "") {
  return api(`/admin/voters/${query ? `?${query}` : ""}`);
}

export function createVoter(payload) {
  return api("/admin/voters/", {method: "POST", body: JSON.stringify(payload)});
}

export function updateVoter(voterId, payload) {
  return api(`/admin/voters/${voterId}/`, {method: "PATCH", body: JSON.stringify(payload)});
}

export function resetVoterPassword(voterId, payload) {
  return api(`/admin/voters/${voterId}/reset-password/`, {method: "POST", body: JSON.stringify(payload)});
}

export function getAuditLogs(query) {
  return api(`/admin/audit-logs/?${query}`);
}
