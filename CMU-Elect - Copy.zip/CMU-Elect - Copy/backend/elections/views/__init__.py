"""Compatibility facade for the elections view package.

The public view names remain available from ``elections.views`` so existing
URL imports and test patches continue to work while implementation details are
organized by domain.
"""

from .health import HealthCheckView
from ..models import Vote
from .common import (
    hash_value, create_audit_log, create_reset_code, send_reset_code, build_login_response,
)
from .auth import (
    LoginView, AdminLoginView, LogoutView, MeView,
    ChangePasswordView, ForgotPasswordView, VerifyResetCodeView, ResendResetCodeView,
    ResetPasswordView,
)
from .admin import (
    AdminDashboardView, AdminVoterListCreateView, AdminVoterDetailView,
    AdminVoterPasswordResetView, AdminElectionListCreateView, AdminElectionDetailView,
)
from .positions import AdminPositionListCreateView, AdminPositionDetailView
from .candidates import AdminCandidateListCreateView, AdminCandidateDetailView
from .audit import AdminAuditLogListView
from .elections import ElectionListView, ElectionDetailView
from .voting import VoteView
from .analytics import build_analytics_data, AnalyticsView, VoterAnalyticsView
from .results import ResultsView

__all__ = [
    "HealthCheckView",
    "hash_value", "create_audit_log", "create_reset_code", "send_reset_code", "build_login_response",
    "LoginView", "AdminLoginView", "LogoutView", "MeView", "Vote",
    "ChangePasswordView", "ForgotPasswordView", "VerifyResetCodeView", "ResendResetCodeView",
    "ResetPasswordView",
    "AdminDashboardView", "AdminVoterListCreateView", "AdminVoterDetailView", "AdminVoterPasswordResetView",
    "AdminElectionListCreateView", "AdminElectionDetailView", "AdminPositionListCreateView",
    "AdminPositionDetailView", "AdminCandidateListCreateView", "AdminCandidateDetailView",
    "AdminAuditLogListView",
    "ElectionListView", "ElectionDetailView", "VoteView",
    "build_analytics_data", "AnalyticsView", "VoterAnalyticsView", "ResultsView",
]
