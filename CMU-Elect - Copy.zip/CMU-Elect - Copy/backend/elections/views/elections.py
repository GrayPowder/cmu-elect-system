from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import Election
from ..permissions import IsAuthenticatedAndPasswordChanged
from ..serializers import ElectionSerializer


# Voter-facing election views.

class ElectionListView(APIView):
    permission_classes = [IsAuthenticatedAndPasswordChanged]

    def get(self, request):
        profile = getattr(request.user, "profile", None)
        if not profile or profile.account_status != "active" or not request.user.is_active:
            return Response(
                {"detail": "This account is inactive. Please contact the administrator."},
                status=status.HTTP_403_FORBIDDEN,
            )

        elections = (
            Election.objects
            .filter(eligible_voter_category=profile.role)
            .prefetch_related("positions__candidates")
            .order_by("start_datetime", "id")
        )
        return Response(ElectionSerializer(elections, many=True).data)


class ElectionDetailView(APIView):
    """Return one election only when it is eligible for the authenticated voter."""

    permission_classes = [IsAuthenticatedAndPasswordChanged]

    def get(self, request, election_id):
        profile = getattr(request.user, "profile", None)
        if not profile or profile.account_status != "active" or not request.user.is_active:
            return Response(
                {"detail": "This account is inactive. Please contact the administrator."},
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            election = (
                Election.objects
                .prefetch_related("positions__candidates")
                .get(pk=election_id, eligible_voter_category=profile.role)
            )
        except Election.DoesNotExist:
            return Response(
                {"detail": "Election not found or you are not eligible to access it."},
                status=status.HTTP_404_NOT_FOUND,
            )

        return Response(ElectionSerializer(election).data)
