from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import Election
from ..permissions import IsAdministrator
from ..services.analytics_service import build_analytics_data


# Aggregate analytics views. Calculation logic lives in the service layer.

class AnalyticsView(APIView):
    """Return live database-backed analytics for an administrator."""
    permission_classes = [IsAdministrator]

    def get(self, request, election_id):
        try:
            election = Election.objects.get(pk=election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(build_analytics_data(election))


class VoterAnalyticsView(APIView):
    """Return aggregate live analytics to an eligible authenticated voter."""
    permission_classes = [IsAuthenticated]

    def get(self, request, election_id):
        try:
            election = Election.objects.get(pk=election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        profile = getattr(request.user, "profile", None)
        if (
            not request.user.is_active
            or not profile
            or profile.account_status != "active"
        ):
            return Response({"detail": "Active voter access is required."}, status=status.HTTP_403_FORBIDDEN)
        if profile.must_change_password:
            return Response({"detail": "You must change your password before viewing analytics."}, status=status.HTTP_403_FORBIDDEN)
        if profile.role != election.eligible_voter_category:
            return Response({"detail": "You are not eligible to view this election's analytics."}, status=status.HTTP_403_FORBIDDEN)

        return Response(build_analytics_data(election))
