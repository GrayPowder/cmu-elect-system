from rest_framework import serializers

from ..models import Election, Position, VOTER_CATEGORY_CHOICES
from .candidates import CandidateSerializer


class PositionSerializer(serializers.ModelSerializer):
    candidates = CandidateSerializer(many=True, read_only=True)

    class Meta:
        model = Position
        fields = ["id", "name", "order", "candidates"]


class AdminPositionSerializer(serializers.ModelSerializer):
    election_id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=80, required=True, allow_blank=False, trim_whitespace=True)

    class Meta:
        model = Position
        fields = ["id", "election_id", "name", "order"]
        read_only_fields = ["id", "election_id"]

    def validate_name(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Position name cannot be empty or contain only spaces.")
        return value

    def validate_order(self, value):
        if value < 0:
            raise serializers.ValidationError("Position order cannot be negative.")
        return value

    def validate(self, attrs):
        election = self.context.get("election")
        name = attrs.get("name", getattr(self.instance, "name", "")).strip()
        if not name:
            raise serializers.ValidationError({"name": "Position name cannot be empty or contain only spaces."})
        if election and Position.objects.filter(
            election=election, name__iexact=name
        ).exclude(pk=getattr(self.instance, "pk", None)).exists():
            raise serializers.ValidationError({"name": "A position with this name already exists in this election."})
        return attrs


class ElectionSerializer(serializers.ModelSerializer):
    """Voter-facing election representation used by the dashboard and details page."""
    audience = serializers.CharField(source="eligible_voter_category", read_only=True)
    is_open = serializers.BooleanField(read_only=True)
    status = serializers.CharField(source="schedule_status", read_only=True)
    voting_availability = serializers.SerializerMethodField()
    positions = PositionSerializer(many=True, read_only=True)

    class Meta:
        model = Election
        fields = [
            "id", "name", "description", "audience", "start_datetime", "end_datetime",
            "status", "is_open", "voting_availability", "positions",
        ]

    def get_voting_availability(self, obj):
        if obj.schedule_status == "not_started":
            return "not_started"
        if obj.schedule_status == Election.STATUS_ENDED:
            return "ended"
        if obj.is_open:
            return "available"
        return "unavailable"


class AdminElectionSerializer(serializers.ModelSerializer):
    name = serializers.CharField(max_length=120, required=True, allow_blank=False, trim_whitespace=True)
    eligible_voter_category = serializers.ChoiceField(choices=VOTER_CATEGORY_CHOICES)
    status = serializers.SerializerMethodField()
    is_open = serializers.BooleanField(read_only=True)
    created_date = serializers.DateTimeField(source="created_at", read_only=True)

    class Meta:
        model = Election
        fields = [
            "id", "name", "description", "start_datetime", "end_datetime",
            "eligible_voter_category", "status", "is_open", "created_date",
        ]
        read_only_fields = ["id", "status", "is_open", "created_date"]

    def validate_name(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Election name cannot be empty or contain only spaces.")
        return value

    def validate(self, attrs):
        start = attrs.get("start_datetime", getattr(self.instance, "start_datetime", None))
        end = attrs.get("end_datetime", getattr(self.instance, "end_datetime", None))
        if start and end and start >= end:
            raise serializers.ValidationError({"end_datetime": "Election end date/time must be after the start date/time."})
        return attrs

    def get_status(self, obj):
        return obj.effective_status
