"""Business operations for authentication and password workflows."""

import secrets
from datetime import timedelta

from django.contrib.auth.models import User
from django.db import transaction
from django.utils import timezone
from rest_framework.authtoken.models import Token

from ..models import PasswordResetRequest, Profile
from .audit_service import create_audit_log
from .common import hash_value, create_reset_code


def create_login_session(*, user):
    # Rotate the DRF token on every successful login so a previously issued
    # token cannot remain valid after a new authentication event.
    Token.objects.filter(user=user).delete()
    token = Token.objects.create(user=user)
    is_admin = bool(user.is_staff and user.is_active)
    create_audit_log(
        actor=user,
        action="admin_login" if is_admin else "voter_login",
        target_model="User",
        target_object_id=user.id,
        description=(
            "Administrator successfully logged in."
            if is_admin else "Voter successfully logged in."
        ),
    )
    return token


def create_admin_login_session(*, user):
    Token.objects.filter(user=user).delete()
    token = Token.objects.create(user=user)
    create_audit_log(
        actor=user,
        action="admin_login",
        target_model="User",
        target_object_id=user.id,
        description="Administrator successfully logged in.",
    )
    return token


def logout_user(*, user):
    is_admin = bool(user.is_staff)
    create_audit_log(
        actor=user,
        action="admin_logout" if is_admin else "voter_logout",
        target_model="User",
        target_object_id=user.id,
        description="Administrator logged out." if is_admin else "Voter logged out.",
    )
    Token.objects.filter(user=user).delete()


def get_current_user_data(*, user):
    if not user.is_active:
        return None, ("This account is inactive. Please contact the administrator.", 403)

    if user.is_staff:
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "is_admin": True,
            "role": None,
            "must_change_password": False,
        }, None

    profile = getattr(user, "profile", None)
    if profile is None or profile.account_status != "active":
        return None, ("This account is inactive. Please contact the administrator.", 403)

    return {
        "id": user.id,
        "username": user.username,
        "role": profile.role,
        "email": profile.cmu_email,
        "is_admin": False,
        "must_change_password": profile.must_change_password,
    }, None


def change_password(*, user, new_password):
    profile = user.profile
    user.set_password(new_password)
    user.save(update_fields=["password"])
    profile.must_change_password = False
    profile.save(update_fields=["must_change_password", "updated_at"])
    create_audit_log(
        actor=user,
        action="password_changed",
        target_model="User",
        target_object_id=user.id,
        description="User changed their password.",
    )
    Token.objects.filter(user=user).delete()
    return Token.objects.create(user=user)


def request_password_reset(*, email, send_code):
    response = {"detail": "If that CMU email exists, a verification code has been sent."}
    try:
        profile = Profile.objects.select_related("user").get(cmu_email__iexact=email)
    except Profile.DoesNotExist:
        return response

    if profile.account_status != "active" or not profile.user.is_active:
        return response

    PasswordResetRequest.objects.filter(
        email__iexact=email,
        used_at__isnull=True,
    ).update(used_at=timezone.now())

    code = create_reset_code()
    PasswordResetRequest.objects.create(
        email=profile.cmu_email,
        code_hash=hash_value(code),
        expires_at=timezone.now() + timedelta(minutes=10),
    )
    send_code(profile.cmu_email, code)
    return response


def verify_reset_code(*, email, code):
    reset = PasswordResetRequest.objects.filter(
        email__iexact=email,
        used_at__isnull=True,
        verified_at__isnull=True,
    ).order_by("-created_at").first()
    if not reset or reset.expires_at < timezone.now():
        return None, ("That code has expired. Please request a new one.", 400)
    if reset.attempts >= 5:
        return None, ("Too many attempts. Please request a new code.", 400)

    if not secrets.compare_digest(hash_value(code), reset.code_hash):
        reset.attempts += 1
        reset.save(update_fields=["attempts"])
        return None, ("Invalid verification code.", 400)

    token = secrets.token_urlsafe(32)
    reset.verified_at = timezone.now()
    reset.reset_token_hash = hash_value(token)
    reset.save(update_fields=["verified_at", "reset_token_hash"])
    return token, None


@transaction.atomic
def reset_password(*, email, reset_token, password):
    reset = PasswordResetRequest.objects.select_for_update().filter(
        email__iexact=email,
        verified_at__isnull=False,
        used_at__isnull=True,
    ).order_by("-created_at").first()
    if not reset or reset.expires_at < timezone.now():
        return ("Your reset session has expired. Please start again.", 400)
    if not secrets.compare_digest(hash_value(reset_token), reset.reset_token_hash):
        return ("Invalid reset session.", 400)

    try:
        profile = Profile.objects.select_related("user").get(cmu_email__iexact=email)
    except Profile.DoesNotExist:
        return ("Account not found.", 400)

    if profile.account_status != "active" or not profile.user.is_active:
        return ("Password reset is unavailable for this account.", 400)

    user = profile.user
    user.set_password(password)
    user.save(update_fields=["password"])
    Token.objects.filter(user=user).delete()
    reset.used_at = timezone.now()
    reset.save(update_fields=["used_at"])
    create_audit_log(
        actor=None,
        action="password_reset",
        target_model="User",
        target_object_id=user.id,
        description="Password reset was completed through the password recovery flow.",
    )
    return None


@transaction.atomic
def create_voter(*, validated_data, actor):
    password = validated_data["password"]
    identifier = validated_data["identifier"]
    email = validated_data["email"]
    status_value = validated_data["status"]

    user = User.objects.create_user(
        username=identifier,
        email=email,
        password=password,
        is_active=status_value == "active",
    )
    voter = Profile.objects.create(
        user=user,
        full_name=validated_data["name"],
        cmu_email=email,
        role=validated_data["category"],
        account_status=status_value,
        must_change_password=True,
    )
    create_audit_log(
        actor=actor,
        action="account_created",
        target_model="Profile",
        target_object_id=voter.id,
        description="Voter account was created.",
    )
    return voter


@transaction.atomic
def reset_voter_password(*, voter, password, actor):
    user = voter.user
    user.set_password(password)
    user.save(update_fields=["password"])
    voter.must_change_password = True
    voter.save(update_fields=["must_change_password", "updated_at"])
    Token.objects.filter(user=user).delete()
    create_audit_log(
        actor=actor,
        action="password_reset",
        target_model="Profile",
        target_object_id=voter.id,
        description="Administrator reset a voter account password.",
    )
