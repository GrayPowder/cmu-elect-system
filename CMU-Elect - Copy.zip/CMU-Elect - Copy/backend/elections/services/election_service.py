"""Business operations for elections and election-owned positions."""

from django.db import transaction

from ..models import Election, Position
from .audit_service import create_audit_log


@transaction.atomic
def create_election(*, validated_data, actor):
    election = Election.objects.create(
        **validated_data,
        status=Election.STATUS_ACTIVE,
    )
    create_audit_log(
        actor=actor,
        action="election_created",
        target_model="Election",
        target_object_id=election.id,
        description="Election was created.",
    )
    return election


@transaction.atomic
def update_election(*, election, validated_data, actor):
    for field, value in validated_data.items():
        setattr(election, field, value)
    election.save()
    create_audit_log(
        actor=actor,
        action="election_modified",
        target_model="Election",
        target_object_id=election.id,
        description="Election was modified.",
    )
    return election


@transaction.atomic
def delete_election(*, election, actor):
    if election.effective_status == Election.STATUS_ACTIVE:
        return False

    election_id = election.id
    election.delete()
    create_audit_log(
        actor=actor,
        action="election_deleted",
        target_model="Election",
        target_object_id=election_id,
        description="Election was deleted.",
    )
    return True


@transaction.atomic
def create_position(*, election, validated_data, actor):
    position = Position.objects.create(election=election, **validated_data)
    create_audit_log(
        actor=actor,
        action="position_created",
        target_model="Position",
        target_object_id=position.id,
        description="Position was created.",
    )
    return position


@transaction.atomic
def update_position(*, position, validated_data, actor):
    for field, value in validated_data.items():
        setattr(position, field, value)
    position.save()
    create_audit_log(
        actor=actor,
        action="position_modified",
        target_model="Position",
        target_object_id=position.id,
        description="Position was modified.",
    )
    return position


@transaction.atomic
def delete_position(*, position, actor):
    position_id = position.id
    position.delete()
    create_audit_log(
        actor=actor,
        action="position_deleted",
        target_model="Position",
        target_object_id=position_id,
        description="Position was deleted.",
    )
