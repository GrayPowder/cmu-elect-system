import React, {useEffect, useMemo, useState} from "react";
import {Link, useNavigate, useParams} from "react-router-dom";
import {api, clearAuth} from "./api";
import logo from "./assets/cmu-elect-logo.png";

function MetricCard({label, value, detail}) {
  return <div className="analytics-metric-card">
    <span>{label}</span>
    <strong>{value}</strong>
    {detail && <small>{detail}</small>}
  </div>;
}

function TurnoutVisual({participants, eligible, percentage}) {
  const safePercentage = Math.max(0, Math.min(100, Number(percentage) || 0));
  return <div className="turnout-layout">
    <div className="turnout-ring" style={{background: `conic-gradient(#3348c4 ${safePercentage}%, #e9edf5 0)`}}>
      <div className="turnout-ring-center">
        <strong>{safePercentage.toFixed(2)}%</strong>
        <span>Turnout</span>
      </div>
    </div>
    <div className="turnout-details">
      <div><span>Participants</span><strong>{participants}</strong></div>
      <div><span>Eligible voters</span><strong>{eligible}</strong></div>
      <p>Aggregate participation only. No individual voter identity or ballot choice is displayed.</p>
    </div>
  </div>;
}

function BarChart({items}) {
  const max = Math.max(...items.map(item => Number(item.votes) || 0), 0);
  if (!items.length) return <div className="analytics-empty">No vote data is available yet.</div>;
  return <div className="analytics-bars">
    {items.map(item => {
      const votes = Number(item.votes) || 0;
      const width = max ? (votes / max) * 100 : 0;
      return <div className="analytics-bar-row" key={item.id}>
        <span className="analytics-bar-label" title={item.name}>{item.name}</span>
        <div className="analytics-bar-track"><div className="analytics-bar-fill" style={{width: `${width}%`}} /></div>
        <strong>{votes}</strong>
      </div>;
    })}
  </div>;
}

function CandidateGroups({items}) {
  const groups = useMemo(() => items.reduce((acc, item) => {
    if (!acc[item.position]) acc[item.position] = [];
    acc[item.position].push(item);
    return acc;
  }, {}), [items]);

  const positions = Object.keys(groups);
  if (!positions.length) return <div className="analytics-empty">No candidate data is available yet.</div>;

  return <div className="candidate-analytics-groups">
    {positions.map(position => (
      <div className="candidate-analytics-group" key={position}>
        <h3>{position}</h3>
        <BarChart items={groups[position]} />
      </div>
    ))}
  </div>;
}

export default function VoterAnalytics() {
  const {electionId} = useParams();
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const nav = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => {
    let cancelled = false;
    let timer;

    async function load() {
      try {
        const next = await api(`/elections/${electionId}/analytics/`);
        if (cancelled) return;
        setData(next);
        setError("");
        setLastUpdated(new Date());
      } catch (e) {
        if (!cancelled) setError(e.message);
      } finally {
        if (!cancelled) timer = window.setTimeout(load, 2000);
      }
    }

    load();
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [electionId]);

  async function logout() {
    try { await api("/auth/logout/", {method: "POST"}); } catch (_) {}
    clearAuth();
    nav("/login");
  }

  const metrics = data?.metrics;
  const election = data?.election;

  return <>
    <header className="topbar">
      <div className="topbar-brand">
        <img src={logo} alt="CMU-ELECT Logo" />
        <span>CMU-ELECT</span>
      </div>
      <nav className="main-nav">
        <span className="user-chip">{user.email}</span>
        <Link to="/dashboard">Home</Link>
        <button onClick={logout}>Logout</button>
      </nav>
    </header>

    <main className="dashboard analytics-page">
      <div className="admin-page-heading">
        <div>
          <h1>Real-Time Election Analytics</h1>
          <p>Live aggregate statistics from the current vote records.</p>
        </div>
        {data && <div className="analytics-live-status">
          <span className="live-dot" /> Live · updates every 2 seconds
          {lastUpdated && <small>Last update: {lastUpdated.toLocaleTimeString()}</small>}
        </div>}
      </div>

      <div className="modal-actions analytics-back-actions">
        <Link className="secondary" to="/dashboard">Back to Dashboard</Link>
        {election?.status === "ended" && <Link className="primary" to={`/results/${electionId}`}>Official Results</Link>}
      </div>

      {error && <div className="error">{error}</div>}
      {!data && !error && <div className="center">Loading analytics...</div>}

      {data && metrics && election && <>
        <section className="election-card analytics-election-summary">
          <h2>{election.name}</h2>
          <p>This dashboard shows aggregate election activity. It does not reveal how any individual voter voted.</p>
        </section>

        <div className="analytics-metrics-grid">
          <MetricCard label="Total votes" value={metrics.total_votes} detail="Recorded vote entries" />
          <MetricCard label="Participation" value={metrics.participants} detail="Unique voters who voted" />
          <MetricCard label="Turnout" value={`${Number(metrics.turnout_percentage).toFixed(2)}%`} detail="Participants ÷ eligible voters" />
          <MetricCard label="Positions" value={metrics.position_count} detail={`${metrics.candidate_count} candidates`} />
        </div>

        <div className="analytics-grid-two">
          <section className="analytics-panel">
            <div className="analytics-panel-heading"><div><h2>Turnout</h2><p>Current aggregate participation</p></div></div>
            <TurnoutVisual participants={metrics.participants} eligible={metrics.total_eligible_voters} percentage={metrics.turnout_percentage} />
          </section>

          <section className="analytics-panel">
            <div className="analytics-panel-heading"><div><h2>Election Statistics</h2><p>Current election activity</p></div></div>
            <div className="analytics-stat-list">
              <div><span>Status</span><strong className={`status-badge ${election.status}`}>{election.status}</strong></div>
              <div><span>Schedule</span><strong>{election.schedule_status.replace("_", " ")}</strong></div>
              <div><span>Positions</span><strong>{metrics.position_count}</strong></div>
              <div><span>Candidates</span><strong>{metrics.candidate_count}</strong></div>
              <div><span>Total votes</span><strong>{metrics.total_votes}</strong></div>
              <div><span>Participation</span><strong>{metrics.participants}</strong></div>
            </div>
          </section>
        </div>

        <section className="analytics-panel">
          <div className="analytics-panel-heading"><div><h2>Votes per Position</h2><p>Current vote totals grouped by position</p></div></div>
          <BarChart items={data.votes_per_position} />
        </section>

        <section className="analytics-panel">
          <div className="analytics-panel-heading"><div><h2>Votes per Candidate</h2><p>Current aggregate totals for each candidate</p></div></div>
          <CandidateGroups items={data.votes_per_candidate} />
        </section>
      </>}
    </main>
  </>;
}
