import React from "react";
import {NavLink} from "react-router-dom";

export function AdminModulePlaceholder({name}) {
  return <div>
    <header className="topbar">
      <div className="topbar-brand"><span>CMU-ELECT ADMIN</span></div>
      <nav><NavLink to="/admin" end className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Dashboard</NavLink></nav>
    </header>
    <main className="dashboard">
      <div className="result-title"><h1>{name}</h1><p>This administrator module is reserved for its dedicated implementation phase.</p></div>
    </main>
  </div>;
}

