import React, {useEffect, useState} from "react";
import {Link, NavLink, useNavigate} from "react-router-dom";
import {getAdminDashboard} from "../../services/adminService";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

export function AdminDashboard() {
  const nav = useNavigate();
  const {logout} = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getAdminDashboard()
      .then(setData)
      .catch(e => setError(e.message));
  }, []);

  async function handleLogout() {
    await logout();
    nav("/login", {replace: true});
  }

  return <div>
    <header className="topbar">
      <div className="topbar-brand">
        <img src={logo} alt="CMU-ELECT Logo" />
        <span>CMU-ELECT ADMIN</span>
      </div>
      <nav className="main-nav">
        <NavLink to="/admin" end className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Dashboard</NavLink>
        <NavLink to="/admin/users" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Voters</NavLink>
        <NavLink to="/admin/departments" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Departments</NavLink>
        <NavLink to="/admin/elections" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Elections</NavLink>
        <NavLink to="/admin/results" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Results</NavLink>
        <NavLink to="/admin/analytics" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Analytics</NavLink>
        <NavLink to="/admin/audit-logs" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Audit Logs</NavLink>
        <span className="user-chip">{data?.user?.email}</span>
        <button onClick={handleLogout}>Logout</button>
      </nav>
    </header>
    <main className="dashboard">
      <div className="result-title">
        <h1>Administrator Dashboard</h1>
        <p>Secure administrator area.</p>
      </div>
      {error && <div className="error">{error}</div>}
      <div className="position-grid">
        {data?.modules?.filter(module => !["positions", "candidates"].includes(module.key)).map(module => (
          <Link className="position" to={module.path} key={module.key}>
            <span>{module.name}</span>
          </Link>
        ))}
      </div>
    </main>
  </div>;
}
