import React, { useCallback, useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { getAuditLogs } from "../../services/adminService";
import { useAuth } from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

export default function AdminAuditLogs() {
  const nav = useNavigate();
  const { user, logout } = useAuth();

  const [logs, setLogs] = useState([]);
  const [actions, setActions] = useState([]);

  const [search, setSearch] = useState("");
  const [action, setAction] = useState("");
  const [sort, setSort] = useState("desc");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);

    try {
      const q = new URLSearchParams();

      if (search.trim()) {
        q.set("search", search.trim());
      }

      if (action) {
        q.set("action", action);
      }

      q.set("sort", sort);

      const data = await getAuditLogs(q.toString());

      setLogs(data.logs || []);
      setActions(data.actions || []);
      setError("");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [search, action, sort]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleLogout() {
    await logout();
    nav("/login", { replace: true });
  }

  return (
    <div>
      <header className="topbar">
        <div className="topbar-brand">
          <img src={logo} alt="CMU-ELECT Logo" />
          <span>CMU-ELECT ADMIN</span>
        </div>

        <nav className="main-nav">
          <NavLink to="/admin" end className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Dashboard</NavLink>
          <NavLink to="/admin/users" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Voters</NavLink>
          <NavLink to="/admin/departments" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Departments</NavLink>
          <NavLink to="/admin/elections" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Elections</NavLink>
          <NavLink to="/admin/results" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Results</NavLink>
          <NavLink to="/admin/analytics" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Analytics</NavLink>
          <NavLink to="/admin/audit-logs" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Audit Logs</NavLink>
          <span className="user-chip">{user?.email}</span>
          <button onClick={handleLogout}>Logout</button>
        </nav>
      </header>

      <main className="dashboard">
        <div className="admin-page-heading">
          <div>
            <h1>Audit Logs</h1>
            <p>
              Review important system, administrator, voter, voting,
              and security events.
            </p>
          </div>
        </div>

        <section className="result-selector audit-filters">
          <input
            className="standalone-input"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search action, actor, or description"
          />

          <select
            className="standalone-input"
            value={action}
            onChange={(e) => setAction(e.target.value)}
          >
            <option value="">All actions</option>

            {actions.map((x) => (
              <option key={x} value={x}>
                {x}
              </option>
            ))}
          </select>

          <select
            className="standalone-input"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="desc">Newest first</option>
            <option value="asc">Oldest first</option>
          </select>
        </section>

        {error && <div className="error">{error}</div>}

        {loading && (
          <div className="center">
            <span className="spinner" />
            Loading audit logs...
          </div>
        )}

        {!loading && !logs.length && (
          <div className="message">
            No audit events match the current filters.
          </div>
        )}

        {!loading && logs.length > 0 && (
          <section className="analytics-panel">
            <div className="audit-table-wrap">
              <table className="audit-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Actor</th>
                    <th>Action</th>
                    <th>Description</th>
                  </tr>
                </thead>

                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id}>
                      <td>
                        {new Date(log.timestamp).toLocaleString()}
                      </td>

                      <td>{log.actor}</td>

                      <td>
                        <span className="audit-action">
                          {log.action}
                        </span>
                      </td>

                      <td>{log.description || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}