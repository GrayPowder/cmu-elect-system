import React, {useEffect, useMemo, useState} from "react";
import {NavLink, useNavigate} from "react-router-dom";
import {createDepartment, listDepartments, updateDepartment} from "../../services/adminService";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

function DepartmentModal({department, onClose, onSaved}) {
  const editing = Boolean(department);
  const [form, setForm] = useState({
    code: department?.code || "",
    name: department?.name || "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(field, value) {
    setForm(current => ({...current, [field]: value}));
  }

  async function submit(event) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      const payload = {code: form.code.trim(), name: form.name.trim()};
      const saved = editing
        ? await updateDepartment(department.id, payload)
        : await createDepartment({...payload, is_active: true});
      onSaved(saved, editing ? "Department updated successfully." : "Department created successfully.");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal small-modal">
      <div className="modal-header">
        <div>
          <h2>{editing ? "Edit Department" : "Create Department"}</h2>
          <p>{editing ? "Update the department information." : "Add an academic department to CMU-ELECT."}</p>
        </div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <form onSubmit={submit}>
        <label>Department code</label>
        <input
          className="standalone-input"
          value={form.code}
          onChange={event => update("code", event.target.value)}
          maxLength="20"
          required

          placeholder="e.g. CCS"
        />
        {editing && <p className="password-note">The department code is unique and can be updated when needed.</p>}
        <label>Department name</label>
        <input
          className="standalone-input"
          value={form.name}
          onChange={event => update("name", event.target.value)}
          maxLength="150"
          required
          placeholder="e.g. College of Computer Studies"
        />
        {error && <div className="error">{error}</div>}
        <div className="modal-actions">
          <button type="button" className="secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary modal-primary" disabled={loading}>{loading ? "Saving..." : editing ? "Save Changes" : "Create Department"}</button>
        </div>
      </form>
    </section>
  </div>;
}

export default function AdminDepartments() {
  const nav = useNavigate();
  const {user, logout} = useAuth();
  const [departments, setDepartments] = useState([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);

  async function loadDepartments() {
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("search", search.trim());
      if (status) params.set("status", status);
      setDepartments(await listDepartments(params.toString()));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadDepartments(); }, []);

  const summary = useMemo(() => ({
    total: departments.length,
    active: departments.filter(department => department.is_active).length,
    inactive: departments.filter(department => !department.is_active).length,
  }), [departments]);

  async function toggleStatus(department) {
    setError("");
    setSuccess("");
    try {
      await updateDepartment(department.id, {is_active: !department.is_active});
      setSuccess(`Department ${department.code} ${department.is_active ? "deactivated" : "activated"} successfully.`);
      await loadDepartments();
    } catch (err) {
      setError(err.message);
    }
  }

  function handleSaved(_, message) {
    setCreating(false);
    setEditing(null);
    setSuccess(message);
    loadDepartments();
  }

  async function handleLogout() {
    await logout();
    nav("/login", {replace: true});
  }

  return <div>
    <header className="topbar">
      <div className="topbar-brand">
        <img src={logo} alt="CMU-ELECT Logo" />
        <span>CMU-ELECT ADMIN</span>
      </div>
      <nav className="main-nav">
        <NavLink to="/admin" end className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Dashboard</NavLink>
        <NavLink to="/admin/users" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Voters</NavLink>
        <NavLink to="/admin/departments" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Departments</NavLink>
        <NavLink to="/admin/elections" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Elections</NavLink>
        <NavLink to="/admin/results" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Results</NavLink>
        <NavLink to="/admin/analytics" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Analytics</NavLink>
        <NavLink to="/admin/audit-logs" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Audit Logs</NavLink>
        <span className="user-chip">{user?.email}</span>
        <button onClick={handleLogout}>Logout</button>
      </nav>
    </header>

    <main className="dashboard admin-users-page">
      <div className="admin-page-heading">
        <div>
          <h1>Department Management</h1>
          <p>Create, edit, activate, and deactivate academic departments.</p>
        </div>
        <button className="primary create-button" onClick={() => {setSuccess(""); setCreating(true);}}>+ Create Department</button>
      </div>

      <div className="admin-summary">
        <div><strong>{summary.total}</strong><span>Total Departments</span></div>
        <div><strong>{summary.active}</strong><span>Active</span></div>
        <div><strong>{summary.inactive}</strong><span>Inactive</span></div>
      </div>

      <section className="admin-panel">
        <div className="filter-row department-filter-row">
          <div>
            <label>Search</label>
            <input value={search} onChange={event => setSearch(event.target.value)} placeholder="Code or department name" />
          </div>
          <div>
            <label>Status</label>
            <select value={status} onChange={event => setStatus(event.target.value)}>
              <option value="">All statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          <button className="primary filter-button" onClick={loadDepartments}>Apply Filters</button>
        </div>
      </section>

      {success && <div className="success">{success}</div>}
      {error && <div className="error">{error}</div>}

      <section className="admin-table-wrap">
        <div className="table-scroll">
          <table className="admin-table department-table">
            <thead><tr><th>Code</th><th>Department Name</th><th>Status</th><th>Last Updated</th><th>Actions</th></tr></thead>
            <tbody>
              {loading ? <tr><td colSpan="5">Loading departments...</td></tr> : departments.length === 0 ? <tr><td colSpan="5">No departments found.</td></tr> : departments.map(department => <tr key={department.id}>
                <td><strong>{department.code}</strong></td>
                <td>{department.name}</td>
                <td><span className={`status-badge ${department.is_active ? "active" : "inactive"}`}>{department.status}</span></td>
                <td>{department.updated_at ? new Date(department.updated_at).toLocaleString() : "—"}</td>
                <td><div className="table-actions">
                  <button className="secondary" onClick={() => {setSuccess(""); setEditing(department);}}>Edit</button>
                  <button className={department.is_active ? "secondary danger-action" : "secondary"} onClick={() => toggleStatus(department)}>
                    {department.is_active ? "Deactivate" : "Activate"}
                  </button>
                </div></td>
              </tr>)}
            </tbody>
          </table>
        </div>
      </section>
    </main>

    {(creating || editing) && <DepartmentModal department={editing} onClose={() => {setCreating(false); setEditing(null);}} onSaved={handleSaved} />}
  </div>;
}
