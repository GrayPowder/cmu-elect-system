import React, {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import {useAuth} from "../../context/AuthContext";
import {AuthShell} from "../../components/auth/AuthShell";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import emailIcon from "../../assets/Email.png";
import lockIcon from "../../assets/Lock.png";

export function Login() {
  const nav = useNavigate();
  const {login} = useAuth();
  const [role, setRole] = useState("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const user = await login({email, password, role});
      if (user.is_admin) {
        nav("/admin", {replace: true});
      } else {
        nav(user.must_change_password ? "/change-password" : "/dashboard", {replace: true});
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <AuthShell>
    <form className="auth-card login-card" onSubmit={submit}>
      <h1>Welcome!</h1>
      <p>Sign in to cast your voice and become an instrument for change.</p>
      <h3>Are you a/an?</h3>
      <div className="role-buttons">
        {["student", "alumni", "faculty"].map(r => <button
          type="button"
          key={r}
          className={`role role-${r} ${role === r ? "selected" : ""}`}
          onClick={() => { setRole(r); setError(""); }}
        >{r[0].toUpperCase() + r.slice(1)}</button>)}
      </div>

      <label htmlFor="login-identifier">Login Identifier or CMU Email</label>
      <div className="input-wrap">
        <img src={emailIcon} alt="" />
        <input
          id="login-identifier"
          name="email"
          type="text"
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder="enter your identifier or email"
          autoComplete="username"
          required
        />
      </div>

      <label htmlFor="login-password">Password</label>
      <div className="input-wrap">
        <img src={lockIcon} alt="" />
        <input
          id="login-password"
          name="password"
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          placeholder="enter your password"
          autoComplete="current-password"
          required
        />
      </div>

      {error && <div className="error">{error}</div>}
      <button className="primary" disabled={loading}>{loading ? "Signing In..." : "Sign In"}</button>
      <Link className="forgot-link" to="/forgot-password">Forgot Password?</Link>
    </form>
  </AuthShell>;
}

