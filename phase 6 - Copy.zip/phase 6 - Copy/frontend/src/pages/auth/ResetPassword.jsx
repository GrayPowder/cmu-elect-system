import React, {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import {AuthShell, AuthCard} from "../../components/auth/AuthShell";
import {resetPassword} from "../../services/authService";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import lockIcon from "../../assets/Lock.png";

export function ResetPassword() {
  const nav = useNavigate();
  const [email, setEmail] = useState(() => sessionStorage.getItem("cmu_elect_reset_email") || "");
  const [resetToken] = useState(() => sessionStorage.getItem("cmu_elect_reset_token") || "");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!email || !resetToken) nav("/forgot-password", {replace: true});
  }, [email, resetToken, nav]);

  async function submit(e) {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      await resetPassword({email, reset_token: resetToken, password, confirm_password: confirmPassword});
      sessionStorage.removeItem("cmu_elect_reset_email");
      sessionStorage.removeItem("cmu_elect_reset_token");
      nav("/login", {replace: true});
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  return <AuthShell>
    <AuthCard title="RESET PASSWORD">
      <form onSubmit={submit}>
        <label htmlFor="new-password">New password</label>
        <div className="input-wrap">
          <img src={lockIcon} alt="" />
          <input
            id="new-password"
            name="newPassword"
            type="password"
            minLength="8"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="at least 8 characters"
            autoComplete="new-password"
            required
          />
        </div>

        <label htmlFor="confirm-password">Confirm password</label>
        <div className="input-wrap">
          <img src={lockIcon} alt="" />
          <input
            id="confirm-password"
            name="confirmPassword"
            type="password"
            minLength="8"
            value={confirmPassword}
            onChange={e => setConfirmPassword(e.target.value)}
            placeholder="repeat your new password"
            autoComplete="new-password"
            required
          />
        </div>
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={loading}>{loading ? "Saving..." : "Reset Password"}</button>
      </form>
    </AuthCard>
  </AuthShell>;
}
