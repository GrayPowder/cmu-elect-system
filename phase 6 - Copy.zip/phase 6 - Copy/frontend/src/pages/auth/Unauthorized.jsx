import React from "react";
import {Link} from "react-router-dom";
import {AuthShell, AuthCard} from "../../components/auth/AuthShell";

export function Unauthorized() {
  return <AuthShell>
    <AuthCard title="UNAUTHORIZED" backToLogin={false}>
      <p>You do not have permission to access the administrator area.</p>
      <Link className="primary" to="/login">Return to login</Link>
    </AuthCard>
  </AuthShell>;
}
