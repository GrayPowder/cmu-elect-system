import React, {useState} from "react";
import {useNavigate} from "react-router-dom";
import {AuthShell, AuthCard} from "../../components/auth/AuthShell";
import {requestPasswordReset, verifyResetCode, resendResetCode} from "../../services/authService";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import emailIcon from "../../assets/Email.png";

export function ForgotPassword() {
  const nav = useNavigate();
  const [step, setStep] = useState("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function requestCode(e) {
    e.preventDefault();
    setError(""); setMessage(""); setLoading(true);
    try {
      const data = await requestPasswordReset(email);
      setMessage(data.detail);
      setStep("code");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  async function verifyCode(e) {
    e.preventDefault();
    setError(""); setMessage(""); setLoading(true);
    try {
      const data = await verifyResetCode({email, code});
      sessionStorage.setItem("cmu_elect_reset_email", email.trim().toLowerCase());
      sessionStorage.setItem("cmu_elect_reset_token", data.reset_token);
      nav("/reset-password");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  async function resendCode() {
    setError(""); setMessage("");
    try {
      const data = await resendResetCode(email);
      setMessage(data.detail);
    } catch (err) { setError(err.message); }
  }

  if (step === "code") return <AuthShell>
    <AuthCard title="VERIFICATION">
      <p className="small-label">ENTER VERIFICATION CODE</p>
      <form onSubmit={verifyCode}>
        <input
          id="verification-code"
          name="verificationCode"
          className="code-input"
          type="text"
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength="6"
          value={code}
          onChange={e => setCode(e.target.value.replace(/\D/g, ""))}
          placeholder="000000"
          required
        />
        <p className="resend-copy">Didn't receive a code? <button type="button" onClick={resendCode}>Resend</button></p>
        {message && <div className="info">{message}</div>}
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={loading}>{loading ? "Verifying..." : "Verify"}</button>
      </form>
    </AuthCard>
  </AuthShell>;

  return <AuthShell>
    <AuthCard title="FORGOT PASSWORD">
      <p className="forgot-copy">Enter your CMU email and we'll send you a verification code.</p>
      <form onSubmit={requestCode}>
        <div className="input-wrap">
          <img src={emailIcon} alt="" />
          <input
            id="forgot-password-email"
            name="email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="enter your email"
            autoComplete="email"
            required
          />
        </div>
        {message && <div className="info">{message}</div>}
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={loading}>{loading ? "Sending..." : "SUBMIT"}</button>
      </form>
    </AuthCard>
  </AuthShell>;
}
