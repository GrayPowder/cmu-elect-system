import React, {useEffect, useState} from "react";
import {Link, useNavigate, useParams} from "react-router-dom";
import {getElection} from "../../services/electionService";
import {mediaUrl} from "../../services/api";
import {Layout} from "../../components/layout/Layout";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import profileIcon from "../../assets/Profile.png";

export function BallotPage() {
  const { electionId } = useParams();
  const nav = useNavigate();
  const [election, setElection] = useState(null);
  const [selections, setSelections] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getElection(electionId)
      .then(data => {
        if (!data.is_open) {
          setError(data.status === "not_started"
            ? "Voting for this election has not started."
            : "Voting for this election has ended.");
        }
        setElection(data);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [electionId]);

  function selectCandidate(positionId, candidateId) {
    setSelections(current => ({...current, [positionId]: candidateId}));
  }

  function review() {
    setError("");
    if (!election?.is_open) return;
    if (Object.keys(selections).length === 0) {
      setError("Please select at least one candidate before continuing.");
      return;
    }
    nav(`/vote/${election.id}/review`, {state: {election, selections}});
  }

  if (loading) return <Layout><main className="dashboard"><div className="loading-state"><span className="spinner" /> Loading ballot...</div></main></Layout>;

  return (
    <Layout>
      <main className="dashboard">
        <div className="result-title">
          <h1>{election?.name || "Ballot"}</h1>
          <p>Select candidates for the positions you wish to vote for, then review your ballot.</p>
        </div>

        {error && <div className="error">{error}</div>}

        {election && election.is_open && (
          <>
            {election.positions.map(position => (
              <section className="election-card ballot-position" key={position.id}>
                <h2>{position.name}</h2>
                <div className="candidate-list">
                  {position.candidates.map(candidate => (
                    <article
                      className={`candidate ${selections[position.id] === candidate.id ? "chosen" : ""}`}
                      onClick={() => selectCandidate(position.id, candidate.id)}
                      key={candidate.id}
                    >
                      <img src={candidate.photo ? mediaUrl(candidate.photo) : profileIcon} alt="" />
                      <div>
                        {candidate.party_list && <span className="party">{candidate.party_list}</span>}
                        <h2>{candidate.name}</h2>
                        {candidate.department && <p>{candidate.department}</p>}
                        {candidate.platform && <p><b>Platform:</b> {candidate.platform}</p>}
                      </div>
                      <button type="button" onClick={e => {e.stopPropagation(); selectCandidate(position.id, candidate.id);}}>
                        {selections[position.id] === candidate.id ? "Selected" : "Select"}
                      </button>
                    </article>
                  ))}
                </div>
              </section>
            ))}

            <div className="modal-actions">
              <Link className="secondary" to={`/elections/${election.id}`}>Back</Link>
              <button className="primary" onClick={review}>Review Ballot</button>
            </div>
          </>
        )}
      </main>
    </Layout>
  );
}
