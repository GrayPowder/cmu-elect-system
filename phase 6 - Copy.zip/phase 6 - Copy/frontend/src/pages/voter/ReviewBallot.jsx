import React, {useState} from "react";
import {Link, useNavigate, useLocation, useParams} from "react-router-dom";
import {submitVotes} from "../../services/votingService";
import {Layout} from "../../components/layout/Layout";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";

export function ReviewBallot() {
  const { electionId } = useParams();
  const nav = useNavigate();
  const location = useLocation();
  const state = location.state;
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!state?.election || String(state.election.id) !== String(electionId)) {
    return <Layout><main className="center"><div className="error">Your ballot session is no longer available. Please return to the election and start again.</div><Link className="primary" to={`/vote/${electionId}`}>Return to Ballot</Link></main></Layout>;
  }

  const {election, selections} = state;

  async function submit() {
    setSubmitting(true);
    setError("");
    try {
      const votes = Object.entries(selections).map(([position_id, candidate_id]) => ({
        position_id: Number(position_id),
        candidate_id: Number(candidate_id),
      }));
      const data = await submitVotes({electionId: election.id, votes});
      nav(`/vote/${election.id}/confirmation`, {state: {confirmation: data}});
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Layout>
      <main className="dashboard">
        <div className="result-title">
          <h1>Review Ballot</h1>
          <p>Check your selections before submitting your vote.</p>
        </div>

        <section className="election-card">
          <h2>{election.name}</h2>
          {Object.entries(selections).map(([positionId, candidateId]) => {
            const position = election.positions.find(p => p.id === Number(positionId));
            const candidate = position?.candidates.find(c => c.id === Number(candidateId));
            return position && candidate ? (
              <div className="review-row" key={positionId}>
                <strong>{position.name}</strong>
                <span>{candidate.name}</span>
              </div>
            ) : null;
          })}
        </section>

        {error && <div className="error">{error}</div>}

        <div className="modal-actions">
          <button className="secondary" onClick={() => nav(`/vote/${election.id}`)}>Back</button>
          <button className="primary" onClick={submit} disabled={submitting}>
            {submitting ? "Submitting..." : "Submit Vote"}
          </button>
        </div>
      </main>
    </Layout>
  );
}
