import React from "react";
import {Link} from "react-router-dom";
import {Layout} from "../../components/layout/Layout";
import {useAuth} from "../../context/AuthContext";

export function Profile() {
  const {user} = useAuth();
  const category = user.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : "Voter";

  return (
    <Layout>
      <main className="dashboard profile-page">
        <div className="page-heading-card">
          <div>
            <span className="eyebrow">ACCOUNT</span>
            <h1>My Profile</h1>
            <p>Review your CMU-ELECT account information and security options.</p>
          </div>
        </div>
        <section className="profile-grid">
          <article className="profile-card profile-identity">
            <div className="profile-avatar">{(user.username || user.email || "V").charAt(0).toUpperCase()}</div>
            <h2>{user.username || "Voter"}</h2>
            <span className={`category-badge ${user.role || "student"}`}>{category}</span>
            <p className="profile-muted">Your account is managed by a CMU-ELECT administrator.</p>
          </article>
          <article className="profile-card">
            <div className="section-heading"><div><h2>Account information</h2><p>Details currently associated with your voter account.</p></div></div>
            <div className="profile-details">
              <div><span>Login identifier</span><strong>{user.username || "—"}</strong></div>
              <div><span>CMU email</span><strong>{user.email || "—"}</strong></div>
              <div><span>Voter category</span><strong>{category}</strong></div>
              <div><span>Account status</span><strong className="status-badge active">Active</strong></div>
            </div>
            <div className="profile-actions">
              <Link className="secondary" to="/change-password">Change Password</Link>
              <Link className="primary profile-primary" to="/dashboard">Back to Dashboard</Link>
            </div>
          </article>
        </section>
      </main>
    </Layout>
  );
}
