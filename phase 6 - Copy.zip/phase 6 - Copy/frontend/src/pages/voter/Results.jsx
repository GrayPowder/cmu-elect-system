import React, {useEffect, useState} from "react";
import {useParams, useNavigate} from "react-router-dom";
import {getElectionResults} from "../../services/electionService";
import {Layout} from "../../components/layout/Layout";
import {ResultsContent} from "../../components/common/ResultsContent";

export function Results() {
  const {electionId}=useParams();
  const navigate=useNavigate();
  const [data,setData]=useState(null);
  const [error,setError]=useState("");
  useEffect(()=>{
    getElectionResults(electionId)
      .then(setData)
      .catch(e=>setError(e.message));
  },[electionId]);

  return <Layout>
    <main className="dashboard">
      <div className="result-title">
        <h1>Election Results</h1>
        <p>Official results calculated from recorded votes.</p>
      </div>
      {error && <div className="error">{error}</div>}
      <button
          type="button"
          onClick={()=>navigate("/dashboard")}
        >
          Back to Dashboard
        </button>
      {data && <ResultsContent data={data}/>}
    </main>
  </Layout>;
}