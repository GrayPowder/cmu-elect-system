import React from "react";
import {Link, useLocation} from "react-router-dom";
import {Layout} from "../../components/layout/Layout";

export function VoteConfirmation() {
  const location = useLocation();
  const confirmation = location.state?.confirmation;

  return (
    <Layout>
      <main className="dashboard">
        <div className="result-title">
          <h1>Vote Successfully Submitted</h1>
          <p>Your ballot was recorded successfully.</p>
        </div>
        <section className="election-card">
          <h2>{confirmation?.election?.name || "Election"}</h2>
          <p><strong>Submission timestamp:</strong> {confirmation?.submitted_at ? new Date(confirmation.submitted_at).toLocaleString() : "Recorded"}</p>
          <p>Your selections have been securely recorded.</p>
        </section>
        <div className="modal-actions">
          <Link className="primary" to="/dashboard">Return to Dashboard</Link>
        </div>
      </main>
    </Layout>
  );
}
