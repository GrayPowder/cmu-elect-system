import {api} from "./api";

export function getVoterAnalytics(electionId) {
  return api(`/elections/${electionId}/analytics/`);
}

export function getAdminAnalytics(electionId) {
  return api(`/admin/elections/${electionId}/analytics/`);
}
