import {api} from "./api";

export function submitVotes({electionId, votes}) {
  return api("/votes/", {
    method: "POST",
    body: JSON.stringify({election_id: Number(electionId), votes}),
  });
}
