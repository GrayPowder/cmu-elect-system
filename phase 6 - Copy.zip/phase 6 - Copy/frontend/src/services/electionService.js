import {api} from "./api";

export function listElections() {
  return api("/elections/");
}

export function getElection(electionId) {
  return api(`/elections/${electionId}/`);
}

export function getElectionResults(electionId) {
  return api(`/elections/${electionId}/results/`);
}
