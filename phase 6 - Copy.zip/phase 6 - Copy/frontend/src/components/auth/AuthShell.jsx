import React from "react";
import {Link} from "react-router-dom";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";

export function AuthShell({children}) {
  return (
    <div
      className="auth-page"
      style={{backgroundImage: `url("${cover}")`}}
    >
      <section className="auth-brand">

        <div className="brand-logos">
          <img src={logo} className="brand-elect" />
          <img src={cmu} className="brand-cmu" />
        </div>

        <h1>CMU-ELECT</h1>

        <p>
          There's nothing better than being transparent to the people.
        </p>

      </section>

      {children}
    </div>
  );
}

export function AuthCard({title, children, backToLogin=true}) {
  return <section className="auth-card">
    <h1>{title}</h1>
    {children}
    {backToLogin && <Link className="back-login" to="/login">← back to login</Link>}
  </section>;
}
