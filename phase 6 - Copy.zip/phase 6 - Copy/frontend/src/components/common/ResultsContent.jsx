import React from "react";

export function ResultsContent({data}) {
  return <div className="results-content">
    <div className="result-summary">
      <div><span>Election</span><strong>{data.election.name}</strong></div>
    </div>
    {data.results.map(result => (
      <section className="result" key={result.position_id}>
        <div className="result-heading">
          <div>
            <h2>{result.position}</h2>
            <span>Final result percentages</span>
          </div>
          {result.winners.length > 0 && (
            <div className="winner-box">
              <span>Winner{result.winners.length > 1 ? "s" : ""}</span>
              <strong>{result.winners.map(w => w.candidate).join(", ")}</strong>
            </div>
          )}
        </div>
        <div className="result-candidates">
          {result.candidates.map(candidate => (
            <div className="result-candidate" key={candidate.id}>
              <span>{candidate.candidate}</span>
              <strong>{Number(candidate.percentage).toFixed(2)}%</strong>
            </div>
          ))}
        </div>
      </section>
    ))}
  </div>;
}

