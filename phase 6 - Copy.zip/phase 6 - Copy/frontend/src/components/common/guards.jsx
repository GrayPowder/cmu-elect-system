import React from "react";
import {Navigate} from "react-router-dom";
import {useAuth} from "../../context/AuthContext";

export function RequireAuth({children}) {
  const {isAuthenticated, isInitializing} = useAuth();
  if (isInitializing) return null;
  return isAuthenticated ? children : <Navigate to="/login" replace />;
}

export function RequirePasswordChanged({children}) {
  const {isAuthenticated, isInitializing, user} = useAuth();
  if (isInitializing) return null;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (!user?.is_admin && user?.must_change_password) return <Navigate to="/change-password" replace />;
  return children;
}

export function RequireAdmin({children}) {
  const {isAuthenticated, isInitializing, isAdmin} = useAuth();
  if (isInitializing) return null;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (!isAdmin) return <Navigate to="/unauthorized" replace />;
  return children;
}
