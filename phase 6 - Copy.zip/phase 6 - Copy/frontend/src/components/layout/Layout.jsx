import React from "react";
import {Link, useNavigate} from "react-router-dom";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

export function Layout({children}) {
  const nav = useNavigate();
  const {user, logout} = useAuth();

  async function handleLogout() {
    await logout();
    nav("/login", {replace: true});
  }
  return <>
  <header className="topbar">
  <div className="topbar-brand">
    <img src={logo} alt="CMU-ELECT Logo" />
    <span>CMU-ELECT</span>
  </div>

  <nav className="main-nav">
    <span className="user-chip">{user.email}</span>
    <Link to="/dashboard">Home</Link>
    <button onClick={handleLogout}>Logout</button>
  </nav>
</header>
    {children}
  </>;
}
