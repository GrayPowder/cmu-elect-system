import React, {createContext, useCallback, useContext, useEffect, useMemo, useState} from "react";
import {login as loginRequest, logout as logoutRequest, getCurrentUser} from "../services/authService";
import {clearStoredAuth, getStoredUser, getToken, persistAuth} from "./authStorage";

const AuthContext = createContext(null);

function normalizeUser(user) {
  if (!user) return null;
  return {
    ...user,
    is_admin: Boolean(user.is_admin),
    role: user.is_admin ? null : user.role || null,
  };
}

export function AuthProvider({children}) {
  const [user, setUser] = useState(() => normalizeUser(getStoredUser()));
  const [token, setToken] = useState(() => getToken());
  const [isInitializing, setIsInitializing] = useState(Boolean(getToken()));

  const clearSession = useCallback(() => {
    clearStoredAuth();
    setToken(null);
    setUser(null);
  }, []);

  const applySession = useCallback((nextToken, nextUser) => {
    const normalizedUser = normalizeUser(nextUser);
    persistAuth(nextToken, normalizedUser);
    setToken(nextToken);
    setUser(normalizedUser);
    return normalizedUser;
  }, []);

  const login = useCallback(async ({email, password, role}) => {
    const data = await loginRequest({email, password, role});
    return applySession(data.token, data.user);
  }, [applySession]);

  const logout = useCallback(async () => {
    try {
      if (getToken()) {
        await logoutRequest();
      }
    } catch (_) {
      // The local session is cleared even when the server cannot be reached.
    } finally {
      clearSession();
    }
  }, [clearSession]);

  const updateSession = useCallback(({token: nextToken = token, user: nextUser = user}) => {
    if (!nextToken || !nextUser) {
      clearSession();
      return;
    }
    applySession(nextToken, nextUser);
  }, [applySession, clearSession, token, user]);

  useEffect(() => {
    const handleUnauthorized = () => clearSession();
    window.addEventListener("cmu-elect:auth-unauthorized", handleUnauthorized);
    return () => window.removeEventListener("cmu-elect:auth-unauthorized", handleUnauthorized);
  }, [clearSession]);

  useEffect(() => {
    let cancelled = false;

    async function initialize() {
      const storedToken = getToken();
      if (!storedToken) {
        setIsInitializing(false);
        return;
      }

      try {
        const currentUser = await getCurrentUser();
        if (cancelled) return;

        // /auth/me/ is authoritative after a refresh; never infer admin access
        // from a client-controlled role value.
        applySession(storedToken, currentUser);
      } catch (_) {
        if (!cancelled) clearSession();
      } finally {
        if (!cancelled) setIsInitializing(false);
      }
    }

    initialize();
    return () => { cancelled = true; };
  }, [applySession, clearSession]);

  const value = useMemo(() => ({
    user,
    token,
    isAuthenticated: Boolean(token && user),
    isInitializing,
    isAdmin: Boolean(user?.is_admin),
    voterRole: user?.role || null,
    login,
    logout,
    updateSession,
  }), [user, token, isInitializing, login, logout, updateSession]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside an AuthProvider");
  return context;
}
