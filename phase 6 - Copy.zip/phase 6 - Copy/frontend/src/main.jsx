import React from "react";
import {createRoot} from "react-dom/client";
import {BrowserRouter, Routes, Route, Navigate} from "react-router-dom";
import "./styles.css";

import {RequireAuth, RequirePasswordChanged, RequireAdmin} from "./components/common/guards";
import {useAuth} from "./context/AuthContext";
import {AuthProvider} from "./context/AuthContext";

import {Login} from "./pages/auth/Login";
import {ForgotPassword} from "./pages/auth/ForgotPassword";
import {ResetPassword} from "./pages/auth/ResetPassword";
import {ChangePassword} from "./pages/auth/ChangePassword";
import {Unauthorized} from "./pages/auth/Unauthorized";
import {AdminDashboard} from "./pages/admin/AdminDashboard";
import {AdminResults} from "./pages/admin/AdminResults";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminDepartments from "./pages/admin/AdminDepartments";
import AdminElections from "./pages/admin/AdminElections";
import AdminAnalytics from "./pages/admin/AdminAnalytics";
import AdminAuditLogs from "./pages/admin/AdminAuditLogs";
import {Dashboard} from "./pages/voter/Dashboard";
import {Profile} from "./pages/voter/Profile";
import {ElectionDetails} from "./pages/voter/ElectionDetails";
import {BallotPage} from "./pages/voter/BallotPage";
import {ReviewBallot} from "./pages/voter/ReviewBallot";
import {VoteConfirmation} from "./pages/voter/VoteConfirmation";
import {Results} from "./pages/voter/Results";
import VoterAnalytics from "./pages/voter/VoterAnalytics";

function App(){
  const {isAuthenticated, isInitializing, user} = useAuth();

  if (isInitializing) return null;

  return <Routes>
    <Route path="/login" element={<Login/>}/>
    <Route path="/forgot-password" element={<ForgotPassword/>}/>
    <Route path="/reset-password" element={<ResetPassword/>}/>
    <Route path="/unauthorized" element={<Unauthorized/>}/>
    <Route path="/admin" element={<RequireAdmin><AdminDashboard/></RequireAdmin>}/>
    <Route path="/admin/users" element={<RequireAdmin><AdminUsers/></RequireAdmin>}/>
    <Route path="/admin/departments" element={<RequireAdmin><AdminDepartments/></RequireAdmin>}/>
    <Route path="/admin/elections" element={<RequireAdmin><AdminElections/></RequireAdmin>}/>
    <Route path="/admin/results" element={<RequireAdmin><AdminResults/></RequireAdmin>}/>
    <Route path="/admin/analytics" element={<RequireAdmin><AdminAnalytics/></RequireAdmin>}/>
    <Route path="/admin/audit-logs" element={<RequireAdmin><AdminAuditLogs/></RequireAdmin>}/>
    <Route path="/change-password" element={<RequireAuth><ChangePassword/></RequireAuth>}/>
    <Route path="/dashboard" element={<RequireAuth><RequirePasswordChanged><Dashboard/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/profile" element={<RequireAuth><RequirePasswordChanged><Profile/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/elections/:electionId" element={<RequireAuth><RequirePasswordChanged><ElectionDetails/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/vote/:electionId" element={<RequireAuth><RequirePasswordChanged><BallotPage/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/vote/:electionId/review" element={<RequireAuth><RequirePasswordChanged><ReviewBallot/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/vote/:electionId/confirmation" element={<RequireAuth><RequirePasswordChanged><VoteConfirmation/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/results/:electionId" element={<RequireAuth><RequirePasswordChanged><Results/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="/analytics/:electionId" element={<RequireAuth><RequirePasswordChanged><VoterAnalytics/></RequirePasswordChanged></RequireAuth>}/>
    <Route path="*" element={<Navigate to={isAuthenticated ? (user?.is_admin ? "/admin" : "/dashboard") : "/login"} replace/>}/>
  </Routes>;
}

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <AuthProvider>
      <App/>
    </AuthProvider>
  </BrowserRouter>
);
