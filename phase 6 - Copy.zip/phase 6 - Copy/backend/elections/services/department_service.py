from django.db import transaction

from ..models import Department
from .audit_service import create_audit_log


@transaction.atomic
def create_department(*, validated_data, actor):
    department = Department.objects.create(**validated_data)
    create_audit_log(
        actor=actor,
        action="department_created",
        target_model="Department",
        target_object_id=department.id,
        description=f"Department {department.code} was created.",
    )
    return department


@transaction.atomic
def update_department(*, department, validated_data, actor):
    previous_active = department.is_active
    for field, value in validated_data.items():
        setattr(department, field, value)
    department.save()

    if previous_active != department.is_active:
        action = "department_activated" if department.is_active else "department_deactivated"
        description = (
            f"Department {department.code} was activated."
            if department.is_active
            else f"Department {department.code} was deactivated."
        )
    else:
        action = "department_modified"
        description = f"Department {department.code} was modified."

    create_audit_log(
        actor=actor,
        action=action,
        target_model="Department",
        target_object_id=department.id,
        description=description,
    )
    return department
