"""Compatibility exports for non-business helpers used by older imports."""

import hashlib
import secrets

from django.conf import settings
from django.core.mail import send_mail


def hash_value(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def create_reset_code():
    return f"{secrets.randbelow(1_000_000):06d}"


def send_reset_code(email, code):
    send_mail(
        subject="CMU-ELECT password reset verification code",
        message=(
            "Your CMU-ELECT verification code is " + code +
            ". It expires in 10 minutes. If you did not request a password reset, "
            "you can ignore this message."
        ),
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "cmu-elect@localhost"),
        recipient_list=[email],
        fail_silently=False,
    )
