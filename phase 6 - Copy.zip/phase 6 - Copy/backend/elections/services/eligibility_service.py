"""Centralized voter eligibility and election-scope checks."""

from ..models import Election


def is_voter_eligible_for_election(voter, election, *, require_open=True):
    """Return whether a voter may access/vote in an election.

    This is the backend source of truth for category and department eligibility.
    ``require_open=False`` is reserved for post-election voter access such as
    viewing final results, where the election is intentionally no longer open.
    """
    if voter is None or not getattr(voter, "is_authenticated", False):
        return False
    if not voter.is_active:
        return False

    profile = getattr(voter, "profile", None)
    if profile is None or profile.account_status != "active":
        return False
    if profile.must_change_password:
        return False
    if not profile.role:
        return False

    if profile.role != election.eligible_voter_category:
        return False

    if require_open and not election.is_open:
        return False

    if election.department_scope == Election.DEPARTMENT_SCOPE_ALL:
        return True

    if election.department_scope == Election.DEPARTMENT_SCOPE_SPECIFIC:
        department_id = getattr(profile, "department_id", None)
        if not department_id:
            return False
        return election.eligible_departments.filter(pk=department_id).exists()

    return False


def is_voter_in_election_scope(voter, election):
    """Return whether category/department scope matches, independent of schedule."""
    return is_voter_eligible_for_election(voter, election, require_open=False)
