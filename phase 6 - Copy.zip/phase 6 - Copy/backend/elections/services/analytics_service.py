"""Reusable analytics calculations."""

from django.utils import timezone

from ..models import Candidate, Profile, Vote


def build_analytics_data(election):
    """Build database-backed aggregate analytics without changing the response shape."""
    eligible_voters = Profile.objects.filter(
        role=election.eligible_voter_category,
        account_status="active",
        user__is_active=True,
    ).count()
    vote_queryset = Vote.objects.filter(election=election)
    total_votes = vote_queryset.count()
    participants = vote_queryset.values("voter_id").distinct().count()
    turnout_percentage = round((participants / eligible_voters) * 100, 2) if eligible_voters else 0.0

    return {
        "updated_at": timezone.now(),
        "election": {
            "id": election.id,
            "name": election.name,
            "status": election.effective_status,
            "schedule_status": election.schedule_status,
            "eligible_voter_category": election.eligible_voter_category,
            "start_datetime": election.start_datetime,
            "end_datetime": election.end_datetime,
        },
        "metrics": {
            "total_eligible_voters": eligible_voters,
            "total_votes": total_votes,
            "participants": participants,
            "turnout_percentage": turnout_percentage,
            "position_count": election.positions.count(),
            "candidate_count": Candidate.objects.filter(position__election=election).count(),
        },
    }
