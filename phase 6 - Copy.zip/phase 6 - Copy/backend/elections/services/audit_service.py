"""Reusable audit-log business operations."""

from ..models import AuditLog


def create_audit_log(*, actor=None, action, target_model="", target_object_id="", description=""):
    """Persist an audit event using the application's existing audit fields."""
    return AuditLog.objects.create(
        actor=actor if getattr(actor, "is_authenticated", False) else None,
        action=action,
        target_model=target_model,
        target_object_id=str(target_object_id) if target_object_id else "",
        description=description,
    )
