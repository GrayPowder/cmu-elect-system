"""Business operations for ballot submission."""

from django.db import transaction

from ..models import Election, Vote
from .audit_service import create_audit_log
from .eligibility_service import is_voter_eligible_for_election


class VotingServiceError(Exception):
    """A business-rule failure that the HTTP view converts into a response."""

    def __init__(self, detail, status_code):
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code


@transaction.atomic
def submit_ballot(*, user, validated_data):
    """Validate and persist a ballot atomically using the existing voting rules."""
    from rest_framework import status

    profile = getattr(user, "profile", None)
    if not profile or profile.account_status != "active" or not user.is_active:
        raise VotingServiceError(
            "This account is inactive. Please contact the administrator.",
            status.HTTP_403_FORBIDDEN,
        )

    try:
        election = (
            Election.objects
            .select_for_update()
            .prefetch_related("positions__candidates")
            .get(pk=validated_data["election_id"])
        )
    except Election.DoesNotExist:
        raise VotingServiceError("Election not found.", status.HTTP_404_NOT_FOUND)

    if election.schedule_status == "not_started":
        raise VotingServiceError(
            "Voting for this election has not started.",
            status.HTTP_400_BAD_REQUEST,
        )

    if not election.is_open:
        raise VotingServiceError(
            "Voting for this election has ended.",
            status.HTTP_400_BAD_REQUEST,
        )

    if not is_voter_eligible_for_election(user, election):
        raise VotingServiceError(
            "You are not eligible to vote in this election.",
            status.HTTP_403_FORBIDDEN,
        )

    position_map = {position.id: position for position in election.positions.all()}
    validated_choices = []

    for item in validated_data["votes"]:
        position = position_map.get(item["position_id"])
        if position is None:
            raise VotingServiceError("Invalid position.", status.HTTP_400_BAD_REQUEST)

        candidate = next(
            (
                candidate
                for candidate in position.candidates.all()
                if candidate.id == item["candidate_id"]
            ),
            None,
        )
        if candidate is None:
            raise VotingServiceError(
                "Invalid candidate selection.",
                status.HTTP_400_BAD_REQUEST,
            )

        validated_choices.append((position, candidate))

    position_ids = [position.id for position, _ in validated_choices]
    if Vote.objects.filter(
        voter=user,
        election=election,
        position_id__in=position_ids,
    ).exists():
        create_audit_log(
            actor=user,
            action="security_duplicate_vote_attempt",
            target_model="Election",
            target_object_id=election.id,
            description="A duplicate voting attempt was blocked.",
        )
        raise VotingServiceError(
            "You have already voted in this election.",
            status.HTTP_400_BAD_REQUEST,
        )

    created_votes = [
        Vote.objects.create(
            voter=user,
            election=election,
            position=position,
            candidate=candidate,
        )
        for position, candidate in validated_choices
    ]

    submitted_at = max(vote.created_at for vote in created_votes)
    create_audit_log(
        actor=user,
        action="vote_submitted",
        target_model="Election",
        target_object_id=election.id,
        description=(
            f"Voter submitted a ballot containing {len(created_votes)} position vote(s). "
            "Candidate choices are not stored in the audit description."
        ),
    )

    return {
        "detail": "Vote successfully submitted.",
        "election": {"id": election.id, "name": election.name},
        "submitted_at": submitted_at,
        "votes_created": len(created_votes),
    }
