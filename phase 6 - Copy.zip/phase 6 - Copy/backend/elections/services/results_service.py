"""Election-results calculation and access rules."""

from django.db.models import Count, Q
from rest_framework import status

from ..models import Election, Vote
from .eligibility_service import is_voter_in_election_scope


class ResultsServiceError(Exception):
    def __init__(self, detail, status_code):
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code


def get_results(*, user, election_id):
    try:
        election = Election.objects.get(pk=election_id)
    except Election.DoesNotExist:
        raise ResultsServiceError("Election not found.", status.HTTP_404_NOT_FOUND)

    if election.effective_status != Election.STATUS_ENDED:
        raise ResultsServiceError(
            "Election results are not available until the election has ended.",
            status.HTTP_403_FORBIDDEN,
        )

    is_admin = bool(user.is_staff and user.is_active)
    if not is_admin:
        profile = getattr(user, "profile", None)
        if not profile or profile.account_status != "active" or not user.is_active:
            raise ResultsServiceError("Active voter access is required.", status.HTTP_403_FORBIDDEN)
        if profile.must_change_password:
            raise ResultsServiceError(
                "You must change your password before viewing results.",
                status.HTTP_403_FORBIDDEN,
            )
        if not is_voter_in_election_scope(user, election):
            raise ResultsServiceError(
                "You are not eligible to view this election's results.",
                status.HTTP_403_FORBIDDEN,
            )

    total_votes = Vote.objects.filter(election=election).count()
    positions = election.positions.annotate(
        position_total=Count("votes", filter=Q(votes__election=election))
    ).prefetch_related("candidates")

    results = []
    for position in positions:
        candidates = list(
            position.candidates.annotate(
                vote_count=Count("votes", filter=Q(votes__election=election))
            ).order_by("name", "id")
        )
        position_total = position.position_total
        max_votes = max((candidate.vote_count for candidate in candidates), default=0)
        winners = [
            {
                "id": candidate.id,
                "candidate": candidate.name,
                "percentage": round((candidate.vote_count / position_total) * 100, 2) if position_total else 0.0,
            }
            for candidate in candidates
            if max_votes > 0 and candidate.vote_count == max_votes
        ]

        results.append({
            "position_id": position.id,
            "position": position.name,
            "total_votes": position_total,
            "winners": winners,
            "candidates": [
                {
                    "id": candidate.id,
                    "candidate": candidate.name,
                    "percentage": round((candidate.vote_count / position_total) * 100, 2) if position_total else 0.0,
                }
                for candidate in candidates
            ],
        })

    return {
        "election": {
            "id": election.id,
            "name": election.name,
            "status": election.effective_status,
        },
        "total_votes": total_votes,
        "results": results,
    }
