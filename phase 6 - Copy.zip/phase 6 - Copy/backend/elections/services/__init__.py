"""Domain service layer for the elections application."""
