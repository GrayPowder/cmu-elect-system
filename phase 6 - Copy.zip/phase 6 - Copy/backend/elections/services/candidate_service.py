"""Business operations for candidate management."""

from django.db import transaction

from ..models import Candidate
from .audit_service import create_audit_log


@transaction.atomic
def create_candidate(*, position, validated_data, actor):
    # remove_photo is a request-only serializer field and is not persisted.
    validated_data.pop("remove_photo", None)
    candidate = Candidate.objects.create(position=position, **validated_data)
    create_audit_log(
        actor=actor,
        action="candidate_created",
        target_model="Candidate",
        target_object_id=candidate.id,
        description="Candidate was created.",
    )
    return candidate


@transaction.atomic
def update_candidate(*, candidate, validated_data, actor):
    remove_photo = validated_data.pop("remove_photo", False)
    if remove_photo:
        if candidate.photo:
            candidate.photo.delete(save=False)
        candidate.photo = None

    for field, value in validated_data.items():
        setattr(candidate, field, value)
    candidate.save()
    create_audit_log(
        actor=actor,
        action="candidate_modified",
        target_model="Candidate",
        target_object_id=candidate.id,
        description="Candidate was modified.",
    )
    return candidate


@transaction.atomic
def delete_candidate(*, candidate, actor):
    candidate_id = candidate.id
    candidate.delete()
    create_audit_log(
        actor=actor,
        action="candidate_deleted",
        target_model="Candidate",
        target_object_id=candidate_id,
        description="Candidate was deleted.",
    )
