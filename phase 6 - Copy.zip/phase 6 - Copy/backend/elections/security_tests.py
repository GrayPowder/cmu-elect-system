from django.contrib.auth.models import User
from django.test import TestCase
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APIClient
from rest_framework.authtoken.models import Token

from .admin import AuditLogAdmin, PasswordResetRequestAdmin, VoteAdmin
from .models import AuditLog, Election, PasswordResetRequest, Profile, Vote


class Phase9SecurityRegressionTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin = User.objects.create_user(
            username="security-admin",
            email="security-admin@cmu.edu",
            password="AdminPass123!",
            is_staff=True,
        )
        self.student = User.objects.create_user(
            username="security-student",
            email="security-student@cmu.edu",
            password="StudentPass123!",
        )
        Profile.objects.create(
            user=self.student,
            role="student",
            cmu_email=self.student.email,
            full_name="Security Student",
            must_change_password=False,
        )

    def test_non_staff_user_without_profile_cannot_enter_unified_login(self):
        user = User.objects.create_user(
            username="orphan-user",
            email="orphan@cmu.edu",
            password="OrphanPass123!",
        )
        response = self.client.post(
            "/api/auth/login/",
            {"email": user.email, "password": "OrphanPass123!"},
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertNotIn("token", response.data)

    def test_voter_login_rotates_existing_token(self):
        old_token = Token.objects.create(user=self.student)
        response = self.client.post(
            "/api/auth/login/",
            {"email": self.student.email, "password": "StudentPass123!"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotEqual(response.data["token"], old_token.key)
        self.assertFalse(Token.objects.filter(key=old_token.key).exists())

    def test_reset_token_is_single_use(self):
        from .services.authentication import request_password_reset, verify_reset_code, reset_password

        sent = {}
        request_password_reset(email=self.student.email, send_code=lambda email, code: sent.update(code=code))
        token, error = verify_reset_code(email=self.student.email, code=sent["code"])
        self.assertIsNone(error)
        self.assertIsNotNone(token)
        self.assertIsNone(reset_password(email=self.student.email, reset_token=token, password="NewSecurePass123!"))
        self.assertIsNotNone(reset_password(email=self.student.email, reset_token=token, password="AnotherSecurePass123!"))

    def test_sensitive_django_admin_records_are_read_only(self):
        request = type("Request", (), {})()
        vote_admin = VoteAdmin(Vote, None)
        audit_admin = AuditLogAdmin(AuditLog, None)
        reset_admin = PasswordResetRequestAdmin(PasswordResetRequest, None)
        self.assertFalse(vote_admin.has_add_permission(request))
        self.assertFalse(vote_admin.has_change_permission(request))
        self.assertFalse(vote_admin.has_delete_permission(request))
        self.assertFalse(audit_admin.has_add_permission(request))
        self.assertFalse(audit_admin.has_change_permission(request))
        self.assertFalse(audit_admin.has_delete_permission(request))
        self.assertFalse(reset_admin.has_add_permission(request))
        self.assertFalse(reset_admin.has_change_permission(request))
        self.assertFalse(reset_admin.has_delete_permission(request))

    def test_all_voter_roles_are_denied_admin_api(self):
        election = Election.objects.create(
            name="Security Election",
            eligible_voter_category="student",
            start_datetime=timezone.now(),
            end_datetime=timezone.now() + timedelta(hours=1),
        )
        for role in ("student", "alumni", "faculty"):
            user = User.objects.create_user(
                username=f"security-{role}",
                email=f"security-{role}@cmu.edu",
                password="VoterPass123!",
            )
            Profile.objects.create(
                user=user,
                role=role,
                cmu_email=user.email,
                full_name=f"Security {role.title()}",
                must_change_password=False,
            )
            self.client.force_authenticate(user=user)
            response = self.client.get("/api/admin/dashboard/")
            self.assertEqual(response.status_code, 403)
        self.assertIsNotNone(election)
