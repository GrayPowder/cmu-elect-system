from django.contrib import admin

from .models import Profile, Election, Position, Candidate, Vote, AuditLog, PasswordResetRequest


class ReadOnlyAdmin(admin.ModelAdmin):
    """Expose sensitive records for inspection without allowing mutation in Django admin."""

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class VoteAdmin(ReadOnlyAdmin):
    list_display = ("id", "voter", "election", "position", "candidate", "created_at")
    list_select_related = ("voter", "election", "position", "candidate")
    readonly_fields = ("voter", "election", "position", "candidate", "created_at")


class AuditLogAdmin(ReadOnlyAdmin):
    list_display = ("id", "timestamp", "actor", "action", "target_model", "target_object_id")
    list_select_related = ("actor",)
    readonly_fields = (
        "actor",
        "action",
        "timestamp",
        "target_model",
        "target_object_id",
        "description",
    )


class PasswordResetRequestAdmin(ReadOnlyAdmin):
    list_display = ("id", "email", "expires_at", "verified_at", "used_at", "attempts", "created_at")
    readonly_fields = (
        "email",
        "code_hash",
        "reset_token_hash",
        "expires_at",
        "verified_at",
        "used_at",
        "attempts",
        "created_at",
    )


admin.site.register(Profile)
admin.site.register(Election)
admin.site.register(Position)
admin.site.register(Candidate)
admin.site.register(Vote, VoteAdmin)
admin.site.register(AuditLog, AuditLogAdmin)
admin.site.register(PasswordResetRequest, PasswordResetRequestAdmin)
