from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser

from ..models import Election, Position, Candidate
from ..permissions import IsAdministrator
from ..serializers import AdminCandidateSerializer
from ..services.candidate_service import create_candidate, delete_candidate, update_candidate


# Administrator candidate-management views.

class AdminCandidateListCreateView(APIView):
    permission_classes = [IsAdministrator]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get_context(self, election_id, position_id):
        try:
            election = Election.objects.get(pk=election_id)
        except Election.DoesNotExist:
            return None, None, Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        try:
            position = Position.objects.get(pk=position_id)
        except Position.DoesNotExist:
            return None, None, Response({"detail": "Position not found."}, status=status.HTTP_404_NOT_FOUND)

        if position.election_id != election.id:
            return None, None, Response(
                {"detail": "Position does not belong to this election."},
                status=status.HTTP_404_NOT_FOUND,
            )
        return election, position, None

    def get(self, request, election_id, position_id):
        _, position, error = self.get_context(election_id, position_id)
        if error:
            return error
        candidates = position.candidates.all().order_by("id")
        return Response(AdminCandidateSerializer(candidates, many=True).data)

    def post(self, request, election_id, position_id):
        _, position, error = self.get_context(election_id, position_id)
        if error:
            return error
        serializer = AdminCandidateSerializer(
            data=request.data, context={"request": request, "position": position}
        )
        serializer.is_valid(raise_exception=True)
        candidate = create_candidate(
            position=position,
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(AdminCandidateSerializer(candidate).data, status=status.HTTP_201_CREATED)


class AdminCandidateDetailView(APIView):
    permission_classes = [IsAdministrator]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get_candidate(self, candidate_id):
        return Candidate.objects.select_related("position", "position__election").get(pk=candidate_id)

    def get(self, request, candidate_id):
        try:
            candidate = self.get_candidate(candidate_id)
        except Candidate.DoesNotExist:
            return Response({"detail": "Candidate not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(AdminCandidateSerializer(candidate).data)

    def patch(self, request, candidate_id):
        try:
            candidate = self.get_candidate(candidate_id)
        except Candidate.DoesNotExist:
            return Response({"detail": "Candidate not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = AdminCandidateSerializer(
            candidate, data=request.data, partial=True,
            context={"request": request, "position": candidate.position}
        )
        serializer.is_valid(raise_exception=True)
        candidate = update_candidate(
            candidate=candidate,
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(AdminCandidateSerializer(candidate).data)

    def delete(self, request, candidate_id):
        try:
            candidate = self.get_candidate(candidate_id)
        except Candidate.DoesNotExist:
            return Response({"detail": "Candidate not found."}, status=status.HTTP_404_NOT_FOUND)

        delete_candidate(candidate=candidate, actor=request.user)
        return Response(status=status.HTTP_204_NO_CONTENT)
