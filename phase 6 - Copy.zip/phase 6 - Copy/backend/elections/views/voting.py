from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from ..permissions import IsAuthenticatedAndPasswordChanged
from ..serializers import BallotSubmissionSerializer
from ..services.voting_service import VotingServiceError, submit_ballot


# Ballot submission views.

class VoteView(APIView):
    """Coordinate HTTP validation/response handling for ballot submission."""

    permission_classes = [IsAuthenticatedAndPasswordChanged]

    def post(self, request):
        serializer = BallotSubmissionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            result = submit_ballot(
                user=request.user,
                validated_data=serializer.validated_data,
            )
        except VotingServiceError as exc:
            return Response({"detail": exc.detail}, status=exc.status_code)

        return Response(result, status=status.HTTP_201_CREATED)
