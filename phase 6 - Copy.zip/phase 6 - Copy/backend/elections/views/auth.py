import sys

from rest_framework import status
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from ..serializers import LoginSerializer, AdminLoginSerializer, ChangePasswordSerializer
from ..services.authentication import (
    change_password,
    create_admin_login_session,
    create_login_session,
    get_current_user_data,
    logout_user,
    request_password_reset,
    reset_password,
    verify_reset_code,
)
from ..services.audit_service import create_audit_log
from .common import build_login_response, send_reset_code


# Authentication and password-recovery views.

class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError:
            create_audit_log(actor=None, action="security_login_failure", target_model="Authentication", description="A login attempt failed.")
            raise

        user = serializer.validated_data["user"]
        token = create_login_session(user=user)
        return Response({"token": token.key, "user": build_login_response(user)})


class AdminLoginView(APIView):
    """Backward-compatible admin endpoint; the frontend now uses LoginView."""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = AdminLoginSerializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError:
            create_audit_log(actor=None, action="security_admin_login_failure", target_model="Authentication", description="An administrator login attempt failed.")
            raise

        user = serializer.validated_data["user"]
        token = create_admin_login_session(user=user)
        return Response({"token": token.key, "user": build_login_response(user)})


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        logout_user(user=request.user)
        return Response({"detail": "Logged out."})


class MeView(APIView):
    def get(self, request):
        data, error = get_current_user_data(user=request.user)
        if error:
            detail, status_code = error
            return Response({"detail": detail}, status=status_code)
        return Response(data)


class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        profile = request.user.profile
        if profile.account_status != "active" or not request.user.is_active:
            return Response({"detail": "This account is inactive. Please contact the administrator."}, status=status.HTTP_403_FORBIDDEN)

        serializer = ChangePasswordSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        new_token = change_password(
            user=request.user,
            new_password=serializer.validated_data["new_password"],
        )

        return Response({
            "detail": "Password changed successfully.",
            "token": new_token.key,
            "must_change_password": False,
        })


class ForgotPasswordView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = str(request.data.get("email", "")).strip().lower()
        if not email:
            return Response({"detail": "Please enter your CMU email."}, status=400)

        # Keep the package-level hook so existing tests and integrations can
        # replace the mail sender without coupling the service to the view.
        facade = sys.modules.get(__package__)
        mail_sender = getattr(facade, "send_reset_code", send_reset_code)
        response = request_password_reset(email=email, send_code=mail_sender)
        return Response(response)


class VerifyResetCodeView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = str(request.data.get("email", "")).strip().lower()
        code = str(request.data.get("code", "")).strip()
        if not email or not code:
            return Response({"detail": "Email and verification code are required."}, status=400)

        token, error = verify_reset_code(email=email, code=code)
        if error:
            detail, status_code = error
            return Response({"detail": detail}, status=status_code)
        return Response({"detail": "Code verified.", "reset_token": token})


class ResendResetCodeView(ForgotPasswordView):
    pass


class ResetPasswordView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = str(request.data.get("email", "")).strip().lower()
        reset_token = str(request.data.get("reset_token", "")).strip()
        password = str(request.data.get("password", ""))
        confirm_password = str(request.data.get("confirm_password", ""))

        if not all([email, reset_token, password, confirm_password]):
            return Response({"detail": "All fields are required."}, status=400)
        if password != confirm_password:
            return Response({"detail": "Passwords do not match."}, status=400)
        if len(password) < 8:
            return Response({"detail": "Password must be at least 8 characters."}, status=400)

        error = reset_password(email=email, reset_token=reset_token, password=password)
        if error:
            detail, status_code = error
            return Response({"detail": detail}, status=status_code)
        return Response({"detail": "Password changed successfully."})
