from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView


class HealthCheckView(APIView):
    """Minimal public endpoint used to verify that the API is reachable."""

    permission_classes = [AllowAny]

    def get(self, request):
        return Response({"status": "ok", "service": "cmu-elect-api"})
