from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

from ..services.results_service import ResultsServiceError, get_results


# Final election results views.

class ResultsView(APIView):
    """Coordinate HTTP access and response handling for final results."""
    permission_classes = [IsAuthenticated]

    def get(self, request, election_id):
        try:
            result = get_results(user=request.user, election_id=election_id)
        except ResultsServiceError as exc:
                        return Response({"detail": exc.detail}, status=exc.status_code)
        return Response(result)
