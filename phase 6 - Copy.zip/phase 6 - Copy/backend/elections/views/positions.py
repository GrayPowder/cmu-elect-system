from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import Election, Position
from ..permissions import IsAdministrator
from ..serializers import AdminPositionSerializer
from ..services.election_service import create_position, delete_position, update_position


# Administrator position-management views.

class AdminPositionListCreateView(APIView):
    permission_classes = [IsAdministrator]

    def get_election(self, election_id):
        return Election.objects.get(pk=election_id)

    def get(self, request, election_id):
        try:
            election = self.get_election(election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        positions = election.positions.all().order_by("order", "id")
        return Response(AdminPositionSerializer(positions, many=True).data)

    def post(self, request, election_id):
        try:
            election = self.get_election(election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = AdminPositionSerializer(
            data=request.data, context={"request": request, "election": election}
        )
        serializer.is_valid(raise_exception=True)
        position = create_position(
            election=election,
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(AdminPositionSerializer(position).data, status=status.HTTP_201_CREATED)


class AdminPositionDetailView(APIView):
    permission_classes = [IsAdministrator]

    def get_position(self, position_id):
        return Position.objects.select_related("election").get(pk=position_id)

    def get(self, request, position_id):
        try:
            position = self.get_position(position_id)
        except Position.DoesNotExist:
            return Response({"detail": "Position not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(AdminPositionSerializer(position).data)

    def patch(self, request, position_id):
        try:
            position = self.get_position(position_id)
        except Position.DoesNotExist:
            return Response({"detail": "Position not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = AdminPositionSerializer(
            position, data=request.data, partial=True,
            context={"request": request, "election": position.election}
        )
        serializer.is_valid(raise_exception=True)
        position = update_position(
            position=position,
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(AdminPositionSerializer(position).data)

    def delete(self, request, position_id):
        try:
            position = self.get_position(position_id)
        except Position.DoesNotExist:
            return Response({"detail": "Position not found."}, status=status.HTTP_404_NOT_FOUND)

        delete_position(position=position, actor=request.user)
        return Response(status=status.HTTP_204_NO_CONTENT)
