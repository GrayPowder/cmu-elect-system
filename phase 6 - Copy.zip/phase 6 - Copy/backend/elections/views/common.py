"""Compatibility facade for helpers historically exposed by ``elections.views``."""

from ..services.audit_service import create_audit_log
from ..services.common import hash_value, create_reset_code, send_reset_code


def build_login_response(user):
    is_admin = bool(user.is_staff and user.is_active)
    profile = getattr(user, "profile", None)

    return {
        "id": user.id,
        "username": user.username,
        "email": profile.cmu_email if profile else user.email,
        "is_admin": is_admin,
        "role": profile.role if profile and not is_admin else None,
        "must_change_password": profile.must_change_password if profile and not is_admin else False,
    }
