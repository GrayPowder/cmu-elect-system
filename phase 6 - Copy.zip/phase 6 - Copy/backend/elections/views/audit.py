from django.db.models import Q
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import AuditLog
from ..permissions import IsAdministrator
from ..serializers import AuditLogSerializer


# Administrator audit-log views.

class AdminAuditLogListView(APIView):
    permission_classes = [IsAdministrator]

    def get(self, request):
        queryset = AuditLog.objects.select_related("actor").all()
        search = str(request.query_params.get("search", "")).strip()
        action = str(request.query_params.get("action", "")).strip()
        target_model = str(request.query_params.get("target_model", "")).strip()
        sort = str(request.query_params.get("sort", "desc")).strip().lower()
        if search:
            queryset = queryset.filter(Q(action__icontains=search) | Q(description__icontains=search) | Q(target_model__icontains=search) | Q(target_object_id__icontains=search) | Q(actor__username__icontains=search))
        if action: queryset = queryset.filter(action=action)
        if target_model: queryset = queryset.filter(target_model=target_model)
        queryset = queryset.order_by("timestamp", "id") if sort == "asc" else queryset.order_by("-timestamp", "-id")
        return Response({
            "logs": AuditLogSerializer(queryset[:500], many=True).data,
            "actions": list(AuditLog.objects.order_by("action").values_list("action", flat=True).distinct()),
            "target_models": list(AuditLog.objects.exclude(target_model="").order_by("target_model").values_list("target_model", flat=True).distinct()),
        })
