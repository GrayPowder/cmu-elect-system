from rest_framework import serializers

from ..models import Candidate


class CandidateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Candidate
        fields = ["id", "name", "department", "platform", "gwa", "party_list", "photo"]


class AdminCandidateSerializer(serializers.ModelSerializer):
    election_id = serializers.IntegerField(source="position.election.id", read_only=True)
    position_id = serializers.IntegerField(source="position.id", read_only=True)
    remove_photo = serializers.BooleanField(required=False, default=False, write_only=True)

    class Meta:
        model = Candidate
        fields = [
            "id", "election_id", "position_id", "name", "party_list",
            "platform", "photo", "remove_photo",
        ]
        read_only_fields = ["id", "election_id", "position_id"]

    def create(self, validated_data):
        validated_data.pop("remove_photo", None)
        return Candidate.objects.create(**validated_data)

    def update(self, instance, validated_data):
        remove_photo = validated_data.pop("remove_photo", False)
        if remove_photo:
            if instance.photo:
                instance.photo.delete(save=False)
            instance.photo = None
        return super().update(instance, validated_data)
