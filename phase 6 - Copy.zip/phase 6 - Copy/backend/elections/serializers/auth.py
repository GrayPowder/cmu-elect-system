from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from ..models import Profile


class LoginSerializer(serializers.Serializer):
    # Keep the existing request field name for API compatibility while allowing
    # either a CMU email or login identifier/username.
    email = serializers.CharField()
    password = serializers.CharField(write_only=True)
    # Optional UI role selection. Authentication still uses the actual account.
    role = serializers.ChoiceField(choices=["student", "alumni", "faculty"], required=False)

    def validate(self, attrs):
        identifier = attrs["email"].strip()
        if not identifier:
            raise serializers.ValidationError("Invalid CMU email or password.")

        user = None
        profile = None

        try:
            profile = Profile.objects.select_related("user").get(cmu_email__iexact=identifier)
            user = profile.user
        except Profile.DoesNotExist:
            try:
                profile = Profile.objects.select_related("user").get(user__username__iexact=identifier)
                user = profile.user
            except Profile.DoesNotExist:
                user = User.objects.filter(email__iexact=identifier).first()
                if user is None:
                    user = User.objects.filter(username__iexact=identifier).first()
                if user is not None:
                    profile = getattr(user, "profile", None)

        if user is None or not user.is_active:
            raise serializers.ValidationError("Invalid CMU email or password.")

        # Non-staff accounts must have a CMU Profile. This prevents a regular
        # Django User record without voter identity/role data from entering the
        # unified application session. Staff administrators are handled by the
        # backend is_staff check and do not require a voter Profile.
        if not user.is_staff and profile is None:
            raise serializers.ValidationError("Invalid CMU email or password.")

        if profile is not None and profile.account_status != "active":
            raise serializers.ValidationError("This account is inactive. Please contact the administrator.")

        authenticated_user = authenticate(username=user.username, password=attrs["password"])
        if not authenticated_user:
            raise serializers.ValidationError("Invalid CMU email or password.")

        # The selected role is only an additional consistency check for voter
        # accounts. Admin status is still determined exclusively by is_staff.
        selected_role = attrs.get("role")
        if selected_role and not authenticated_user.is_staff:
            authenticated_profile = getattr(authenticated_user, "profile", None)
            if authenticated_profile is None or authenticated_profile.role != selected_role:
                raise serializers.ValidationError("The selected account type does not match your account.")

        attrs["user"] = authenticated_user
        return attrs


class AdminLoginSerializer(LoginSerializer):
    def validate(self, attrs):
        attrs = super().validate(attrs)
        user = attrs["user"]
        if not user.is_staff:
            raise serializers.ValidationError("Invalid administrator email or password.")
        return attrs


class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = self.context["request"].user

        if not user.check_password(attrs["current_password"]):
            raise serializers.ValidationError({"current_password": "Current password is incorrect."})

        if attrs["new_password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})

        if attrs["current_password"] == attrs["new_password"]:
            raise serializers.ValidationError({"new_password": "New password must be different from your current password."})

        validate_password(attrs["new_password"], user=user)
        return attrs
