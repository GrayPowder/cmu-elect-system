from rest_framework import serializers

from ..models import Department


class DepartmentSerializer(serializers.ModelSerializer):
    status = serializers.SerializerMethodField()

    class Meta:
        model = Department
        fields = [
            "id",
            "code",
            "name",
            "is_active",
            "status",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "status", "created_at", "updated_at"]

    def validate_code(self, value):
        value = str(value).strip()
        if not value:
            raise serializers.ValidationError("Department code cannot be empty.")
        queryset = Department.objects.filter(code__iexact=value)
        if self.instance is not None:
            queryset = queryset.exclude(pk=self.instance.pk)
        if queryset.exists():
            raise serializers.ValidationError("A department with this code already exists.")
        return value

    def validate_name(self, value):
        value = str(value).strip()
        if not value:
            raise serializers.ValidationError("Department name cannot be empty.")
        return value

    def validate(self, attrs):
        code = attrs.get("code", getattr(self.instance, "code", ""))
        name = attrs.get("name", getattr(self.instance, "name", ""))
        if not str(code).strip():
            raise serializers.ValidationError({"code": "Department code cannot be empty."})
        if not str(name).strip():
            raise serializers.ValidationError({"name": "Department name cannot be empty."})
        return attrs

    def get_status(self, obj):
        return "active" if obj.is_active else "inactive"
