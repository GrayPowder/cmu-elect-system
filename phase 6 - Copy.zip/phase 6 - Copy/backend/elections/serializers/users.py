from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from ..models import Department, Profile, VOTER_CATEGORY_CHOICES


def _normalize_identifier(value):
    value = value.strip()
    if not value:
        raise serializers.ValidationError("Login identifier is required.")
    return value


def _normalize_email(value):
    return value.strip().lower()


def _validate_name(value):
    value = value.strip()
    if not value:
        raise serializers.ValidationError("Name is required.")
    return value


class VoterSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(source="full_name")
    identifier = serializers.CharField(source="user.username")
    email = serializers.EmailField(source="cmu_email")
    category = serializers.ChoiceField(source="role", choices=VOTER_CATEGORY_CHOICES)
    status = serializers.ChoiceField(source="account_status", choices=Profile.ACCOUNT_STATUS_CHOICES)
    department = serializers.PrimaryKeyRelatedField(
        queryset=Department.objects.filter(is_active=True),
        allow_null=True,
        required=False,
    )
    created_date = serializers.DateTimeField(source="created_at", read_only=True)

    class Meta:
        model = Profile
        fields = ["id", "name", "identifier", "email", "category", "department", "status", "created_date"]
        read_only_fields = ["id", "created_date"]

    def validate_identifier(self, value):
        value = _normalize_identifier(value)
        queryset = User.objects.filter(username__iexact=value)
        current_user = getattr(self.instance, "user", None)
        if current_user:
            queryset = queryset.exclude(pk=current_user.pk)
        if queryset.exists():
            raise serializers.ValidationError("That login identifier is already in use.")
        return value

    def validate_email(self, value):
        value = _normalize_email(value)
        queryset = Profile.objects.filter(cmu_email__iexact=value)
        if self.instance:
            queryset = queryset.exclude(pk=self.instance.pk)
        user_queryset = User.objects.filter(email__iexact=value)
        current_user = getattr(self.instance, "user", None)
        if current_user:
            user_queryset = user_queryset.exclude(pk=current_user.pk)
        if queryset.exists() or user_queryset.exists():
            raise serializers.ValidationError("That email address is already assigned to another account.")
        return value

    def validate_name(self, value):
        return _validate_name(value)

    def validate_department(self, value):
        if value is not None and not value.is_active:
            raise serializers.ValidationError("Inactive departments cannot be newly assigned to voters.")
        return value

    def update(self, instance, validated_data):
        user_data = validated_data.pop("user", {})
        new_identifier = user_data.get("username")
        if new_identifier is not None:
            instance.user.username = new_identifier.strip()

        new_email = validated_data.get("cmu_email")
        if new_email is not None:
            instance.user.email = new_email.strip().lower()

        if "account_status" in validated_data:
            new_status = validated_data["account_status"]
            instance.user.is_active = new_status == "active"

        instance.user.save(update_fields=["username", "email", "is_active"])
        return super().update(instance, validated_data)


class VoterCreateSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=150)
    identifier = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    category = serializers.ChoiceField(choices=VOTER_CATEGORY_CHOICES)
    department = serializers.PrimaryKeyRelatedField(
        queryset=Department.objects.filter(is_active=True),
    )
    password = serializers.CharField(write_only=True, min_length=8)
    status = serializers.ChoiceField(choices=Profile.ACCOUNT_STATUS_CHOICES, default="active")

    def validate_identifier(self, value):
        value = _normalize_identifier(value)
        if User.objects.filter(username__iexact=value).exists():
            raise serializers.ValidationError("That login identifier is already in use.")
        return value

    def validate_email(self, value):
        value = _normalize_email(value)
        if Profile.objects.filter(cmu_email__iexact=value).exists() or User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("That email address is already assigned to another account.")
        return value

    def validate_name(self, value):
        return _validate_name(value)

    def validate_department(self, value):
        if value is not None and not value.is_active:
            raise serializers.ValidationError("Inactive departments cannot be newly assigned to voters.")
        return value

    def validate_password(self, value):
        validate_password(value)
        return value

    def create(self, validated_data):
        password = validated_data.pop("password")
        identifier = validated_data.pop("identifier")
        email = validated_data.pop("email")
        status_value = validated_data.pop("status")

        user = User.objects.create_user(
            username=identifier,
            email=email,
            password=password,
            is_active=status_value == "active",
        )
        return Profile.objects.create(
            user=user,
            full_name=validated_data["name"],
            cmu_email=email,
            role=validated_data["category"],
            department=validated_data.get("department"),
            account_status=status_value,
            must_change_password=True,
        )


class VoterPasswordResetSerializer(serializers.Serializer):
    password = serializers.CharField(write_only=True, min_length=8)
    confirm_password = serializers.CharField(write_only=True, min_length=8)

    def validate(self, attrs):
        if attrs["password"] != attrs["confirm_password"]:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        validate_password(attrs["password"])
        return attrs
