"""Serializer module reserved for analytics-specific representations.

The current analytics endpoints return explicitly constructed response payloads,
so there are no DRF serializer classes to move here in Phase 7.
"""
