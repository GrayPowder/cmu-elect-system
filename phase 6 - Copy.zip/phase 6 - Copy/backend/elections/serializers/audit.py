from rest_framework import serializers

from ..models import AuditLog


class AuditLogSerializer(serializers.ModelSerializer):
    actor = serializers.SerializerMethodField()

    class Meta:
        model = AuditLog
        fields = ["id", "actor", "action", "timestamp", "target_model", "target_object_id", "description"]

    def get_actor(self, obj):
        return obj.actor.get_username() if obj.actor else "System"
