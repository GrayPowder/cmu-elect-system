from rest_framework import serializers

from ..models import Department, Election, Position, VOTER_CATEGORY_CHOICES
from .candidates import CandidateSerializer


class PositionSerializer(serializers.ModelSerializer):
    candidates = CandidateSerializer(many=True, read_only=True)

    class Meta:
        model = Position
        fields = ["id", "name", "order", "candidates"]


class AdminPositionSerializer(serializers.ModelSerializer):
    election_id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=80, required=True, allow_blank=False, trim_whitespace=True)

    class Meta:
        model = Position
        fields = ["id", "election_id", "name", "order"]
        read_only_fields = ["id", "election_id"]

    def validate_name(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Position name cannot be empty or contain only spaces.")
        return value

    def validate_order(self, value):
        if value < 0:
            raise serializers.ValidationError("Position order cannot be negative.")
        return value

    def validate(self, attrs):
        election = self.context.get("election")
        name = attrs.get("name", getattr(self.instance, "name", "")).strip()
        if not name:
            raise serializers.ValidationError({"name": "Position name cannot be empty or contain only spaces."})
        if election and Position.objects.filter(
            election=election, name__iexact=name
        ).exclude(pk=getattr(self.instance, "pk", None)).exists():
            raise serializers.ValidationError({"name": "A position with this name already exists in this election."})
        return attrs


class ElectionSerializer(serializers.ModelSerializer):
    """Voter-facing election representation, including backend-provided eligibility scope."""
    audience = serializers.CharField(source="eligible_voter_category", read_only=True)
    eligible_voter_category_display = serializers.CharField(
        source="get_eligible_voter_category_display", read_only=True
    )
    department_scope = serializers.CharField(read_only=True)
    eligible_departments = serializers.PrimaryKeyRelatedField(many=True, read_only=True)
    eligible_department_details = serializers.SerializerMethodField()
    is_open = serializers.BooleanField(read_only=True)
    status = serializers.CharField(source="schedule_status", read_only=True)
    voting_availability = serializers.SerializerMethodField()
    positions = PositionSerializer(many=True, read_only=True)

    class Meta:
        model = Election
        fields = [
            "id", "name", "description", "audience", "eligible_voter_category_display",
            "department_scope", "eligible_departments", "eligible_department_details",
            "start_datetime", "end_datetime", "status", "is_open",
            "voting_availability", "positions",
        ]

    def get_eligible_department_details(self, obj):
        return [
            {"id": department.id, "code": department.code, "name": department.name}
            for department in obj.eligible_departments.all()
        ]

    def get_voting_availability(self, obj):
        if obj.schedule_status == "not_started":
            return "not_started"
        if obj.schedule_status == Election.STATUS_ENDED:
            return "ended"
        if obj.is_open:
            return "available"
        return "unavailable"


class AdminElectionSerializer(serializers.ModelSerializer):
    name = serializers.CharField(max_length=120, required=True, allow_blank=False, trim_whitespace=True)
    eligible_voter_category = serializers.ChoiceField(choices=VOTER_CATEGORY_CHOICES)
    department_scope = serializers.ChoiceField(choices=Election.DEPARTMENT_SCOPE_CHOICES, required=False)
    eligible_departments = serializers.PrimaryKeyRelatedField(
        many=True,
        queryset=Department.objects.filter(is_active=True),
        required=False,
    )
    status = serializers.SerializerMethodField()
    is_open = serializers.BooleanField(read_only=True)
    created_date = serializers.DateTimeField(source="created_at", read_only=True)

    class Meta:
        model = Election
        fields = [
            "id", "name", "description", "start_datetime", "end_datetime",
            "eligible_voter_category", "department_scope", "eligible_departments",
            "status", "is_open", "created_date",
        ]
        read_only_fields = ["id", "status", "is_open", "created_date"]

    def validate_name(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Election name cannot be empty or contain only spaces.")
        return value

    def validate(self, attrs):
        start = attrs.get("start_datetime", getattr(self.instance, "start_datetime", None))
        end = attrs.get("end_datetime", getattr(self.instance, "end_datetime", None))
        if start and end and start >= end:
            raise serializers.ValidationError({"end_datetime": "Election end date/time must be after the start date/time."})

        scope = attrs.get("department_scope", getattr(self.instance, "department_scope", Election.DEPARTMENT_SCOPE_ALL))
        if scope == Election.DEPARTMENT_SCOPE_SPECIFIC:
            departments = attrs.get("eligible_departments")
            if departments is None and self.instance is not None:
                has_departments = self.instance.eligible_departments.exists()
            else:
                has_departments = bool(departments)
            if not has_departments:
                raise serializers.ValidationError({
                    "eligible_departments": "At least one department is required when department scope is Specific Departments."
                })
        elif scope == Election.DEPARTMENT_SCOPE_ALL and attrs.get("eligible_departments"):
            raise serializers.ValidationError({
                "eligible_departments": "Specific departments must be empty when department scope is All Departments."
            })
        return attrs

    def get_status(self, obj):
        return obj.effective_status
