from rest_framework import serializers


class BallotItemSerializer(serializers.Serializer):
    position_id = serializers.IntegerField(min_value=1)
    candidate_id = serializers.IntegerField(min_value=1)


class BallotSubmissionSerializer(serializers.Serializer):
    election_id = serializers.IntegerField(min_value=1)
    votes = BallotItemSerializer(many=True, allow_empty=False)

    def validate_votes(self, value):
        position_ids = [item["position_id"] for item in value]
        if len(position_ids) != len(set(position_ids)):
            raise serializers.ValidationError("Only one candidate may be selected for each position.")
        return value


class VoteSerializer(serializers.Serializer):
    position_id = serializers.IntegerField()
    candidate_id = serializers.IntegerField()
