"""Serializer module reserved for results-specific representations.

The current results endpoint returns an explicitly constructed response payload,
so there are no DRF serializer classes to move here in Phase 7.
"""
