from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("elections", "0004_department_foundation"),
    ]

    operations = [
        migrations.AddField(
            model_name="election",
            name="department_scope",
            field=models.CharField(
                choices=[("all", "All Departments"), ("specific", "Specific Departments")],
                db_index=True,
                default="all",
                max_length=10,
            ),
        ),
        migrations.AddField(
            model_name="election",
            name="eligible_departments",
            field=models.ManyToManyField(
                blank=True,
                related_name="eligible_elections",
                to="elections.department",
            ),
        ),
    ]
