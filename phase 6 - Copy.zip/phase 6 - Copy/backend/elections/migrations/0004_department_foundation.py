from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("elections", "0003_alter_profile_role"),
    ]

    operations = [
        migrations.CreateModel(
            name="Department",
            fields=[
                (
                    "id",
                    models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID"),
                ),
                ("code", models.CharField(max_length=20, unique=True)),
                ("name", models.CharField(max_length=150)),
                ("is_active", models.BooleanField(db_index=True, default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AddField(
            model_name="profile",
            name="department",
            field=models.ForeignKey(
                blank=True,
                help_text="Optional department for existing accounts; required by future department-scoped features.",
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="profiles",
                to="elections.department",
            ),
        ),
    ]
