import os

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

from django.core.asgi import get_asgi_application

django_application = get_asgi_application()

from channels.routing import ProtocolTypeRouter, URLRouter
from elections.middleware import TokenAuthMiddleware
from elections.routing import websocket_urlpatterns


application = ProtocolTypeRouter({
    "http": django_application,

    "websocket": TokenAuthMiddleware(
        URLRouter(websocket_urlpatterns)
    ),
})