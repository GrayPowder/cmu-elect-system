from django.urls import path

from .consumers import AnalyticsConsumer


websocket_urlpatterns = [
    path(
        "ws/analytics/<int:election_id>/",
        AnalyticsConsumer.as_asgi(),
    ),
]