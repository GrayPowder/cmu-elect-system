from django.contrib.auth.models import User
from django.test import TestCase
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APIClient
from rest_framework.authtoken.models import Token

from .admin import AuditLogAdmin, PasswordResetRequestAdmin, VoteAdmin
from .models import AuditLog, Election, PasswordResetRequest, Profile, Vote


class Phase9SecurityRegressionTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin = User.objects.create_user(
            username="security-admin",
            email="security-admin@cmu.edu",
            password="AdminPass123!",
            is_staff=True,
        )
        self.student = User.objects.create_user(
            username="security-student",
            email="security-student@cmu.edu",
            password="StudentPass123!",
        )
        Profile.objects.create(
            user=self.student,
            role="student",
            cmu_email=self.student.email,
            full_name="Security Student",
            must_change_password=False,
        )

    def test_non_staff_user_without_profile_cannot_enter_unified_login(self):
        user = User.objects.create_user(
            username="orphan-user",
            email="orphan@cmu.edu",
            password="OrphanPass123!",
        )
        response = self.client.post(
            "/api/auth/login/",
            {"email": user.email, "password": "OrphanPass123!"},
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertNotIn("token", response.data)

    def test_voter_login_rotates_existing_token(self):
        old_token = Token.objects.create(user=self.student)
        response = self.client.post(
            "/api/auth/login/",
            {"email": self.student.email, "password": "StudentPass123!"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotEqual(response.data["token"], old_token.key)
        self.assertFalse(Token.objects.filter(key=old_token.key).exists())

    def test_admin_password_reset_uses_direct_link_without_otp(self):
        from .services.authentication import request_password_reset, reset_password

        sent = {}

        def capture_link(email, token):
            sent["email"] = email
            sent["token"] = token

        request_password_reset(
            email=self.admin.email,
            send_code=lambda email, code: self.fail("Admin reset must not send an OTP."),
            send_link=capture_link,
        )

        self.assertEqual(sent["email"], self.admin.email)
        self.assertTrue(sent["token"])
        self.assertEqual(
            PasswordResetRequest.objects.filter(
                email__iexact=self.admin.email,
                verified_at__isnull=False,
                used_at__isnull=True,
            ).count(),
            1,
        )

        token, error = __import__("elections.services.authentication", fromlist=["verify_reset_code"]).verify_reset_code(
            email=self.admin.email,
            code="123456",
        )
        self.assertIsNone(token)
        self.assertIsNotNone(error)

        self.assertIsNone(
            reset_password(
                email=self.admin.email,
                reset_token=sent["token"],
                password="NewAdminPass123!",
            )
        )
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password("NewAdminPass123!"))
        self.assertEqual(
            PasswordResetRequest.objects.filter(
                email__iexact=self.admin.email,
                used_at__isnull=False,
            ).count(),
            1,
        )

    def test_reset_token_is_single_use(self):
        from .services.authentication import request_password_reset, verify_reset_code, reset_password

        sent = {}
        request_password_reset(email=self.student.email, send_code=lambda email, code: sent.update(code=code))
        token, error = verify_reset_code(email=self.student.email, code=sent["code"])
        self.assertIsNone(error)
        self.assertIsNotNone(token)
        self.assertIsNone(reset_password(email=self.student.email, reset_token=token, password="NewSecurePass123!"))
        self.assertIsNotNone(reset_password(email=self.student.email, reset_token=token, password="AnotherSecurePass123!"))

    def test_sensitive_django_admin_records_are_read_only(self):
        request = type("Request", (), {})()
        vote_admin = VoteAdmin(Vote, None)
        audit_admin = AuditLogAdmin(AuditLog, None)
        reset_admin = PasswordResetRequestAdmin(PasswordResetRequest, None)
        self.assertFalse(vote_admin.has_add_permission(request))
        self.assertFalse(vote_admin.has_change_permission(request))
        self.assertFalse(vote_admin.has_delete_permission(request))
        self.assertFalse(audit_admin.has_add_permission(request))
        self.assertFalse(audit_admin.has_change_permission(request))
        self.assertFalse(audit_admin.has_delete_permission(request))
        self.assertFalse(reset_admin.has_add_permission(request))
        self.assertFalse(reset_admin.has_change_permission(request))
        self.assertFalse(reset_admin.has_delete_permission(request))

    def test_all_voter_roles_are_denied_admin_api(self):
        election = Election.objects.create(
            name="Security Election",
            eligible_voter_category="student",
            start_datetime=timezone.now(),
            end_datetime=timezone.now() + timedelta(hours=1),
        )
        for role in ("student", "alumni", "faculty"):
            user = User.objects.create_user(
                username=f"security-{role}",
                email=f"security-{role}@cmu.edu",
                password="VoterPass123!",
            )
            Profile.objects.create(
                user=user,
                role=role,
                cmu_email=user.email,
                full_name=f"Security {role.title()}",
                must_change_password=False,
            )
            self.client.force_authenticate(user=user)
            response = self.client.get("/api/admin/dashboard/")
            self.assertEqual(response.status_code, 403)
        self.assertIsNotNone(election)


class BallotIntegrityRegressionTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.voter = User.objects.create_user(
            username="ballot-voter",
            email="ballot-voter@cmu.edu",
            password="VoterPass123!",
        )
        Profile.objects.create(
            user=self.voter,
            role="student",
            cmu_email=self.voter.email,
            full_name="Ballot Voter",
            must_change_password=False,
        )
        now = timezone.now()
        self.election = Election.objects.create(
            name="Ballot Integrity Election",
            eligible_voter_category="student",
            start_datetime=now - timedelta(minutes=5),
            end_datetime=now + timedelta(hours=1),
        )
        from .models import Candidate, Position
        self.position_one = Position.objects.create(election=self.election, name="President", order=1)
        self.position_two = Position.objects.create(election=self.election, name="Secretary", order=2)
        self.candidate_one = Candidate.objects.create(position=self.position_one, name="Candidate One")
        self.candidate_two = Candidate.objects.create(position=self.position_two, name="Candidate Two")
        self.client.force_authenticate(user=self.voter)

    def _complete_ballot(self):
        return {
            "election_id": self.election.id,
            "votes": [
                {"position_id": self.position_one.id, "candidate_id": self.candidate_one.id},
                {"position_id": self.position_two.id, "candidate_id": self.candidate_two.id},
            ],
        }

    def test_incomplete_ballot_is_rejected(self):
        response = self.client.post(
            "/api/votes/",
            {
                "election_id": self.election.id,
                "votes": [{"position_id": self.position_one.id, "candidate_id": self.candidate_one.id}],
            },
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("every position", response.data["detail"])
        self.assertEqual(Vote.objects.filter(voter=self.voter, election=self.election).count(), 0)

    def test_ballot_endpoint_is_blocked_after_voting(self):
        response = self.client.post("/api/votes/", self._complete_ballot(), format="json")
        self.assertEqual(response.status_code, 201)

        ballot_response = self.client.get(f"/api/elections/{self.election.id}/ballot/")
        self.assertEqual(ballot_response.status_code, 403)
        self.assertEqual(ballot_response.data["detail"], "You have already voted in this election.")

    def test_election_detail_marks_voter_as_already_voted(self):
        response = self.client.post("/api/votes/", self._complete_ballot(), format="json")
        self.assertEqual(response.status_code, 201)

        detail_response = self.client.get(f"/api/elections/{self.election.id}/")
        self.assertEqual(detail_response.status_code, 200)
        self.assertTrue(detail_response.data["has_voted"])
