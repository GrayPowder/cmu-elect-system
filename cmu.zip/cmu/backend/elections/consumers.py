from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from django.contrib.auth.models import AnonymousUser
from django.core.exceptions import ObjectDoesNotExist

from .models import Election
from .services.eligibility_service import is_voter_in_election_scope


class AnalyticsConsumer(AsyncJsonWebsocketConsumer):
    """Push lightweight analytics-change events to authorized viewers."""

    async def connect(self):
        self.election_id = self.scope["url_route"]["kwargs"]["election_id"]
        self.group_name = f"analytics_{self.election_id}"

        user = self.scope.get("user", AnonymousUser())
        if not await self._can_view_analytics(user, self.election_id):
            await self.close(code=4403)
            return

        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name,
        )

        await self.accept()
        await self.send_json({
            "type": "analytics_connected",
            "election_id": self.election_id,
        })

    async def disconnect(self, close_code):
        if hasattr(self, "group_name"):
            await self.channel_layer.group_discard(
                self.group_name,
                self.channel_name,
            )

    async def analytics_update(self, event):
        await self.send_json({
            "type": "analytics_update",
            "election_id": self.election_id,
        })

    @database_sync_to_async
    def _can_view_analytics(self, user, election_id):
        if not user or not user.is_authenticated or not user.is_active:
            return False

        try:
            election = Election.objects.get(pk=election_id)
        except Election.DoesNotExist:
            return False

        if user.is_staff:
            return True

        try:
            profile = user.profile
        except ObjectDoesNotExist:
            return False

        if profile.account_status != "active" or profile.must_change_password:
            return False

        return is_voter_in_election_scope(user, election)
