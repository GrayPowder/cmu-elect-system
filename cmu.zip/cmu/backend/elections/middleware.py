from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from django.contrib.auth.models import AnonymousUser
from rest_framework.authtoken.models import Token


@database_sync_to_async
def get_user_from_token(token_key):
    if not token_key:
        return AnonymousUser()

    try:
        token = Token.objects.select_related("user", "user__profile").get(
            key=token_key
        )
    except Token.DoesNotExist:
        return AnonymousUser()

    user = token.user
    if not user.is_active:
        return AnonymousUser()

    return user


class TokenAuthMiddleware:
    """Authenticate Channels connections using the same DRF token as the REST API."""

    def __init__(self, inner):
        self.inner = inner

    async def __call__(self, scope, receive, send):
        query_string = scope.get("query_string", b"").decode("utf-8")
        query_params = parse_qs(query_string)
        token_key = query_params.get("token", [None])[0]

        scope["user"] = await get_user_from_token(token_key)

        return await self.inner(scope, receive, send)
