from rest_framework import serializers

from ..models import AuditLog


class AuditLogSerializer(serializers.ModelSerializer):
    actor = serializers.SerializerMethodField()
    actor_role = serializers.SerializerMethodField()

    class Meta:
        model = AuditLog
        fields = [
            "id",
            "actor",
            "actor_role",
            "action",
            "timestamp",
            "target_model",
            "target_object_id",
            "description",
        ]

    def get_actor(self, obj):
        return obj.actor.get_username() if obj.actor else "System"

    def get_actor_role(self, obj):
        if not obj.actor:
            return "System"
        if obj.actor.is_staff:
            return "Administrator"
        return "Voter"
