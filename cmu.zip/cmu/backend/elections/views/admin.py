from django.db.models import Q
from django.db.models.functions import Lower
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from ..models import Profile, Election, Department
from ..permissions import IsAdministrator
from ..serializers import (
    VoterSerializer, VoterCreateSerializer, VoterPasswordResetSerializer,
    AdminElectionSerializer, DepartmentSerializer,
)
from ..services.authentication import create_voter, reset_voter_password
from ..services.election_service import create_election, delete_election, update_election
from ..services.department_service import create_department, update_department
from .common import create_audit_log


# Administrator dashboard, voter management, and election management views.

class AdminDashboardView(APIView):
    permission_classes = [IsAdministrator]

    def get(self, request):
        return Response({
            "detail": "Administrator access granted.",
            "user": {
                "id": request.user.id,
                "username": request.user.username,
                "email": request.user.email,
                "is_admin": True,
            },
            "modules": [
                {"key": "users", "name": "User Management", "path": "/admin/users"},
                {"key": "departments", "name": "Department Management", "path": "/admin/departments"},
                {"key": "elections", "name": "Election Management", "path": "/admin/elections"},
                {"key": "positions", "name": "Position Management", "path": "/admin/positions"},
                {"key": "candidates", "name": "Candidate Management", "path": "/admin/candidates"},
                {"key": "results", "name": "Results", "path": "/admin/results"},
                {"key": "analytics", "name": "Analytics", "path": "/admin/analytics"},
                {"key": "audit-logs", "name": "Audit Logs", "path": "/admin/audit-logs"},
            ],
        })


class AdminDepartmentListCreateView(APIView):
    permission_classes = [IsAdministrator]

    def get(self, request):
        departments = Department.objects.all().order_by("name", "id")
        search = str(request.query_params.get("search", "")).strip()
        active = str(request.query_params.get("status", "")).strip().lower()

        if search:
            departments = departments.filter(Q(code__icontains=search) | Q(name__icontains=search))
        if active in {"active", "inactive"}:
            departments = departments.filter(is_active=(active == "active"))

        return Response(DepartmentSerializer(departments, many=True).data)

    def post(self, request):
        serializer = DepartmentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        department = create_department(validated_data=serializer.validated_data, actor=request.user)
        return Response(DepartmentSerializer(department).data, status=status.HTTP_201_CREATED)


class AdminDepartmentDetailView(APIView):
    permission_classes = [IsAdministrator]

    def get_department(self, department_id):
        return Department.objects.get(pk=department_id)

    def get(self, request, department_id):
        try:
            department = self.get_department(department_id)
        except Department.DoesNotExist:
            return Response({"detail": "Department not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(DepartmentSerializer(department).data)

    def patch(self, request, department_id):
        try:
            department = self.get_department(department_id)
        except Department.DoesNotExist:
            return Response({"detail": "Department not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = DepartmentSerializer(department, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        department = update_department(
            department=department,
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(DepartmentSerializer(department).data)


class AdminVoterListCreateView(APIView):
    permission_classes = [IsAdministrator]

    def get(self, request):
        queryset = (
            Profile.objects
            .select_related("user")
            .all()
            .annotate(name_lower=Lower("full_name"))
            .order_by("name_lower", "id")
        )

        search = str(request.query_params.get("search", "")).strip()
        category = str(request.query_params.get("category", "")).strip().lower()
        department_param = request.query_params.get("department", "").strip()
        account_status = str(request.query_params.get("status", "")).strip().lower()

        if search:
            queryset = queryset.filter(
                Q(full_name__icontains=search)
                | Q(cmu_email__icontains=search)
                | Q(user__username__icontains=search)
            )
        if category:
            queryset = queryset.filter(role=category)
        if department_param:
            try:
                department_id = int(department_param)
            except (TypeError, ValueError):
                return Response(
                    {"detail": "Invalid department filter."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            queryset = queryset.filter(department_id=department_id)
        if account_status:
            queryset = queryset.filter(account_status=account_status)

        return Response(VoterSerializer(queryset, many=True).data)

    def post(self, request):
        serializer = VoterCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        voter = create_voter(validated_data=serializer.validated_data, actor=request.user)
        return Response(VoterSerializer(voter).data, status=status.HTTP_201_CREATED)


class AdminVoterDetailView(APIView):
    permission_classes = [IsAdministrator]

    def get_voter(self, voter_id):
        return Profile.objects.select_related("user").get(pk=voter_id)

    def get(self, request, voter_id):
        try:
            voter = self.get_voter(voter_id)
        except Profile.DoesNotExist:
            return Response({"detail": "Voter account not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(VoterSerializer(voter).data)

    def patch(self, request, voter_id):
        try:
            voter = self.get_voter(voter_id)
        except Profile.DoesNotExist:
            return Response({"detail": "Voter account not found."}, status=status.HTTP_404_NOT_FOUND)

        previous_status = voter.account_status
        serializer = VoterSerializer(voter, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        action = "account_deactivated" if previous_status != voter.account_status and voter.account_status == "inactive" else "account_modified"
        description = "Voter account was deactivated." if action == "account_deactivated" else "Voter account was modified."
        create_audit_log(actor=request.user, action=action, target_model="Profile", target_object_id=voter.id, description=description)
        return Response(VoterSerializer(voter).data)


class AdminVoterPasswordResetView(APIView):
    permission_classes = [IsAdministrator]

    def post(self, request, voter_id):
        try:
            voter = Profile.objects.select_related("user").get(pk=voter_id)
        except Profile.DoesNotExist:
            return Response({"detail": "Voter account not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = VoterPasswordResetSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        reset_voter_password(
            voter=voter,
            password=serializer.validated_data["password"],
            actor=request.user,
        )

        return Response({"detail": "Voter password reset successfully. The voter must change it on first login."})


class AdminElectionListCreateView(APIView):
    permission_classes = [IsAdministrator]

    def get(self, request):
        elections = Election.objects.all().order_by("start_datetime", "id")
        status_filter = str(request.query_params.get("status", "")).strip().lower()
        schedule_status_filter = str(request.query_params.get("schedule_status", "")).strip().lower()
        exclude_not_started = str(request.query_params.get("exclude_not_started", "")).strip().lower() in {"1", "true", "yes"}
        department_scope_filter = str(request.query_params.get("department_scope", "")).strip().lower()
        department_code_filter = str(request.query_params.get("department", "")).strip().upper()

        if schedule_status_filter in {Election.STATUS_ACTIVE, Election.STATUS_ENDED, "not_started"}:
            elections = [
                election
                for election in elections
                if election.schedule_status == schedule_status_filter
            ]
        elif exclude_not_started:
            elections = [
                election
                for election in elections
                if election.schedule_status != "not_started"
            ]

        if status_filter in {
            "not_started",
            Election.STATUS_ACTIVE,
            Election.STATUS_ENDED,
        }:
            if status_filter == Election.STATUS_ENDED:
                elections = [
                    election
                    for election in elections
                    if election.effective_status == Election.STATUS_ENDED
                ]
            elif status_filter == Election.STATUS_ACTIVE:
                elections = [
                    election
                    for election in elections
                    if election.effective_status == Election.STATUS_ACTIVE
                ]
            else:
                elections = [
                    election
                    for election in elections
                    if election.schedule_status == "not_started"
                ]

        if department_scope_filter in {
            Election.DEPARTMENT_SCOPE_ALL,
            Election.DEPARTMENT_SCOPE_SPECIFIC,
        }:
            elections = [
                election
                for election in elections
                if election.department_scope == department_scope_filter
            ]

        # Department filter for the analytics dashboard. Selecting a specific
        # department includes both elections scoped to that department and
        # ALL-DEPARTMENT elections, since the latter are also applicable to it.
        if department_code_filter:
            elections = [
                election
                for election in elections
                if election.department_scope == Election.DEPARTMENT_SCOPE_ALL
                or election.eligible_departments.filter(
                    code__iexact=department_code_filter,
                    is_active=True,
                ).exists()
            ]

        # Analytics should prioritize elections available to everyone. This
        # keeps ALL-DEPARTMENT elections at the top of the selector.
        elections = list(elections)
        elections.sort(
            key=lambda election: (
                0 if election.department_scope == Election.DEPARTMENT_SCOPE_ALL else 1,
                election.start_datetime,
                election.id,
            )
        )

        return Response(AdminElectionSerializer(elections, many=True).data)

    def post(self, request):
        serializer = AdminElectionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        election = create_election(
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(AdminElectionSerializer(election).data, status=status.HTTP_201_CREATED)


class AdminElectionDetailView(APIView):
    permission_classes = [IsAdministrator]

    def get_election(self, election_id):
        return Election.objects.get(pk=election_id)

    def get(self, request, election_id):
        try:
            election = self.get_election(election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(AdminElectionSerializer(election).data)

    def patch(self, request, election_id):
        try:
            election = self.get_election(election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = AdminElectionSerializer(election, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        election = update_election(
            election=election,
            validated_data=serializer.validated_data,
            actor=request.user,
        )
        return Response(AdminElectionSerializer(election).data)

    def delete(self, request, election_id):
        try:
            election = self.get_election(election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        if election.effective_status == Election.STATUS_ACTIVE:
            return Response(
                {"detail": "Active elections cannot be deleted."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        delete_election(election=election, actor=request.user)
        return Response(status=status.HTTP_204_NO_CONTENT)
