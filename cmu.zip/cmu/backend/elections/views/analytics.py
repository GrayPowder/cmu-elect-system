from datetime import date

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import Election
from ..permissions import IsAdministrator
from ..services.analytics_service import build_analytics_data
from ..services.eligibility_service import is_voter_in_election_scope


def _requested_date(request):
    value = request.query_params.get("date")
    if not value:
        return None, None
    try:
        return date.fromisoformat(value), None
    except ValueError:
        return None, Response(
            {"detail": "Invalid analytics date. Use YYYY-MM-DD."},
            status=status.HTTP_400_BAD_REQUEST,
        )


class AnalyticsView(APIView):
    """Return live database-backed analytics for an administrator."""
    permission_classes = [IsAdministrator]

    def get(self, request, election_id):
        try:
            election = Election.objects.get(pk=election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        selected_date, error_response = _requested_date(request)
        if error_response:
            return error_response

        return Response(
            build_analytics_data(
                election,
                selected_date=selected_date,
                include_private_metrics=True,
            )
        )


class VoterAnalyticsView(APIView):
    """Return aggregate live analytics to an eligible authenticated voter."""
    permission_classes = [IsAuthenticated]

    def get(self, request, election_id):
        try:
            election = Election.objects.get(pk=election_id)
        except Election.DoesNotExist:
            return Response({"detail": "Election not found."}, status=status.HTTP_404_NOT_FOUND)

        profile = getattr(request.user, "profile", None)
        if (
            not request.user.is_active
            or not profile
            or profile.account_status != "active"
        ):
            return Response({"detail": "Active voter access is required."}, status=status.HTTP_403_FORBIDDEN)
        if profile.must_change_password:
            return Response({"detail": "You must change your password before viewing analytics."}, status=status.HTTP_403_FORBIDDEN)
        if not is_voter_in_election_scope(request.user, election):
            return Response({"detail": "You are not eligible to view this election's analytics."}, status=status.HTTP_403_FORBIDDEN)

        selected_date, error_response = _requested_date(request)
        if error_response:
            return error_response

        return Response(
            build_analytics_data(
                election,
                selected_date=selected_date,
                include_private_metrics=False,
            )
        )
