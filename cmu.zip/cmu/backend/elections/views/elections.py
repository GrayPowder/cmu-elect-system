from django.db.models import Exists, OuterRef, Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import Election, Vote
from ..permissions import IsAuthenticatedAndPasswordChanged
from ..serializers import ElectionSerializer
from ..services.eligibility_service import is_voter_eligible_for_election


# Voter-facing election views.

class ElectionListView(APIView):
    permission_classes = [IsAuthenticatedAndPasswordChanged]

    def get(self, request):
        profile = getattr(request.user, "profile", None)
        if not profile or profile.account_status != "active" or not request.user.is_active:
            return Response(
                {"detail": "This account is inactive. Please contact the administrator."},
                status=status.HTTP_403_FORBIDDEN,
            )

        # The authenticated profile determines the voter category. Do not ask
        # the voter to select Student/Alumni/Faculty on the login screen.
        # Department scope is also enforced here so the dashboard only receives
        # elections the voter is actually allowed to access.
        if profile.department_id:
            elections = Election.objects.filter(
                eligible_voter_category=profile.role,
            ).filter(
                Q(department_scope=Election.DEPARTMENT_SCOPE_ALL)
                | Q(
                    department_scope=Election.DEPARTMENT_SCOPE_SPECIFIC,
                    eligible_departments=profile.department_id,
                )
            )
        else:
            elections = Election.objects.filter(
                eligible_voter_category=profile.role,
                department_scope=Election.DEPARTMENT_SCOPE_ALL,
            )

        elections = (
            elections
            .annotate(has_voted=Exists(Vote.objects.filter(voter=request.user, election=OuterRef("pk"))))
            .prefetch_related("positions__candidates", "eligible_departments")
            .order_by("start_datetime", "id")
        )

        return Response(ElectionSerializer(elections, many=True, context={"request": request}).data)


class ElectionDetailView(APIView):
    """Return one election only when it is eligible for the authenticated voter."""

    permission_classes = [IsAuthenticatedAndPasswordChanged]

    def get(self, request, election_id):
        profile = getattr(request.user, "profile", None)
        if not profile or profile.account_status != "active" or not request.user.is_active:
            return Response(
                {"detail": "This account is inactive. Please contact the administrator."},
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            election = (
                Election.objects
                .annotate(has_voted=Exists(Vote.objects.filter(voter=request.user, election=OuterRef("pk"))))
                .prefetch_related("positions__candidates", "eligible_departments")
                .get(pk=election_id)
            )
        except Election.DoesNotExist:
            return Response(
                {"detail": "Election not found or you are not eligible to access it."},
                status=status.HTTP_404_NOT_FOUND,
            )

        if not is_voter_eligible_for_election(request.user, election, require_open=False,):
            return Response(
                {"detail": "You are not eligible to access it."},
                status=status.HTTP_404_NOT_FOUND,
            )

        return Response(ElectionSerializer(election, context={"request": request}).data)

class ElectionBallotView(APIView):
    """Return ballot data only while the authenticated voter can still vote."""

    permission_classes = [IsAuthenticatedAndPasswordChanged]

    def get(self, request, election_id):
        profile = getattr(request.user, "profile", None)
        if not profile or profile.account_status != "active" or not request.user.is_active:
            return Response(
                {"detail": "This account is inactive. Please contact the administrator."},
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            election = (
                Election.objects
                .annotate(has_voted=Exists(Vote.objects.filter(voter=request.user, election=OuterRef("pk"))))
                .prefetch_related("positions__candidates", "eligible_departments")
                .get(pk=election_id)
            )
        except Election.DoesNotExist:
            return Response(
                {"detail": "Election not found or you are not eligible to access it."},
                status=status.HTTP_404_NOT_FOUND,
            )

        if not is_voter_eligible_for_election(request.user, election):
            return Response(
                {"detail": "You are not eligible to access this election."},
                status=status.HTTP_404_NOT_FOUND,
            )

        if election.has_voted:
            return Response(
                {"detail": "You have already voted in this election."},
                status=status.HTTP_403_FORBIDDEN,
            )

        if not election.is_open:
            message = (
                "Voting for this election has not started."
                if election.schedule_status == "not_started"
                else "Voting for this election has ended."
            )
            return Response({"detail": message}, status=status.HTTP_400_BAD_REQUEST)

        return Response(ElectionSerializer(election, context={"request": request}).data)

