from datetime import timedelta

from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
from rest_framework.response import Response
from rest_framework.views import APIView

from ..models import AuditLog
from ..permissions import IsAdministrator
from ..serializers import AuditLogSerializer


# Administrator audit-log views.

class AdminAuditLogListView(APIView):
    permission_classes = [IsAdministrator]

    def get(self, request):
        queryset = AuditLog.objects.select_related("actor", "actor__profile").all()
        search = str(request.query_params.get("search", "")).strip()
        action = str(request.query_params.get("action", "")).strip()
        actor = str(request.query_params.get("actor", "")).strip()
        target_model = str(request.query_params.get("target_model", "")).strip()
        sort = str(request.query_params.get("sort", "desc")).strip().lower()
        date_range = str(request.query_params.get("date_range", "7")).strip().lower()

        if search:
            queryset = queryset.filter(
                Q(action__icontains=search)
                | Q(description__icontains=search)
                | Q(target_model__icontains=search)
                | Q(target_object_id__icontains=search)
                | Q(actor__username__icontains=search)
                | Q(actor__email__icontains=search)
            )
        if action:
            queryset = queryset.filter(action=action)
        if actor:
            queryset = queryset.filter(actor__username=actor)
        if target_model:
            queryset = queryset.filter(target_model=target_model)

        if date_range in {"7", "30", "90"}:
            since = timezone.now() - timedelta(days=int(date_range))
            queryset = queryset.filter(timestamp__gte=since)

        queryset = queryset.order_by("timestamp", "id") if sort == "asc" else queryset.order_by("-timestamp", "-id")

        try:
            page_number = max(1, int(request.query_params.get("page", "1")))
        except (TypeError, ValueError):
            page_number = 1

        try:
            page_size = min(100, max(1, int(request.query_params.get("page_size", "10"))))
        except (TypeError, ValueError):
            page_size = 10

        paginator = Paginator(queryset, page_size)
        page_obj = paginator.get_page(page_number)

        users = []
        for user in User.objects.filter(audit_logs__isnull=False).distinct().order_by("username"):
            users.append({
                "username": user.username,
                "label": user.username,
            })

        return Response({
            "logs": AuditLogSerializer(page_obj.object_list, many=True).data,
            "actions": list(AuditLog.objects.order_by("action").values_list("action", flat=True).distinct()),
            "target_models": list(AuditLog.objects.exclude(target_model="").order_by("target_model").values_list("target_model", flat=True).distinct()),
            "users": users,
            "total": paginator.count,
            "page": page_obj.number,
            "page_size": page_size,
            "total_pages": paginator.num_pages,
        })
