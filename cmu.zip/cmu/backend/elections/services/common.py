"""Compatibility exports for non-business helpers used by older imports."""

import hashlib
import secrets

from django.conf import settings
from django.core.mail import send_mail


def hash_value(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def create_reset_code():
    return f"{secrets.randbelow(1_000_000):06d}"


def send_reset_code(email, code):
    send_mail(
        subject="CMU-ELECT password reset verification code",
        message=(
            "Your CMU-ELECT verification code is " + code +
            ". It expires in 10 minutes. If you did not request a password reset, "
            "you can ignore this message."
        ),
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "cmu-elect@localhost"),
        recipient_list=[email],
        fail_silently=False,
    )

def send_admin_reset_link(email, reset_token):
    """Send a direct password-reset link for administrator accounts."""
    from urllib.parse import urlencode

    frontend_base_url = getattr(
        settings,
        "FRONTEND_BASE_URL",
        "http://localhost:5173",
    ).rstrip("/")
    reset_url = f"{frontend_base_url}/reset-password/?{urlencode({'email': email, 'token': reset_token})}"

    send_mail(
        subject="CMU-ELECT administrator password reset",
        message=(
            "A password reset was requested for your CMU-ELECT administrator account.\n\n"
            "Use the link below to create a new password. You will not be asked for a verification code.\n\n"
            f"{reset_url}\n\n"
            "This link expires in 10 minutes. If you did not request this password reset, you can ignore this message."
        ),
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "cmu-elect@localhost"),
        recipient_list=[email],
        fail_silently=False,
    )

