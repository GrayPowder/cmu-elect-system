"""Reusable, database-backed election analytics calculations."""

from datetime import datetime, time, timedelta, timezone as dt_timezone
from zoneinfo import ZoneInfo

from django.conf import settings
from django.db.models import Count
from django.db.models.functions import TruncDate, TruncHour, TruncSecond
from django.utils import timezone

from ..models import Candidate, Profile, Vote


def _get_eligible_profiles(election):
    """Return voter profiles eligible by category and department scope."""
    queryset = Profile.objects.filter(
        role=election.eligible_voter_category,
        account_status="active",
        user__is_active=True,
    )

    if election.department_scope == election.DEPARTMENT_SCOPE_SPECIFIC:
        queryset = queryset.filter(
            department__in=election.eligible_departments.all()
        )

    return queryset


def _calculate_turnout(participants, eligible_voters):
    if not eligible_voters:
        return 0.0
    return round((participants / eligible_voters) * 100, 2)


def _build_department_turnout(election):
    """Build department turnout only for All Departments elections."""
    if election.department_scope != election.DEPARTMENT_SCOPE_ALL:
        return []

    from ..models import Department

    departments = Department.objects.filter(
        is_active=True,
        profiles__role=election.eligible_voter_category,
        profiles__account_status="active",
        profiles__user__is_active=True,
    ).distinct().order_by("name")

    vote_queryset = Vote.objects.filter(election=election)
    total_participants = (
        vote_queryset
        .values("voter_id")
        .distinct()
        .count()
    )
    results = []

    for department in departments:
        eligible_voters = Profile.objects.filter(
            role=election.eligible_voter_category,
            account_status="active",
            user__is_active=True,
            department=department,
        ).count()

        participants = (
            vote_queryset
            .filter(voter__profile__department=department)
            .values("voter_id")
            .distinct()
            .count()
        )

        results.append({
            "id": department.id,
            "code": department.code,
            "name": department.name,
            "turnout_percentage": _calculate_turnout(
                participants,
                eligible_voters,
            ),
            "vote_share_percentage": (
                round((participants / total_participants) * 100, 2)
                if total_participants else 0.0
            ),
        })

    return results


def _local_timezone():
    return ZoneInfo(getattr(settings, "TIME_ZONE", "UTC"))


def _local_date_range(election):
    tz = _local_timezone()
    start_date = timezone.localtime(election.start_datetime, tz).date()
    end_date = timezone.localtime(election.end_datetime, tz).date()
    return start_date, end_date


def _activity_dates(election, vote_queryset):
    """Return useful dates for the activity selector without huge payloads."""
    tz = _local_timezone()
    start_date, end_date = _local_date_range(election)

    vote_dates = {
        value
        for value in vote_queryset
        .annotate(local_date=TruncDate("created_at", tzinfo=tz))
        .values_list("local_date", flat=True)
        .distinct()
        if value
    }

    # Always keep the election boundaries available. Also expose today while
    # the election is running so a live dashboard can be opened on the current day.
    dates = vote_dates | {start_date, end_date}
    today = timezone.localtime(timezone.now(), tz).date()
    if start_date <= today <= end_date:
        dates.add(today)

    return [date.isoformat() for date in sorted(dates)]


def _build_voting_activity(election, selected_date=None):
    """Build daily voting activity across the full election period.

    The chart uses one point per local calendar date. The point height is the
    number of votes recorded on that date, so the line makes daily peaks,
    lows, and average activity easy to compare. The legacy ``events`` and
    ``points`` fields are retained for API compatibility with older clients.
    """
    tz = _local_timezone()
    election_start = timezone.localtime(election.start_datetime, tz)
    election_end = timezone.localtime(election.end_datetime, tz)
    start_date = election_start.date()
    end_date = election_end.date()

    vote_queryset = Vote.objects.filter(
        election=election,
        created_at__gte=election.start_datetime,
        created_at__lt=election.end_datetime,
    )

    daily_rows = (
        vote_queryset
        .annotate(local_date=TruncDate("created_at", tzinfo=tz))
        .values("local_date")
        .annotate(votes=Count("id"))
        .order_by("local_date")
    )
    daily_totals = {
        row["local_date"]: int(row["votes"] or 0)
        for row in daily_rows
        if row["local_date"]
    }

    daily_points = []
    current_date = start_date
    while current_date <= end_date:
        votes = daily_totals.get(current_date, 0)
        daily_points.append({
            "date": current_date.isoformat(),
            "label": current_date.strftime("%b %d").replace(" 0", " "),
            "votes": votes,
        })
        current_date += timedelta(days=1)


    total_votes = sum(point["votes"] for point in daily_points)
    total_days = len(daily_points)
    active_days = sum(1 for point in daily_points if point["votes"] > 0)
    average_daily_votes = round(total_votes / total_days, 2) if total_days else 0.0

    peak_day = None
    lowest_day = None
    if daily_points:
        peak_point = max(daily_points, key=lambda point: point["votes"])
        lowest_point = min(daily_points, key=lambda point: point["votes"])
        if total_votes:
            peak_day = {
                "date": peak_point["date"],
                "label": peak_point["label"],
                "votes": peak_point["votes"],
            }
            lowest_day = {
                "date": lowest_point["date"],
                "label": lowest_point["label"],
                "votes": lowest_point["votes"],
            }

    # Keep the selected-date event series for older clients. New chart code
    # uses daily_points exclusively.
    if selected_date is None or not start_date <= selected_date <= end_date:
        selected_date = timezone.localtime(timezone.now(), tz).date()
        if not start_date <= selected_date <= end_date:
            selected_date = start_date

    local_start = datetime.combine(selected_date, time.min, tzinfo=tz)
    local_end = local_start + timedelta(days=1)
    utc_start = local_start.astimezone(dt_timezone.utc)
    utc_end = local_end.astimezone(dt_timezone.utc)

    rows = (
        Vote.objects
        .filter(
            election=election,
            created_at__gte=utc_start,
            created_at__lt=utc_end,
        )
        .annotate(local_second=TruncSecond("created_at", tzinfo=tz))
        .values("local_second")
        .annotate(votes=Count("id"))
        .order_by("local_second")
    )

    cumulative_votes = 0
    events = []
    hourly_totals = {}
    for row in rows:
        timestamp = timezone.localtime(row["local_second"], tz)
        event_votes = int(row["votes"] or 0)
        cumulative_votes += event_votes
        hourly_totals[timestamp.hour] = hourly_totals.get(timestamp.hour, 0) + event_votes
        events.append({
            "timestamp": timestamp.isoformat(),
            "votes": event_votes,
            "cumulative_votes": cumulative_votes,
        })

    election_start_local = timezone.localtime(election.start_datetime, tz)
    election_end_local = timezone.localtime(election.end_datetime, tz)
    first_hour = election_start_local.hour if selected_date == election_start_local.date() else 0
    last_hour = election_end_local.hour if selected_date == election_end_local.date() else 23
    points = [
        {
            "hour": hour,
            "label": datetime.combine(selected_date, time(hour=hour)).strftime("%I %p").lstrip("0"),
            "votes": hourly_totals.get(hour, 0),
        }
        for hour in range(first_hour, last_hour + 1)
    ]

    peak = None
    if hourly_totals:
        peak_hour, peak_votes = max(hourly_totals.items(), key=lambda item: (item[1], -item[0]))
        peak_start = datetime.combine(selected_date, time(hour=peak_hour), tzinfo=tz)
        peak_end = peak_start + timedelta(hours=1)
        peak = {
            "date": selected_date.isoformat(),
            "start": peak_start.strftime("%I:%M %p").lstrip("0"),
            "end": peak_end.strftime("%I:%M %p").lstrip("0"),
            "votes": peak_votes,
        }

    return {
        "date": selected_date.isoformat(),
        "start_timestamp": election_start_local.isoformat(),
        "end_timestamp": election_end_local.isoformat(),
        "points": points,
        "events": events,
        "peak": peak,
        "daily_points": daily_points,
        "total_votes": total_votes,
        "total_days": total_days,
        "active_days": active_days,
        "average_daily_votes": average_daily_votes,
        "peak_day": peak_day,
        "lowest_day": lowest_day,
    }

def _build_election_peak(election):
    """Return the highest-volume one-hour voting period for this election.

    The peak is calculated across the complete election period, not only the
    date currently selected in the chart.  This is what lets the frontend
    answer: "When did this specific election receive the most votes?"
    """
    tz = _local_timezone()
    election_start = election.start_datetime
    election_end = election.end_datetime

    rows = (
        Vote.objects
        .filter(
            election=election,
            created_at__gte=election_start,
            created_at__lt=election_end,
        )
        .annotate(local_hour=TruncHour("created_at", tzinfo=tz))
        .values("local_hour")
        .annotate(votes=Count("id"))
        .order_by("local_hour")
    )

    peak_row = None
    for row in rows:
        votes = int(row["votes"] or 0)
        if peak_row is None or votes > peak_row["votes"]:
            peak_row = {
                "local_hour": row["local_hour"],
                "votes": votes,
            }

    if not peak_row:
        return None

    peak_start = timezone.localtime(peak_row["local_hour"], tz)
    peak_end = peak_start + timedelta(hours=1)

    return {
        "date": peak_start.date().isoformat(),
        "start": peak_start.strftime("%I:%M %p").lstrip("0"),
        "end": peak_end.strftime("%I:%M %p").lstrip("0"),
        "hour": peak_start.hour,
        "votes": peak_row["votes"],
    }


def build_analytics_data(election, selected_date=None, include_private_metrics=False):
    """
    Build live aggregate analytics.

    Admin responses include raw eligible/participant/vote-entry metrics.
    Voter responses intentionally omit those private aggregate counts.
    """
    eligible_profiles = _get_eligible_profiles(election)
    vote_queryset = Vote.objects.filter(election=election)

    total_votes = vote_queryset.count()
    participants = (
        vote_queryset
        .filter(voter__in=eligible_profiles.values("user_id"))
        .values("voter_id")
        .distinct()
        .count()
    )
    eligible_voters = eligible_profiles.count()

    metrics = {
        "turnout_percentage": _calculate_turnout(participants, eligible_voters),
        "position_count": election.positions.count(),
        "candidate_count": Candidate.objects.filter(
            position__election=election
        ).count(),
    }
    if include_private_metrics:
        metrics.update({
            "total_eligible_voters": eligible_voters,
            "participants": participants,
            "total_votes": total_votes,
        })

    return {
        "updated_at": timezone.now(),
        "election": {
            "id": election.id,
            "name": election.name,
            "status": election.effective_status,
            "schedule_status": election.schedule_status,
            "eligible_voter_category": election.eligible_voter_category,
            "eligible_voter_category_display": election.get_eligible_voter_category_display(),
            "department_scope": election.department_scope,
            "start_datetime": election.start_datetime,
            "end_datetime": election.end_datetime,
        },
        "metrics": metrics,
        "department_turnout": _build_department_turnout(election),
        "activity_dates": _activity_dates(election, vote_queryset),
        "voting_activity": _build_voting_activity(election, selected_date),
        "election_peak": _build_election_peak(election),
    }
