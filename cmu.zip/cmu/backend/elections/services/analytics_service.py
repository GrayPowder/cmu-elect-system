"""Reusable analytics calculations."""

from django.db.models import Count
from django.utils import timezone

from ..models import Candidate, Profile, Vote


def _get_eligible_profiles(election):
    """
    Return the voter profiles eligible by category and department scope.

    The queryset is used only for analytics calculations.
    Raw eligible-voter counts are not exposed to the frontend.
    """
    queryset = Profile.objects.filter(
        role=election.eligible_voter_category,
        account_status="active",
        user__is_active=True,
    )

    if election.department_scope == election.DEPARTMENT_SCOPE_SPECIFIC:
        queryset = queryset.filter(
            department__in=election.eligible_departments.all()
        )

    return queryset


def _calculate_turnout(participants, eligible_voters):
    """Return turnout percentage without exposing the raw counts."""
    if not eligible_voters:
        return 0.0

    return round((participants / eligible_voters) * 100, 2)


def _build_department_turnout(election):
    """
    Build department turnout only for All Departments elections.
    """
    if election.department_scope != election.DEPARTMENT_SCOPE_ALL:
        return []

    from ..models import Department

    departments = Department.objects.filter(
        is_active=True,
        profiles__role=election.eligible_voter_category,
        profiles__account_status="active",
        profiles__user__is_active=True,
    ).distinct().order_by("name")

    vote_queryset = Vote.objects.filter(election=election)

    results = []

    for department in departments:
        eligible_voters = Profile.objects.filter(
            role=election.eligible_voter_category,
            account_status="active",
            user__is_active=True,
            department=department,
        ).count()

        participants = (
            vote_queryset
            .filter(voter__profile__department=department)
            .values("voter_id")
            .distinct()
            .count()
        )

        results.append({
            "id": department.id,
            "code": department.code,
            "name": department.name,
            "turnout_percentage": _calculate_turnout(
                participants,
                eligible_voters,
            ),
        })

    return results

def build_analytics_data(election):
    """
    Build database-backed aggregate analytics.

    Participant and eligible-voter counts are calculated internally
    because they are required to calculate turnout, but they are not
    intended to be displayed by the frontend.
    """
    eligible_profiles = _get_eligible_profiles(election)

    vote_queryset = Vote.objects.filter(election=election)

    total_votes = vote_queryset.count()

    participants = (
        vote_queryset
        .filter(voter__in=eligible_profiles.values("user_id"))
        .values("voter_id")
        .distinct()
        .count()
    )

    eligible_voters = eligible_profiles.count()

    turnout_percentage = _calculate_turnout(
        participants,
        eligible_voters,
    )

    return {
        "updated_at": timezone.now(),
        "election": {
            "id": election.id,
            "name": election.name,
            "status": election.effective_status,
            "schedule_status": election.schedule_status,
            "eligible_voter_category": election.eligible_voter_category,
            "eligible_voter_category_display": (
                election.get_eligible_voter_category_display()
            ),
            "department_scope": election.department_scope,
            "start_datetime": election.start_datetime,
            "end_datetime": election.end_datetime,
        },
        "metrics": {
            "turnout_percentage": turnout_percentage,
            "position_count": election.positions.count(),
            "candidate_count": Candidate.objects.filter(
                position__election=election
            ).count(),
            "total_votes": total_votes,
        },
        "department_turnout": _build_department_turnout(election),
    }