import React, {createContext, useCallback, useContext, useEffect, useMemo, useState} from "react";
import {login as loginRequest, logout as logoutRequest, getCurrentUser} from "../services/authService";
import {clearStoredAuth, getStoredUser, getToken, persistAuth} from "./authStorage";

const AuthContext = createContext(null);

function normalizeUser(user) {
  if (!user) return null;
  return {
    ...user,
    is_admin: Boolean(user.is_admin),
    role: user.is_admin ? null : user.role || null,
  };
}

export function AuthProvider({children}) {
  const [user, setUser] = useState(() => normalizeUser(getStoredUser()));
  const [token, setToken] = useState(() => getToken());
  const [isInitializing, setIsInitializing] = useState(Boolean(getToken()));
  const [showInactivityWarning, setShowInactivityWarning] = useState(false);
  const [warningSecondsLeft, setWarningSecondsLeft] = useState(120);

  const clearSession = useCallback(() => {
    clearStoredAuth();
    setToken(null);
    setUser(null);
  }, []);

  const applySession = useCallback((nextToken, nextUser) => {
    const normalizedUser = normalizeUser(nextUser);
    persistAuth(nextToken, normalizedUser);
    setToken(nextToken);
    setUser(normalizedUser);
    return normalizedUser;
  }, []);

  const login = useCallback(async ({email, password}) => {
    const data = await loginRequest({email, password});
    return applySession(data.token, data.user);
  }, [applySession]);

  const logout = useCallback(async ({keepalive = false} = {}) => {
    try {
      if (getToken()) {
        await logoutRequest({keepalive});
      }
    } catch (_) {
      // The local session is cleared even when the server cannot be reached.
    } finally {
      clearSession();
    }
  }, [clearSession]);

  const updateSession = useCallback(({token: nextToken = token, user: nextUser = user}) => {
    if (!nextToken || !nextUser) {
      clearSession();
      return;
    }
    applySession(nextToken, nextUser);
  }, [applySession, clearSession, token, user]);

  useEffect(() => {
    const handleUnauthorized = () => clearSession();
    window.addEventListener("cmu-elect:auth-unauthorized", handleUnauthorized);
    return () => window.removeEventListener("cmu-elect:auth-unauthorized", handleUnauthorized);
  }, [clearSession]);

  useEffect(() => {
    if (!token || !user) return undefined;

    // Automatic security timeout: users are logged out after 15 minutes
    // without meaningful interaction. This applies to both voters and admins.
    const INACTIVITY_LIMIT_MS = 15 * 60 * 1000;
    const WARNING_BEFORE_LOGOUT_MS = 2 * 60 * 1000;
    const ACTIVITY_CHECK_MS = 1000;
    let lastActivity = Date.now();
    let logoutStarted = false;

    const markActivity = () => {
      lastActivity = Date.now();
      setShowInactivityWarning(false);
      setWarningSecondsLeft(120);
    };

    const checkInactivity = () => {
      if (logoutStarted) return;

      const inactiveFor = Date.now() - lastActivity;
      const remainingMs = INACTIVITY_LIMIT_MS - inactiveFor;

      if (remainingMs <= 0) {
        logoutStarted = true;
        setShowInactivityWarning(false);
        void logout();
        return;
      }

      if (remainingMs <= WARNING_BEFORE_LOGOUT_MS) {
        setShowInactivityWarning(true);
        setWarningSecondsLeft(Math.max(0, Math.ceil(remainingMs / 1000)));
      }
    };

    const activityEvents = [
      "click",
      "keydown",
      "mousemove",
      "mousedown",
      "scroll",
      "touchstart",
    ];

    // Mouse movement can fire very frequently, but the handler only updates
    // an in-memory timestamp and does not write to storage or the server.
    activityEvents.forEach((eventName) => {
      window.addEventListener(eventName, markActivity, {passive: true});
    });

    const inactivityTimer = window.setInterval(
      checkInactivity,
      ACTIVITY_CHECK_MS,
    );

    // A normal SPA route change does not unload the document. When the user
    // actually leaves the CMU-ELECT site (external navigation, tab close,
    // browser close, or page reload), invalidate the server token as well.
    const handlePageHide = () => {
      if (logoutStarted || !getToken()) return;
      logoutStarted = true;

      // Send the authenticated logout request with keepalive so the backend
      // can invalidate the token even while the document is being unloaded.
      // Clear local credentials immediately because the page is leaving.
      void logoutRequest({keepalive: true}).catch(() => {});
      clearSession();
    };

    window.addEventListener("pagehide", handlePageHide);
    window.addEventListener("cmu-elect:stay-active", markActivity);

    return () => {
      window.clearInterval(inactivityTimer);
      window.removeEventListener("pagehide", handlePageHide);
      window.removeEventListener("cmu-elect:stay-active", markActivity);
      activityEvents.forEach((eventName) => {
        window.removeEventListener(eventName, markActivity);
      });
    };
  }, [token, user, logout, clearSession]);

  useEffect(() => {
    let cancelled = false;

    async function initialize() {
      const storedToken = getToken();
      if (!storedToken) {
        setIsInitializing(false);
        return;
      }

      try {
        const currentUser = await getCurrentUser();
        if (cancelled) return;

        // /auth/me/ is authoritative after a refresh; never infer admin access
        // from a client-controlled role value.
        applySession(storedToken, currentUser);
      } catch (_) {
        if (!cancelled) clearSession();
      } finally {
        if (!cancelled) setIsInitializing(false);
      }
    }

    initialize();
    return () => { cancelled = true; };
  }, [applySession, clearSession]);

  const value = useMemo(() => ({
    user,
    token,
    isAuthenticated: Boolean(token && user),
    isInitializing,
    isAdmin: Boolean(user?.is_admin),
    voterRole: user?.role || null,
    login,
    logout,
    updateSession,
  }), [user, token, isInitializing, login, logout, updateSession]);

  return (
    <AuthContext.Provider value={value}>
      {children}
      {showInactivityWarning && token && user && (
        <div role="dialog" aria-modal="true" aria-labelledby="session-warning-title" style={{position:"fixed",inset:0,zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,0.45)",padding:"20px"}}>
          <div style={{width:"min(420px,100%)",background:"#fff",borderRadius:"16px",padding:"28px",textAlign:"center",boxShadow:"0 18px 50px rgba(0,0,0,0.2)"}}>
            <h2 id="session-warning-title" style={{margin:"0 0 10px"}}>Session Expiring Soon</h2>
            <p style={{margin:"0 0 8px",lineHeight:1.5}}>You have been inactive for a while. For your security, you will be logged out soon.</p>
            <p style={{margin:"0 0 20px",fontWeight:700}}>Automatic logout in {Math.floor(warningSecondsLeft/60)}:{String(warningSecondsLeft%60).padStart(2,"0")}</p>
            <button type="button" onClick={() => window.dispatchEvent(new Event("cmu-elect:stay-active"))} style={{border:0,borderRadius:"10px",padding:"11px 22px",cursor:"pointer",fontWeight:600}}>Stay Logged In</button>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside an AuthProvider");
  return context;
}
