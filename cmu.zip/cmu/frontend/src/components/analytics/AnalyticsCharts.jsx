import React from "react";

const CHART_COLORS = ["#2463d4", "#35ad82", "#8051d8", "#f39a35", "#24a9c5"];

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, Number(value) || 0));
}

export function TurnoutDonut({percentage, admin = false, metrics = null}) {
  const safe = clamp(percentage);
  const circumference = 2 * Math.PI * 76;
  const dash = (safe / 100) * circumference;

  return (
    <div className={`analytics-turnout${admin ? " analytics-turnout-admin" : ""}`}>
      <div className="analytics-donut-wrap">
        <svg viewBox="0 0 190 190" role="img" aria-label={`Turnout ${safe.toFixed(2)} percent`}>
          <circle cx="95" cy="95" r="76" fill="none" stroke="#e6ebf3" strokeWidth="22" />
          <circle
            cx="95"
            cy="95"
            r="76"
            fill="none"
            stroke="#2d59d2"
            strokeWidth="22"
            strokeLinecap="butt"
            strokeDasharray={`${dash} ${circumference - dash}`}
            transform="rotate(-90 95 95)"
          />
        </svg>
        <div className="analytics-donut-center">
          <strong>{safe.toFixed(2)}%</strong>
          <span>Turnout</span>
        </div>
      </div>

      {admin && metrics && (
        <div className="analytics-turnout-legend">
          <div><i className="legend-dot voted" /><span>Voted</span><strong>{metrics.participants ?? 0}<small>({safe.toFixed(2)}%)</small></strong></div>
          <div><i className="legend-dot not-voted" /><span>Not Voted</span><strong>{Math.max(0, (metrics.total_eligible_voters ?? 0) - (metrics.participants ?? 0))}<small>({Math.max(0, 100 - safe).toFixed(2)}%)</small></strong></div>
          <div className="eligible-line"><span>Total Eligible Voters</span><strong>{metrics.total_eligible_voters ?? 0}</strong></div>
        </div>
      )}
    </div>
  );
}

export function DepartmentBarChart({departments = []}) {
  if (!departments.length) return <div className="analytics-empty">No department turnout data is available.</div>;
  const max = 100;

  return (
    <div className="analytics-chart-box department-bar-chart">
      <div className="bar-y-axis"><span>100%</span><span>80%</span><span>60%</span><span>40%</span><span>20%</span><span>0%</span></div>
      <div className="bar-chart-main">
        <div className="bar-grid-lines">{[100, 80, 60, 40, 20, 0].map(v => <span key={v} style={{bottom: `${v}%`}} />)}</div>
        <div className="bar-columns">
          {departments.map(department => {
            const value = clamp(department.turnout_percentage, 0, max);
            return (
              <div className="bar-column" key={department.id} title={`${department.name}: ${value.toFixed(2)}% turnout`}>
                <strong>{value.toFixed(1)}%</strong>
                <div className="bar-track"><div className="bar-fill" style={{height: `${value}%`}} /></div>
                <span>{department.code || department.name}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function parseDate(dateValue) {
  const date = new Date(`${dateValue}T00:00:00`);
  return Number.isFinite(date.getTime()) ? date : null;
}

function formatDayLabel(dateValue, includeYear = false) {
  const date = parseDate(dateValue);
  if (!date) return "";
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    ...(includeYear ? {year: "numeric"} : {}),
  });
}

function formatLongDay(dateValue) {
  const date = parseDate(dateValue);
  if (!date) return "";
  return date.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

function buildDailyChartPoints(dailyPoints, width, height, padding, scaleMax) {
  const innerWidth = width - padding.left - padding.right;
  const innerHeight = height - padding.top - padding.bottom;
  const denominator = Math.max(dailyPoints.length - 1, 1);

  return dailyPoints.map((day, index) => {
    const x = padding.left + (index / denominator) * innerWidth;
    const votes = Number(day.votes) || 0;
    const y = padding.top + innerHeight - (votes / scaleMax) * innerHeight;
    return {...day, x, y};
  });
}

function buildPath(points) {
  return points
    .map((point, index) => `${index === 0 ? "M" : "L"} ${point.x.toFixed(2)} ${point.y.toFixed(2)}`)
    .join(" ");
}

function selectAxisLabels(points, maxLabels = 7) {
  if (points.length <= maxLabels) return points;
  return Array.from({length: maxLabels}, (_, index) => {
    const pointIndex = Math.round((points.length - 1) * index / (maxLabels - 1));
    return points[pointIndex];
  });
}

function classifyDailyValue(votes, average) {
  if (votes > average) return "Above average";
  if (votes < average) return "Below average";
  return "Average";
}

export function VotingActivityChart({activity}) {
  const dailyPoints = activity?.daily_points || [];
  const [hoveredIndex, setHoveredIndex] = React.useState(null);

  if (!dailyPoints.length) {
    return (
      <div className="analytics-empty analytics-activity-empty">
        <strong>No voting activity recorded.</strong>
        <span>The chart will update automatically when votes are recorded.</span>
      </div>
    );
  }

  const width = 900;
  const height = 330;
  const padding = {left: 54, right: 24, top: 28, bottom: 68};
  const maxVotes = Math.max(...dailyPoints.map(day => Number(day.votes) || 0), 1);
  const scaleMax = maxVotes <= 5 ? 5 : Math.ceil(maxVotes / 5) * 5;
  const average = Number(activity?.average_daily_votes) || 0;
  const points = buildDailyChartPoints(dailyPoints, width, height, padding, scaleMax);
  const axisLabels = selectAxisLabels(points);
  const path = buildPath(points);
  const baselineY = height - padding.bottom;
  const areaPath = `${path} L ${points.at(-1).x.toFixed(2)} ${baselineY} L ${points[0].x.toFixed(2)} ${baselineY} Z`;
  const hovered = hoveredIndex === null ? null : points[hoveredIndex];
  const totalVotes = Number(activity?.total_votes) || 0;
  const activeDays = Number(activity?.active_days) || 0;
  const peakDay = activity?.peak_day || null;
  const lowestDay = activity?.lowest_day || null;
  const yTicks = [0, 0.25, 0.5, 0.75, 1];

  return (
    <div className="analytics-activity-chart">

      <div className="activity-chart-stage">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="none"
          role="img"
          aria-label="Daily voting activity across the full election period"
        >
          <text
            x="12"
            y={padding.top + (height - padding.top - padding.bottom) / 2}
            textAnchor="middle"
            className="activity-y-axis-title"
            transform={`rotate(-90 12 ${padding.top + (height - padding.top - padding.bottom) / 2})`}
          >
            Votes / day
          </text>

          {yTicks.map(tick => {
            const y = padding.top + (height - padding.top - padding.bottom) * (1 - tick);
            return (
              <g key={tick}>
                <line
                  x1={padding.left}
                  x2={width - padding.right}
                  y1={y}
                  y2={y}
                  className="activity-grid-line"
                />
                <text
                  x={padding.left - 10}
                  y={y + 4}
                  textAnchor="end"
                  className="activity-axis-label"
                >
                  {Math.round(scaleMax * tick)}
                </text>
              </g>
            );
          })}

          <line
            x1={padding.left}
            x2={width - padding.right}
            y1={baselineY}
            y2={baselineY}
            className="activity-axis-line"
          />

          {average > 0 && (
            <g>
              <line
                x1={padding.left}
                x2={width - padding.right}
                y1={padding.top + (height - padding.top - padding.bottom) - (average / scaleMax) * (height - padding.top - padding.bottom)}
                y2={padding.top + (height - padding.top - padding.bottom) - (average / scaleMax) * (height - padding.top - padding.bottom)}
                className="activity-average-line"
              />
              <text
                x={width - padding.right}
                y={padding.top + (height - padding.top - padding.bottom) - (average / scaleMax) * (height - padding.top - padding.bottom) - 6}
                textAnchor="end"
                className="activity-average-label"
              >
                Average {average.toFixed(1)}
              </text>
            </g>
          )}

          <path d={areaPath} className="activity-area" />
          <path d={path} className="activity-line" />

          {points.map((point, index) => {
            const isHovered = hoveredIndex === index;
            const isPeak = peakDay?.date === point.date && Number(point.votes) === Number(peakDay.votes);
            const isLowest = lowestDay?.date === point.date && Number(point.votes) === Number(lowestDay.votes);
            return (
              <g
                key={point.date}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                className="activity-point-group"
              >
                {isHovered && (
                  <line
                    x1={point.x}
                    x2={point.x}
                    y1={padding.top}
                    y2={baselineY}
                    className="activity-hover-line"
                  />
                )}
                {(isPeak || isLowest) && !isHovered && (
                  <circle cx={point.x} cy={point.y} r="7" className="activity-point-emphasis" />
                )}
                <circle
                  cx={point.x}
                  cy={point.y}
                  r={isHovered ? 7 : 4}
                  className="activity-point"
                />
                <title>
                  {`${formatLongDay(point.date)} · ${point.votes} vote${Number(point.votes) === 1 ? "" : "s"} · ${classifyDailyValue(Number(point.votes), average)}`}
                </title>
              </g>
            );
          })}

          {axisLabels.map((point, index) => {
            const isFirst = index === 0;
            const isLast = index === axisLabels.length - 1;
            return (
              <text
                key={`date-${point.date}`}
                x={point.x}
                y={height - 34}
                textAnchor={isFirst ? "start" : isLast ? "end" : "middle"}
                className="activity-time-label"
              >
                {formatDayLabel(point.date)}
              </text>
            );
          })}
        </svg>

        {hovered && (
          <div
            className="activity-tooltip"
            style={{
              left: `${Math.max(10, Math.min(90, (hovered.x / width) * 100))}%`,
              top: `${Math.max(24, Math.min(78, (hovered.y / height) * 100))}%`,
            }}
          >
            <strong>{formatLongDay(hovered.date)}</strong>
            <span>{hovered.votes} vote{Number(hovered.votes) === 1 ? "" : "s"} recorded</span>
            <span>{classifyDailyValue(Number(hovered.votes), average)} daily activity</span>
            {Number(hovered.votes) === Number(peakDay?.votes) && hovered.date === peakDay?.date && (
              <b>Peak day</b>
            )}
            {Number(hovered.votes) === Number(lowestDay?.votes) && hovered.date === lowestDay?.date && (
              <b>Lowest day</b>
            )}
          </div>
        )}
      </div>

      <div className="analytics-chart-caption">
        <span>One point represents one calendar day. Point height shows the number of votes recorded that day.</span>
        <span>{formatLongDay(dailyPoints[0].date)} → {formatLongDay(dailyPoints.at(-1).date)}</span>
      </div>
    </div>
  );
}

export function DepartmentDonut({departments = [], totalVotes, admin = false}) {
  const parts = departments.filter(item => Number(item.vote_share_percentage) > 0);
  if (!parts.length) return <div className="analytics-empty">No department participation data is available.</div>;

  let offset = 0;
  const gradient = parts.map((item, index) => {
    const start = offset;
    offset += Number(item.vote_share_percentage) || 0;
    return `${CHART_COLORS[index % CHART_COLORS.length]} ${start}% ${offset}%`;
  }).join(", ");

  return (
    <div className="department-donut-layout">
      <div className="department-donut" style={{background: `conic-gradient(${gradient})`}}>
        <div className="department-donut-center">
          {admin && <strong>{totalVotes ?? 0}</strong>}
          <span>{admin ? "Total Votes" : "Total Turnout"}</span>
        </div>
      </div>
      <div className="department-donut-legend">
        {parts.map((item, index) => (
          <div key={item.id}>
            <i style={{background: CHART_COLORS[index % CHART_COLORS.length]}} />
            <span>{item.code || item.name}</span>
            <strong>{Number(item.vote_share_percentage).toFixed(1)}%</strong>
          </div>
        ))}
      </div>
    </div>
  );
}

export function formatDate(value) {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00`);
  return date.toLocaleDateString("en-US", {month: "short", day: "numeric", year: "numeric"});
}

export function formatDateLong(value) {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00`);
  return date.toLocaleDateString("en-US", {month: "long", day: "numeric", year: "numeric"});
}
