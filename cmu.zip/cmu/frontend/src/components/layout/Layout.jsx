import React from "react";
import {useNavigate} from "react-router-dom";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

export function Layout({children}) {
  const nav = useNavigate();
  const {user, logout} = useAuth();

  async function handleLogout() {
    await logout();
    nav("/login", {replace: true});
  }

  return (
    <>
      <header className="topbar modern-topbar">
        <div className="topbar-brand modern-brand">
          <img src={logo} alt="CMU-ELECT Logo" />
          <div className="brand-copy">
            <div className="brand-title-row">
              <span>CMU-ELECT</span>
              <span className="brand-check" aria-hidden="true">✓</span>
            </div>
            <small>Online Voting System</small>
          </div>
        </div>

        <nav className="main-nav modern-nav">
          <span className="user-chip" title={user.email}>{user.email}</span>
          <span className="nav-divider" aria-hidden="true" />
          <button className="modern-logout" onClick={handleLogout}>
            <span className="logout-icon" aria-hidden="true">↪</span>
            Logout
          </button>
        </nav>
      </header>
      {children}
    </>
  );
}
