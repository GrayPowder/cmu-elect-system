import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

export function AdminTopbar() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  async function handleLogout() {
    await logout();
    navigate("/login", { replace: true });
  }

  const navItems = [
    { label: "Dashboard", path: "/admin", end: true },
    { label: "Voters", path: "/admin/users" },
    { label: "Elections", path: "/admin/elections" },
    { label: "Results", path: "/admin/results" },
    { label: "Audit Logs", path: "/admin/audit-logs" },
  ];

  return (
    <header className="admin-dashboard-topbar admin-shared-topbar">
      <div className="admin-brand">
        <img src={logo} alt="CMU-ELECT seal" />
        <div className="admin-brand-copy">
          <strong>CMU-ELECT ADMIN</strong>
          <span>Online Voting System</span>
        </div>
      </div>

      <nav className="admin-topbar-nav" aria-label="Administrator navigation">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.end}
            className={({ isActive }) =>
              `admin-topbar-nav-link${isActive ? " active" : ""}`
            }
          >
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="admin-account-area">
        <span className="admin-account-email">
          {user?.email || "admin@cmu.edu"}
        </span>
        <span className="admin-account-divider" aria-hidden="true" />
        <button className="admin-logout-button" onClick={handleLogout}>
          <span className="admin-logout-icon" aria-hidden="true">
            <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14 5H7v22h7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M17 10l7 6-7 6M23 16H11" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <span>Logout</span>
        </button>
      </div>
    </header>
  );
}
