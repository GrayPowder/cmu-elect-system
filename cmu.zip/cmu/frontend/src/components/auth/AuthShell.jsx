import React from "react";
import {Link} from "react-router-dom";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";

export function AuthShell({children, loginPage = false}) {
  return (
    <div
      className={`auth-page ${loginPage ? "login-auth-page" : ""}`}
      style={{backgroundImage: `url("${cover}")`}}
    >
      <section className="auth-brand">
        <div className="brand-logos">
          <img src={logo} className="brand-elect" alt="CMU-ELECT logo" />
          <span className="brand-logo-divider" aria-hidden="true" />
          <img src={cmu} className="brand-cmu" alt="City of Malabon University logo" />
        </div>

        <h1>CMU-ELECT</h1>
        <p className="auth-brand-title">Online Voting System with Real-Time Data Analytics</p>

        {loginPage ? (
          <>
            <div className="auth-brand-accent" aria-hidden="true" />
            <p className="auth-brand-slogan">Your voice matters.<br />One vote can be the start of something better.</p>
            <div className="auth-brand-features">
              <div><span className="feature-icon shield-icon">✓</span><strong>Secure</strong><small>Your personal information and voting choices are kept confidential.</small></div>
              <i aria-hidden="true" />
              <div><span className="feature-icon chart-icon">▥</span><strong>Transparent</strong><small>Real-time analytics</small></div>
              <i aria-hidden="true" />
              <div><span className="feature-icon people-icon">⚖</span><strong>Your choice</strong><small>Ensures every one has a voice.</small></div>
            </div>
          </>
        ) : null}
      </section>

      {children}
    </div>
  );
}

export function AuthCard({title, children, backToLogin=true}) {
  return <section className="auth-card">
    <h1>{title}</h1>
    {children}
    {backToLogin && <Link className="back-login" to="/login">← back to login</Link>}
  </section>;
}
