import React from "react";
import { mediaUrl } from "../../services/api";
import profileIcon from "../../assets/Profile.png";

function PositionIcon({ position }) {
  const name = String(position || "").toLowerCase();

  if (name.includes("president")) {
    return (
      <svg viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <path d="m24 7 3.2 6.5 7.2 1-5.2 5.1 1.2 7.2-6.4-3.4-6.4 3.4 1.2-7.2-5.2-5.1 7.2-1L24 7Z" fill="currentColor" />
        <path d="M11 31h26M15 31v7h18v-7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      </svg>
    );
  }

  if (name.includes("vice")) {
    return (
      <svg viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <circle cx="18" cy="17" r="6" fill="currentColor" />
        <circle cx="32" cy="19" r="5" fill="currentColor" opacity=".8" />
        <path d="M7 36c1-7 5-10 11-10s10 3 11 10" fill="currentColor" />
        <path d="M27 29c2-2 4-3 7-3 5 0 8 3 9 8" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
      </svg>
    );
  }

  if (name.includes("secret")) {
    return (
      <svg viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <path d="M13 8h22v32H13z" fill="currentColor" opacity=".9" />
        <path d="M19 17h10M19 24h10M19 31h7" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    );
  }

  if (name.includes("treas")) {
    return (
      <svg viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <ellipse cx="24" cy="13" rx="13" ry="5" fill="currentColor" />
        <path d="M11 13v8c0 3 6 5 13 5s13-2 13-5v-8" fill="currentColor" opacity=".85" />
        <path d="M11 21v8c0 3 6 5 13 5s13-2 13-5v-8" fill="currentColor" opacity=".7" />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <path d="M24 7 38 12v10c0 9-6 15-14 19-8-4-14-10-14-19V12l14-5Z" fill="currentColor" />
      <path d="m18 24 4 4 8-9" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function getPositionTheme(index) {
  const themes = ["blue", "green", "purple", "orange", "teal"];
  return themes[index % themes.length];
}

function CandidateAvatar({ candidate }) {
  const [imageFailed, setImageFailed] = React.useState(false);
  const photo = candidate.photo && !imageFailed ? mediaUrl(candidate.photo) : profileIcon;

  return (
    <img
      className="results-candidate-avatar"
      src={photo}
      alt=""
      onError={() => setImageFailed(true)}
    />
  );
}

export function ResultsContent({ data }) {
  const electionName = data?.election?.name || "Election";
  const totalVoters = Number(data?.total_voters ?? 0);

  return (
    <div className="admin-results-content">
      <section className="admin-results-election-summary">
        <div className="admin-results-election-icon" aria-hidden="true">
          <svg viewBox="0 0 48 48" fill="none">
            <rect x="9" y="11" width="30" height="29" rx="4" stroke="currentColor" strokeWidth="3" />
            <path d="M15 7v8M33 7v8M9 20h30" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
            <path d="M17 27h5M26 27h5M17 33h5" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="admin-results-election-copy">
          <span>ELECTION</span>
          <h2>{electionName}</h2>
          <div className="admin-results-election-meta">
            <span>
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="5" width="16" height="15" rx="2" stroke="currentColor" strokeWidth="2" /><path d="M8 3v4M16 3v4M4 10h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>
              Ended
            </span>
            <i aria-hidden="true" />
            <span>
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="9" cy="8" r="3" fill="currentColor" /><circle cx="17" cy="9" r="2.5" fill="currentColor" opacity=".8" /><path d="M3 19c.5-3.5 2.5-5 6-5s5.5 1.5 6 5M14 15c3-.5 5.5.8 6 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>
              Total Voters: {totalVoters}
            </span>
          </div>
        </div>
        <div className="admin-results-summary-art" aria-hidden="true" />
      </section>

      {data.results.length > 0 ? (
        <div className="admin-results-grid">
          {data.results.map((result, index) => {
            const theme = getPositionTheme(index);
            const positionTotal = Number(result.total_votes || 0);

            return (
              <section className={`admin-result-card theme-${theme}`} key={result.position_id}>
                <div className="admin-result-card-header">
                  <div className="admin-result-position-icon"><PositionIcon position={result.position} /></div>
                  <div>
                    <h3>{result.position}</h3>
                    <span>Final result percentages</span>
                  </div>
                </div>

                <div className="admin-result-card-body">
                  {result.candidates.length > 0 ? result.candidates.map((candidate) => {
                    const percentage = Number(candidate.percentage || 0);
                    return (
                      <div className="admin-result-candidate" key={candidate.id}>
                        <div className="admin-result-candidate-main">
                          <CandidateAvatar candidate={candidate} />
                          <div className="admin-result-candidate-info">
                            <div className="admin-result-candidate-name-row">
                              <strong>{candidate.candidate}</strong>
                              <b>{percentage.toFixed(2)}%</b>
                            </div>
                            <div className="admin-result-progress" aria-label={`${percentage.toFixed(2)} percent`}>
                              <span style={{ width: `${Math.max(0, Math.min(100, percentage))}%` }} />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  }) : (
                    <div className="admin-result-empty-candidates">No candidates configured for this position.</div>
                  )}
                </div>

                {result.winners?.length > 0 && positionTotal > 0 && (
                  <div className="admin-result-winner-note">
                    Winner{result.winners.length > 1 ? "s" : ""}: {result.winners.map((winner) => winner.candidate).join(", ")}
                  </div>
                )}
              </section>
            );
          })}
        </div>
      ) : (
        <div className="admin-results-no-results">
          <div className="admin-results-no-results-icon">✓</div>
          <h2>No positions found</h2>
          <p>This ended election does not have any configured positions.</p>
        </div>
      )}
    </div>
  );
}
