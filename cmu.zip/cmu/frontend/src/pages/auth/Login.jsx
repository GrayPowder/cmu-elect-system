import React, {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import {useAuth} from "../../context/AuthContext";
import {AuthShell} from "../../components/auth/AuthShell";
import {PasswordInput} from "../../components/auth/PasswordInput";
import emailIcon from "../../assets/Email.png";

function BallotIcon() {
  return (
    <svg className="login-welcome-icon" viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <path d="M14 18h20a4 4 0 0 1 4 4v15H10V22a4 4 0 0 1 4-4Z" fill="currentColor" opacity=".96"/>
      <path d="M18 18v-5a6 6 0 0 1 12 0v5" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
      <rect x="17" y="8" width="14" height="13" rx="2.5" fill="#fff"/>
      <path d="m21 14 2 2 4-5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

export function Login() {
  const nav = useNavigate();
  const {login} = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      // The account category is determined by the authenticated backend
      // profile. Voters no longer select Student/Alumni/Faculty manually.
      const user = await login({email, password});
      if (user.is_admin) {
        nav("/admin", {replace: true});
      } else {
        nav(user.must_change_password ? "/change-password" : "/dashboard", {replace: true});
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell loginPage>
      <form className="auth-card login-card login-card-modern" onSubmit={submit}>
        <div className="login-welcome-mark"><BallotIcon /></div>
        <h1>Welcome!</h1>
        <p className="login-subtitle">Sign in to cast your vote and become an instrument for change.</p>

        <label htmlFor="login-identifier">Email or CMU Email</label>
        <div className="input-wrap">
          <img src={emailIcon} alt="" />
          <input
            id="login-identifier"
            name="email"
            type="text"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="enter your username or email"
            autoComplete="username"
            required
          />
        </div>

        <label htmlFor="login-password">Password</label>
        <PasswordInput
          id="login-password"
          name="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          placeholder="enter your password"
          autoComplete="current-password"
          required
        />

        {error && <div className="error login-error">{error}</div>}
        <button className="primary login-submit" disabled={loading}>
          <span>{loading ? "Signing In..." : "Sign In"}</span>
          {!loading && <span className="login-submit-arrow" aria-hidden="true">→</span>}
        </button>
        <Link className="forgot-link" to="/forgot-password">Forgot Password?</Link>

        <div className="login-card-footer" aria-hidden="true">
          <span />
          <b>CMU-ELECT</b>
          <span />
        </div>
      </form>
    </AuthShell>
  );
}
