import React, {useEffect, useState} from "react";
import {useSearchParams} from "react-router-dom";
import {useNavigate} from "react-router-dom";
import {AuthShell, AuthCard} from "../../components/auth/AuthShell";
import {resetPassword} from "../../services/authService";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import {PasswordInput} from "../../components/auth/PasswordInput";

export function ResetPassword() {
  const nav = useNavigate();
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState(() => searchParams.get("email")?.trim().toLowerCase() || sessionStorage.getItem("cmu_elect_reset_email") || "");
  const [resetToken, setResetToken] = useState(() => searchParams.get("token") || sessionStorage.getItem("cmu_elect_reset_token") || "");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const linkEmail = searchParams.get("email")?.trim().toLowerCase();
    const linkToken = searchParams.get("token");

    if (linkEmail && linkToken) {
      setEmail(linkEmail);
      setResetToken(linkToken);
      // Store the link credentials so the reset form still works if the URL
      // is refreshed during the same browser session.
      sessionStorage.setItem("cmu_elect_reset_email", linkEmail);
      sessionStorage.setItem("cmu_elect_reset_token", linkToken);
      return;
    }

    if (!email || !resetToken) nav("/forgot-password", {replace: true});
  }, [searchParams, email, resetToken, nav]);

  async function submit(e) {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      await resetPassword({email, reset_token: resetToken, password, confirm_password: confirmPassword});
      sessionStorage.removeItem("cmu_elect_reset_email");
      sessionStorage.removeItem("cmu_elect_reset_token");
      nav("/login", {replace: true});
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  return <AuthShell>
    <AuthCard title="RESET PASSWORD">
      <form onSubmit={submit}>
        <label htmlFor="new-password">New password</label>
        <PasswordInput
          id="new-password"
          name="newPassword"
          minLength="8"
          value={password}
          onChange={e => setPassword(e.target.value)}
          placeholder="at least 8 characters"
          autoComplete="new-password"
          required
        />

        <label htmlFor="confirm-password">Confirm password</label>
        <PasswordInput
          id="confirm-password"
          name="confirmPassword"
          minLength="8"
          value={confirmPassword}
          onChange={e => setConfirmPassword(e.target.value)}
          placeholder="repeat your new password"
          autoComplete="new-password"
          required
        />
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={loading}>{loading ? "Saving..." : "Reset Password"}</button>
      </form>
    </AuthCard>
  </AuthShell>;
}
