import React, {useState} from "react";
import {useNavigate} from "react-router-dom";
import {AuthShell, AuthCard} from "../../components/auth/AuthShell";
import {changePassword} from "../../services/authService";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";
import cmu from "../../assets/image-removebg-preview 1.png";
import cover from "../../assets/cover blue.png";
import {PasswordInput} from "../../components/auth/PasswordInput";

export function ChangePassword() {
  const nav = useNavigate();
  const {user, updateSession, logout} = useAuth();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const data = await changePassword({
        current_password: currentPassword,
        new_password: newPassword,
        confirm_password: confirmPassword,
      });
      updateSession({
        token: data.token,
        user: {...user, must_change_password: data.must_change_password},
      });
      setCurrentPassword(""); setNewPassword(""); setConfirmPassword("");
      nav("/dashboard", {replace: true});
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  return <AuthShell>
    <AuthCard title="CHANGE PASSWORD" backToLogin={false}>
      <p className="forgot-copy">Your administrator provided an initial password. Change it before accessing the voting system.</p>
      <form onSubmit={submit}>
        <label>Current password</label>
        <PasswordInput value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)} autoComplete="current-password" required />
        <label>New password</label>
        <PasswordInput value={newPassword} onChange={e=>setNewPassword(e.target.value)} minLength="8" placeholder="at least 8 characters" autoComplete="new-password" required />
        <label>Confirm new password</label>
        <PasswordInput value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} minLength="8" placeholder="repeat your new password" autoComplete="new-password" required />
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={loading}>{loading ? "Saving..." : "Change Password"}</button>
      </form>
      <button className="cancel-button" onClick={async ()=>{await logout();nav("/login", {replace: true})}}>Log out</button>
    </AuthCard>
  </AuthShell>;
}

