import React, {useState} from "react";
import {useNavigate} from "react-router-dom";
import {AuthShell, AuthCard} from "../../components/auth/AuthShell";
import {
  requestPasswordReset,
  verifyResetCode,
  resendResetCode
} from "../../services/authService";
import emailIcon from "../../assets/Email.png";

export function ForgotPassword() {
  const nav = useNavigate();

  const [step, setStep] = useState("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function requestCode(e) {
    e.preventDefault();

    setError("");
    setMessage("");
    setLoading(true);

    try {
      const normalizedEmail = email.trim().toLowerCase();
      const data = await requestPasswordReset(normalizedEmail);

      /*
       * The backend decides whether this is an administrator account.
       *
       * Admin:
       *   Email -> reset link -> Reset Password
       *
       * Voter:
       *   Email -> OTP -> Reset Password
       */
      if (data.reset_method === "link") {
        setMessage(
          data.detail ||
          "A password reset link has been sent to your email. Please check your inbox."
        );

        setStep("admin-link");
      } else {
        setMessage(
          data.detail ||
          "A verification code has been sent to your email."
        );

        setStep("code");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function verifyCode(e) {
    e.preventDefault();

    setError("");
    setMessage("");
    setLoading(true);

    try {
      const data = await verifyResetCode({
        email,
        code,
      });

      sessionStorage.setItem(
        "cmu_elect_reset_email",
        email.trim().toLowerCase()
      );

      sessionStorage.setItem(
        "cmu_elect_reset_token",
        data.reset_token
      );

      nav("/reset-password");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function resendCode() {
    setError("");
    setMessage("");
    setLoading(true);

    try {
      const data = await resendResetCode(email);

      setMessage(
        data.detail || "A new verification code has been sent."
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  /*
   * ADMIN RESET LINK SCREEN
   *
   * The administrator does NOT enter an OTP.
   * The reset link is already included in the email.
   */
  if (step === "admin-link") {
    return (
      <AuthShell>
        <AuthCard title="CHECK YOUR EMAIL">
          <p className="small-label">PASSWORD RESET LINK SENT</p>

          <p className="forgot-copy">
            We sent a password reset link to your CMU email.
            Open your email and click the link to continue changing
            your password.
          </p>

          <p className="forgot-copy">
            You do not need to enter a verification code.
          </p>

          {message && <div className="info">{message}</div>}
          {error && <div className="error">{error}</div>}

          <button
            type="button"
            className="primary"
            onClick={() => nav("/login")}
          >
            BACK TO LOGIN
          </button>
        </AuthCard>
      </AuthShell>
    );
  }

  /*
   * NORMAL VOTER OTP SCREEN
   */
  if (step === "code") {
    return (
      <AuthShell>
        <AuthCard title="VERIFICATION">
          <p className="small-label">CHECK YOUR EMAIL</p>

          <p className="forgot-copy">
            Enter the verification code sent to your CMU email
            to continue resetting your password.
          </p>

          <form onSubmit={verifyCode}>
            <label htmlFor="verification-code">
              Verification code
            </label>

            <input
              id="verification-code"
              name="verificationCode"
              className="code-input"
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength="6"
              value={code}
              onChange={(e) =>
                setCode(e.target.value.replace(/\D/g, ""))
              }
              placeholder="000000"
              required
            />

            <p className="resend-copy">
              Didn't receive a code?{" "}
              <button
                type="button"
                onClick={resendCode}
                disabled={loading}
              >
                Resend
              </button>
            </p>

            {message && <div className="info">{message}</div>}
            {error && <div className="error">{error}</div>}

            <button
              className="primary"
              disabled={loading}
            >
              {loading ? "Verifying..." : "VERIFY"}
            </button>
          </form>
        </AuthCard>
      </AuthShell>
    );
  }

  /*
   * EMAIL INPUT SCREEN
   */
  return (
    <AuthShell>
      <AuthCard title="FORGOT PASSWORD">
        <p className="forgot-copy">
          Enter your CMU email and we'll send the instructions
          needed to reset your password.
        </p>

        <form onSubmit={requestCode}>
          <div className="input-wrap">
            <img src={emailIcon} alt="" />

            <input
              id="forgot-password-email"
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="enter your email"
              autoComplete="email"
              required
            />
          </div>

          {message && <div className="info">{message}</div>}
          {error && <div className="error">{error}</div>}

          <button
            className="primary"
            disabled={loading}
          >
            {loading ? "SENDING..." : "SUBMIT"}
          </button>
        </form>
      </AuthCard>
    </AuthShell>
  );
}
