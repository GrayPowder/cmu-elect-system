import React, {useEffect, useMemo, useState} from "react";
import {Link, useParams} from "react-router-dom";
import {getElection} from "../../services/electionService";
import {mediaUrl} from "../../services/api";
import {Layout} from "../../components/layout/Layout";
import profilePlaceholder from "../../assets/Profile.png";

function Icon({name, size = 22}) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": true,
  };

  const paths = {
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    building: <><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-4h6v4"/><path d="M9 9h.01M12 9h.01M15 9h.01M9 12h.01M12 12h.01M15 12h.01"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    wifi: <><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.5 16a6 6 0 0 1 7 0"/><path d="M12 20h.01"/></>,
    calendar: <><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 17h.01M12 17h.01"/></>,
    crown: <><path d="m3 7 4 4 5-7 5 7 4-4-2 12H5L3 7Z"/><path d="M5 19h14"/></>,
    shield: <><path d="M12 3 20 6v5c0 5-3.4 8.8-8 10-4.6-1.2-8-5-8-10V6z"/><path d="m9 12 2 2 4-4"/></>,
    megaphone: <><path d="m3 11 18-5v12L3 13z"/><path d="M11 14v5a2 2 0 0 1-2 2H8"/></>,
    arrow: <><path d="m9 18 6-6-6-6"/></>,
    arrowLeft: <><path d="m15 18-6-6 6-6"/></>,
    arrowRight: <><path d="m9 18 6-6-6-6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    send: <><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></>,
    eye: <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></>,
  };

  return <svg {...common}>{paths[name]}</svg>;
}

function statusLabel(status) {
  if (status === "not_started") return "UPCOMING";
  if (status === "ended") return "ENDED";
  return "ACTIVE";
}

function availabilityLabel(availability) {
  if (availability === "not_started") return "Voting Not Yet Available";
  if (availability === "ended") return "Voting Ended";
  return "Voting Available";
}

function getDepartmentText(election) {
  const scope = String(election?.department_scope || "").toLowerCase();
  if (scope !== "specific") return "All Departments";

  const departments = election?.eligible_department_details || [];
  if (!departments.length) return "Department information unavailable";
  return departments.map(department => department.name).join(", ");
}

function getCandidatePhoto(candidate) {
  const photo = typeof candidate?.photo === "string"
    ? candidate.photo
    : candidate?.photo?.url;
  return photo ? mediaUrl(photo) : profilePlaceholder;
}

export function ElectionDetails() {
  const {electionId} = useParams();
  const [election, setElection] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedPositionId, setSelectedPositionId] = useState(null);
  const [expandedCandidateId, setExpandedCandidateId] = useState(null);

  useEffect(() => {
    let isMounted = true;

    setLoading(true);
    setError("");
    setElection(null);
    setSelectedPositionId(null);
    setExpandedCandidateId(null);

    getElection(electionId)
      .then(data => {
        if (isMounted) setElection(data);
      })
      .catch(e => {
        if (isMounted) setError(e.message);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [electionId]);

  const positions = election?.positions || [];

  const selectedPosition = useMemo(() => {
    if (!positions.length) return null;
    return positions.find(position => position.id === selectedPositionId) || positions[0];
  }, [positions, selectedPositionId]);

  useEffect(() => {
    if (positions.length && !selectedPositionId) {
      setSelectedPositionId(positions[0].id);
    }
  }, [positions, selectedPositionId]);

  const hasCandidates = positions.some(position => position.candidates?.length > 0);
  const canProceedToBallot = Boolean(election?.is_open && hasCandidates);
  const status = election?.status || "active";
  const active = status === "active" && election?.is_open;
  const departmentText = getDepartmentText(election);

  if (loading) {
    return (
      <Layout>
        <main className="election-preview-page">
          <div className="loading-state modern-loading election-preview-loading">
            <span className="spinner" /> Loading election...
          </div>
        </main>
      </Layout>
    );
  }

  return (
    <Layout>
      <main className="election-preview-page">
        {error && <div className="error modern-alert election-preview-alert">{error}</div>}

        {election && (
          <>
            <section className="election-preview-hero" aria-labelledby="election-preview-title">
              <div className="election-preview-hero-copy">
                <span className="election-preview-kicker">YOUR VOICE. OUR FUTURE.</span>
                <h1 id="election-preview-title">{election.name || "Student Election"}</h1>
                <p>Review the election information, positions, and candidates.</p>
                <span className="election-preview-hero-line" />
              </div>
              <div className="election-preview-hero-art" aria-hidden="true">
                <div className="election-preview-ray ray-one" />
                <div className="election-preview-ray ray-two" />
                <div className="election-preview-ray ray-three" />
                <div className="election-preview-ballot-box">
                  <div className="election-preview-ballot-paper"><Icon name="check" size={42}/></div>
                  <div className="election-preview-slot" />
                </div>
                <div className="election-preview-slogan">Your Vote<br/><em>Matters</em></div>
              </div>
            </section>

            <section className="election-preview-summary" aria-label="Election information">
              <div className="election-preview-summary-heading">
                <div className="election-preview-calendar-icon"><Icon name="calendar" size={31}/></div>
                <div>
                  <div className="election-preview-title-row">
                    <h2>{election.name || "Election"}</h2>
                    <span className={`election-preview-status ${active ? "active" : status === "ended" ? "ended" : "upcoming"}`}>
                      <b /> {statusLabel(status)}
                    </span>
                  </div>
                  <p>{election.description || "No description provided."}</p>
                </div>
              </div>

              <div className="election-preview-status-mobile">
                <span className={`election-preview-status ${active ? "active" : status === "ended" ? "ended" : "upcoming"}`}>
                  <b /> {statusLabel(status)}
                </span>
              </div>

              <div className="election-preview-info-grid">
                <div className="election-preview-info-card">
                  <span className="election-preview-info-icon blue"><Icon name="users" size={23}/></span>
                  <span><small>Voter Category</small><strong>{election.eligible_voter_category_display || election.audience || "Not specified"}</strong></span>
                </div>
                <div className="election-preview-info-card">
                  <span className="election-preview-info-icon indigo"><Icon name="building" size={23}/></span>
                  <span><small>Eligible Department{String(election.department_scope || "").toLowerCase() === "specific" ? "s" : ""}</small><strong>{departmentText}</strong></span>
                </div>
                <div className="election-preview-info-card election-preview-info-wide">
                  <span className="election-preview-info-icon blue"><Icon name="clock" size={23}/></span>
                  <span><small>Voting Period</small><strong>{new Date(election.start_datetime).toLocaleString()} — {new Date(election.end_datetime).toLocaleString()}</strong></span>
                </div>
                <div className="election-preview-info-card">
                  <span className="election-preview-info-icon cyan"><Icon name="wifi" size={23}/></span>
                  <span><small>Availability</small><strong className={active ? "available" : "unavailable"}>{availabilityLabel(election.voting_availability)}</strong></span>
                </div>
              </div>
            </section>

            <section className="election-preview-candidates" aria-labelledby="candidates-positions-title">
              <div className="election-preview-section-heading">
                <div>
                  <span className="election-preview-section-kicker"><Icon name="users" size={24}/> CANDIDATES &amp; POSITIONS</span>
                  <p id="candidates-positions-title">Meet the candidates and explore their platforms.</p>
                </div>
              </div>

              {positions.length === 0 ? (
                <div className="election-preview-empty">No positions are available for this election.</div>
              ) : (
                <div className="election-preview-position-layout">
                  <aside className="election-preview-position-list" aria-label="Election positions">
                    {positions.map((position, index) => {
                      const selected = selectedPosition?.id === position.id;
                      const iconName = index === 0 ? "crown" : index === positions.length - 1 ? "shield" : index === 3 ? "megaphone" : "users";
                      return (
                        <button
                          key={position.id}
                          type="button"
                          className={`election-preview-position-button ${selected ? "selected" : ""}`}
                          onClick={() => {
                            setSelectedPositionId(position.id);
                            setExpandedCandidateId(null);
                          }}
                          aria-pressed={selected}
                        >
                          <span className={`election-preview-position-icon position-${index % 5}`}><Icon name={iconName} size={22}/></span>
                          <span className="election-preview-position-copy">
                            <strong>{position.name}</strong>
                            <small>{position.candidates?.length || 0} Candidate{position.candidates?.length === 1 ? "" : "s"}</small>
                          </span>
                          <Icon name="arrowRight" size={19}/>
                        </button>
                      );
                    })}
                  </aside>

                  <div className="election-preview-candidate-panel">
                    {selectedPosition && (
                      <>
                        <div className="election-preview-panel-heading">
                          <div className="election-preview-panel-icon"><Icon name="crown" size={26}/></div>
                          <div>
                            <h2>{selectedPosition.name}</h2>
                            <p>
                              {selectedPosition.candidates?.length || 0} candidate{selectedPosition.candidates?.length === 1 ? "" : "s"} are running for this position.
                            </p>
                          </div>
                        </div>

                        {selectedPosition.candidates?.length ? (
                          <div className="election-preview-candidate-grid">
                            {selectedPosition.candidates.map((candidate, index) => {
                              const expanded = expandedCandidateId === candidate.id;
                              return (
                                <article className="election-preview-candidate-card" key={candidate.id}>
                                  <div className={`election-preview-candidate-accent accent-${index % 4}`} />
                                  <div className="election-preview-candidate-photo-wrap">
                                    <img
                                      className="election-preview-candidate-photo"
                                      src={getCandidatePhoto(candidate)}
                                      alt={`${candidate.name} profile`}
                                      onError={event => {
                                        if (event.currentTarget.src !== profilePlaceholder) event.currentTarget.src = profilePlaceholder;
                                      }}
                                    />
                                  </div>
                                  <div className="election-preview-candidate-body">
                                    <span className="election-preview-rank">Candidate {index + 1}</span>
                                    <h3>{candidate.name}</h3>
                                    <p className="election-preview-party">
                                      {candidate.party_list ? `Party List: ${candidate.party_list}` : "Independent Candidate"}
                                    </p>
                                    {candidate.department && <p className="election-preview-candidate-meta">{candidate.department}</p>}
                                    {candidate.platform && (
                                      <>
                                        <p className={`election-preview-platform ${expanded ? "expanded" : ""}`}>
                                          {candidate.platform}
                                        </p>
                                        <button
                                          type="button"
                                          className="election-preview-platform-button"
                                          onClick={() => setExpandedCandidateId(expanded ? null : candidate.id)}
                                          aria-expanded={expanded}
                                        >
                                          <Icon name="eye" size={17}/>
                                          {expanded ? "Hide Platform" : "View Platform"}
                                          <Icon name="arrowRight" size={16}/>
                                        </button>
                                      </>
                                    )}
                                  </div>
                                  <span className="election-preview-card-corner" aria-hidden="true" />
                                </article>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="election-preview-empty election-preview-empty-panel">
                            No candidates are available for this position.
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              )}
            </section>

            <div className="election-preview-actions">
              <Link className="election-preview-secondary-action" to="/dashboard">
                <Icon name="arrowLeft" size={19}/> Back to Dashboard
              </Link>
              {canProceedToBallot && (
                <Link className="election-preview-primary-action" to={`/vote/${election.id}`}>
                  <span>Proceed to Ballot</span><Icon name="send" size={18}/>
                </Link>
              )}
            </div>
          </>
        )}
      </main>
    </Layout>
  );
}
