import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getElection } from "../../services/electionService";
import { mediaUrl } from "../../services/api";
import { Layout } from "../../components/layout/Layout";
import profileIcon from "../../assets/Profile.png";
import secureVotingIcon from "../../assets/secure-voting.png";

export function BallotPage() {
  const { electionId } = useParams();
  const nav = useNavigate();
  const [election, setElection] = useState(null);
  const [selections, setSelections] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getElection(electionId)
      .then(data => {
        if (!data.is_open) {
          setError(
            data.status === "not_started"
              ? "Voting for this election has not started."
              : "Voting for this election has ended."
          );
        }
        setElection(data);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [electionId]);

  function selectCandidate(positionId, candidateId) {
    setSelections(current => ({ ...current, [positionId]: candidateId }));
  }

  function review() {
    setError("");
    if (!election?.is_open) return;

    if (Object.keys(selections).length === 0) {
      setError("Please select at least one candidate before continuing.");
      return;
    }

    nav(`/vote/${election.id}/review`, { state: { election, selections } });
  }

  if (loading) {
    return (
      <Layout>
        <main className="ballot-page-shell">
          <div className="ballot-loading">
            <span className="spinner" /> Loading ballot...
          </div>
        </main>
      </Layout>
    );
  }

  const positions = election?.positions || [];
  const positionCount = positions.length;
  const selectedCount = positions.filter(position => selections[position.id] != null).length;

  return (
    <Layout>
      <main className="ballot-page-shell">
        <section className="ballot-intro">
          <div className="ballot-intro-main">
            <div className="ballot-title-icon" aria-hidden="true">
              <span>✓</span>
            </div>
            <div>
              <p className="ballot-kicker">CAST YOUR VOTE</p>
              <h1>{election?.name || "Student Election"}</h1>
              <p>Select one candidate for each position, then review your ballot before submitting.</p>
            </div>
          </div>

          <div className="ballot-security" aria-label="Secure and anonymous voting">
            <img
                src={secureVotingIcon}
                alt=""
                className="ballot-security-icon"
              />
            <div>
              <strong>Secure &amp; Anonymous Voting</strong>
              <span>Your vote is confidential and protected.</span>
            </div>
          </div>
        </section>

        {error && <div className="error ballot-error">{error}</div>}

        {election && election.is_open && (
          <>
            <div className="ballot-position-list">
              {positions.map((position, index) => {
                const selectedCandidateId = selections[position.id];
                const positionAccent = index % 3;

                return (
                  <section
                    className={`ballot-position-modern accent-${positionAccent}`}
                    key={position.id}
                  >
                    <div className="ballot-position-header">
                      <div className="ballot-position-heading">
                        <span className="ballot-position-number">{String(index + 1).padStart(2, "0")}</span>
                        <div>
                          <h2>{position.name}</h2>
                          <p>Choose 1 candidate</p>
                        </div>
                      </div>
                      <span className="ballot-position-limit">1 Position</span>
                    </div>

                    <div className="ballot-candidate-grid">
                      {position.candidates.map(candidate => {
                        const selected = selectedCandidateId === candidate.id;

                        return (
                          <article
                            className={`ballot-candidate-card ${selected ? "selected" : ""}`}
                            onClick={() => selectCandidate(position.id, candidate.id)}
                            onKeyDown={event => {
                              if (event.key === "Enter" || event.key === " ") {
                                event.preventDefault();
                                selectCandidate(position.id, candidate.id);
                              }
                            }}
                            role="radio"
                            aria-checked={selected}
                            tabIndex={0}
                            key={candidate.id}
                          >
                            <div className="ballot-candidate-photo-wrap">
                              <img
                                src={candidate.photo ? mediaUrl(candidate.photo) : profileIcon}
                                alt=""
                                className="ballot-candidate-photo"
                              />
                            </div>

                            <div className="ballot-candidate-info">
                              {candidate.party_list && (
                                <span className="ballot-party">{candidate.party_list}</span>
                              )}
                              <h3>{candidate.name}</h3>
                              {candidate.department && <p>{candidate.department}</p>}
                              {candidate.platform && (
                                <p className="ballot-platform">
                                  <strong>Platform:</strong> {candidate.platform}
                                </p>
                              )}
                            </div>

                            <span className="ballot-radio" aria-hidden="true">
                              {selected && <span />}
                            </span>
                          </article>
                        );
                      })}
                    </div>
                  </section>
                );
              })}
            </div>

            <div className="ballot-bottom-bar">
              <div className="ballot-selection-summary">
                <span className="ballot-summary-icon" aria-hidden="true">✓</span>
                <div>
                  <span>You have selected</span>
                  <strong>{selectedCount} / {positionCount} candidates</strong>
                </div>
              </div>

              <div className="ballot-actions">
                <Link className="ballot-back-button" to={`/elections/${election.id}`}>
                  <span aria-hidden="true">←</span>
                  Back
                </Link>
                <button className="ballot-review-button" onClick={review}>
                  Review Ballot
                  <span aria-hidden="true">→</span>
                </button>
              </div>
            </div>
          </>
        )}
      </main>
    </Layout>
  );
}
