import React, { useState } from "react";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import { submitVotes } from "../../services/votingService";
import { mediaUrl } from "../../services/api";
import { Layout } from "../../components/layout/Layout";
import profileIcon from "../../assets/Profile.png";
import secureVotingIcon from "../../assets/secure-voting.png";

function Icon({ name, size = 24 }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    "aria-hidden": "true",
  };

  if (name === "clipboard") return (
    <svg {...common}>
      <rect x="6" y="4" width="12" height="17" rx="2" stroke="currentColor" strokeWidth="2" />
      <path d="M9 4.5V3.5C9 2.67 9.67 2 10.5 2h3c.83 0 1.5.67 1.5 1.5v1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="m9 11 1.5 1.5L14 9M9 16h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  if (name === "users") return (
    <svg {...common}>
      <circle cx="9" cy="8" r="3" fill="currentColor" />
      <circle cx="16" cy="9" r="2.5" fill="currentColor" opacity=".75" />
      <path d="M3.5 19c.4-3.1 2.2-5 5.5-5s5.1 1.9 5.5 5H3.5Z" fill="currentColor" />
      <path d="M14 14.8c2.7-.4 5.3 1.1 6 4.2h-4.3" fill="currentColor" opacity=".75" />
    </svg>
  );

  if (name === "crown") return (
    <svg {...common}>
      <path d="M4 9.5 7.3 13h9.4L20 9.5l-1.2 9H5.2L4 9.5Z" fill="currentColor" />
      <path d="m4 9.5 3-4 3 3 2-4 2 4 3-3 3 4" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
      <path d="M6 20h12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );

  if (name === "person") return (
    <svg {...common}>
      <circle cx="12" cy="8" r="4" fill="currentColor" />
      <path d="M4.5 21c.7-4.1 3.1-6 7.5-6s6.8 1.9 7.5 6h-15Z" fill="currentColor" />
    </svg>
  );

  if (name === "document") return (
    <svg {...common}>
      <rect x="5" y="3" width="14" height="18" rx="2" fill="currentColor" />
      <path d="M9 8h6M9 12h6M9 16h4" stroke="#fff" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );

  if (name === "coins") return (
    <svg {...common}>
      <ellipse cx="12" cy="7" rx="7" ry="3" fill="currentColor" />
      <path d="M5 7v5c0 1.7 3.1 3 7 3s7-1.3 7-3V7M5 12v5c0 1.7 3.1 3 7 3s7-1.3 7-3v-5" stroke="currentColor" strokeWidth="2" />
    </svg>
  );

  if (name === "shield") return (
    <svg {...common}>
      <path d="M12 3 19 6v5.4c0 4.4-2.7 7.7-7 9.6-4.3-1.9-7-5.2-7-9.6V6l7-3Z" fill="currentColor" />
      <path d="m8.5 12 2.1 2.1 4.9-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  if (name === "check") return (
    <svg {...common}>
      <circle cx="12" cy="12" r="10" fill="currentColor" />
      <path d="m8 12 2.5 2.5L16.5 9" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  if (name === "send") return (
    <svg {...common}>
      <path d="m3 4 18 8-18 8 3.5-7.3L14 12l-7.5-.7L3 4Z" fill="currentColor" />
    </svg>
  );

  return null;
}

function positionIcon(name) {
  const value = String(name || "").toLowerCase();
  if (value.includes("president")) return value.includes("vice") ? "person" : "crown";
  if (value.includes("secretary")) return "document";
  if (value.includes("treasurer")) return "coins";
  return "shield";
}

export function ReviewBallot() {
  const { electionId } = useParams();
  const nav = useNavigate();
  const location = useLocation();
  const state = location.state;
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!state?.election || String(state.election.id) !== String(electionId)) {
    return (
      <Layout>
        <main className="center">
          <div className="error">Your ballot session is no longer available. Please return to the election and start again.</div>
          <button className="primary" onClick={() => nav(`/vote/${electionId}`)}>Return to Ballot</button>
        </main>
      </Layout>
    );
  }

  const { election, selections } = state;
  const positions = election.positions || [];
  const selectedCount = positions.filter(position => selections?.[position.id] != null).length;
  const positionCount = positions.length;
  const allSelected = positionCount > 0 && selectedCount === positionCount;

  async function submit() {
    setSubmitting(true);
    setError("");
    try {
      const votes = Object.entries(selections).map(([position_id, candidate_id]) => ({
        position_id: Number(position_id),
        candidate_id: Number(candidate_id),
      }));
      const data = await submitVotes({ electionId: election.id, votes });
      nav(`/vote/${election.id}/confirmation`, { state: { confirmation: data } });
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Layout>
      <main className="review-ballot-shell">
        <section className="review-ballot-hero">
          <div className="review-hero-main">
            <div className="review-hero-icon"><Icon name="clipboard" size={42} /></div>
            <div>
              <p className="review-kicker">FINAL CHECK</p>
              <h1>Review Ballot</h1>
              <p>Check your selections before submitting your vote.</p>
            </div>
          </div>

          <div className="review-security">
            <img src={secureVotingIcon} alt="" />
            <div>
              <strong>Secure &amp; Anonymous Voting</strong>
              <span>Your vote is confidential and protected.</span>
            </div>
          </div>
        </section>

        <section className="review-ballot-card">
          <div className="review-selection-heading">
            <div className="review-selection-title">
              <span className="review-users-icon"><Icon name="users" size={31} /></span>
              <h2>Your Selections</h2>
              <span className={`review-count-pill ${allSelected ? "complete" : ""}`}>
                <Icon name="check" size={18} />
                {selectedCount} / {positionCount} positions selected
              </span>
            </div>

            <div className={`review-complete-note ${allSelected ? "complete" : "pending"}`}>
              <span><Icon name={allSelected ? "shield" : "clipboard"} size={20} /></span>
              <div>
                <strong>{allSelected ? "You've completed all positions." : "Some positions are still unselected."}</strong>
                <small>{allSelected ? "You can now submit your vote." : "Return to the ballot to complete your selections."}</small>
              </div>
            </div>
          </div>

          <div className="review-selection-list">
            {positions.map((position, index) => {
              const candidateId = selections?.[position.id];
              const candidate = position.candidates?.find(c => c.id === Number(candidateId));
              if (!candidate) return null;

              return (
                <article className={`review-selection-row accent-${index % 5}`} key={position.id}>
                  <div className="review-position-block">
                    <span className="review-position-icon"><Icon name={positionIcon(position.name)} size={26} /></span>
                    <div>
                      <strong>{position.name}</strong>
                      <small>1 position</small>
                    </div>
                  </div>

                  <div className="review-candidate-block">
                    <div className="review-candidate-photo-wrap">
                      <img
                        src={candidate.photo ? mediaUrl(candidate.photo) : profileIcon}
                        alt=""
                        className="review-candidate-photo"
                      />
                    </div>
                    <div className="review-candidate-info">
                      {candidate.party_list && <span className="review-party-tag">{candidate.party_list}</span>}
                      <strong>{candidate.name}</strong>
                      {candidate.department && <span>{candidate.department}</span>}
                      {candidate.platform && (
                        <span className="review-platform"><b>◆</b> Platform: {candidate.platform}</span>
                      )}
                    </div>
                  </div>

                  <span className="review-selected-badge"><Icon name="check" size={18} /> Selected</span>
                </article>
              );
            })}
          </div>

          {error && <div className="error review-ballot-error">{error}</div>}

          <div className="review-bottom-bar">
            <div className={`review-bottom-message ${allSelected ? "complete" : "pending"}`}>
              <Icon name="check" size={19} />
              <span>{allSelected ? `All ${positionCount} positions are selected.` : `${selectedCount} of ${positionCount} positions are selected.`}</span>
            </div>

            <div className="review-actions">
              <button className="review-back-button" onClick={() => nav(`/vote/${election.id}`)} disabled={submitting}>
                <span aria-hidden="true">←</span> Back
              </button>
              <button className="review-submit-button" onClick={submit} disabled={submitting || !allSelected}>
                <Icon name="send" size={18} />
                {submitting ? "Submitting..." : "Submit Vote"}
              </button>
            </div>
          </div>
        </section>
      </main>
    </Layout>
  );
}
