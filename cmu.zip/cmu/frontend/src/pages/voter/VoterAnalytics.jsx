import React, {useEffect, useState} from "react";
import {Link, useParams} from "react-router-dom";
import {getVoterAnalytics} from "../../services/analyticsService";
import {createAnalyticsSocket} from "../../services/analyticsSocket";
import {Layout} from "../../components/layout/Layout";
import {
  DepartmentBarChart,
  DepartmentDonut,
  formatDate,
  TurnoutDonut,
  VotingActivityChart,
} from "../../components/analytics/AnalyticsCharts";

export default function VoterAnalytics() {
  const {electionId} = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState("connecting");

  useEffect(() => {
    let cancelled = false;
    let socketController;
    let refreshInFlight = false;

    async function load() {
      if (refreshInFlight) return;
      refreshInFlight = true;

      try {
        const next = await getVoterAnalytics(electionId);

        if (cancelled) return;

        setData(next);
        setError("");
        setLastUpdated(new Date(next.updated_at));
      } catch (e) {
        if (!cancelled) setError(e.message);
      } finally {
        refreshInFlight = false;
      }
    }

    load();

    socketController = createAnalyticsSocket(electionId, {
      onUpdate: load,
      onStatus: status => {
        if (cancelled) return;
        setConnectionStatus(status);
        if (status === "connected") {
          setError(current => current === "Real-time connection unavailable." ? "" : current);
        }
      },
      onError: () => {
        if (!cancelled) setError(current => current || "Real-time connection unavailable.");
      },
    });

    return () => {
      cancelled = true;
      socketController?.close();
    };
  }, [electionId]);

  const metrics = data?.metrics;
  const election = data?.election;
  const activity = data?.voting_activity;
  const isAllDepartments = election?.department_scope === "all";

  return (
    <Layout>
      <main className="dashboard analytics-page analytics-modern-page">

        <div className="analytics-page-heading">
          <div>
            <h1>Real-Time Election Analytics</h1>
            <p>Live aggregate election activity without candidate standings.</p>
          </div>

          {data && (
            <div className="analytics-live-status">
              <span className="live-dot" />
              {connectionStatus === "connected"
                ? "Live · updates automatically"
                : connectionStatus === "reconnecting"
                  ? "Reconnecting to live analytics…"
                  : "Connecting to live analytics…"}

              {lastUpdated && (
                <small>
                  Last update: {lastUpdated.toLocaleTimeString()} ·{" "}
                  {lastUpdated.toLocaleDateString()}
                </small>
              )}
            </div>
          )}

          <Link
            className="analytics-back-button"
            to="/dashboard"
          >
            ← &nbsp;Back to Dashboard
          </Link>
        </div>

        {error && <div className="error">{error}</div>}

        {!data && !error && (
          <div className="loading-state">
            <span className="spinner" />
            Loading analytics...
          </div>
        )}

        {data && metrics && election && (
          <>
            <section className="analytics-election-banner">
              <div className="analytics-election-icon">⌂</div>

              <div>
                <h2>{election.name}</h2>

                <p>
                  This dashboard provides aggregate participation
                  information. Live candidate vote counts, percentages,
                  rankings, and standings are not displayed.
                </p>
              </div>
            </section>

            <div className="analytics-top-grid">

              <section className="analytics-modern-card turnout-card">
                <div className="analytics-card-title">
                  <div>
                    <h2>Turnout Overview</h2>
                    <p>Total voter participation</p>
                  </div>

                  <span className="analytics-card-icon">◔</span>
                </div>

                <TurnoutDonut
                  percentage={metrics.turnout_percentage}
                />
              </section>


              <section className="analytics-modern-card statistics-card">
                <div className="analytics-card-title">
                  <div>
                    <h2>Election Statistics</h2>
                    <p>
                      Current configuration and aggregate activity
                    </p>
                  </div>

                  <span className="analytics-card-icon">▤</span>
                </div>

                <div className="analytics-stat-grid">

                  <div>
                    <span>Status</span>

                    <strong
                      className={`status-badge ${election.status}`}
                    >
                      {election.status}
                    </strong>
                  </div>

                  <div>
                    <span>Schedule</span>
                    <strong>
                      {election.schedule_status.replace("_", " ")}
                    </strong>
                  </div>

                  <div>
                    <span>Voter Category</span>

                    <strong>
                      {election.eligible_voter_category_display ||
                        election.eligible_voter_category}
                    </strong>
                  </div>

                  <div>
                    <span>Department Scope</span>

                    <strong>
                      {isAllDepartments
                        ? "All Departments"
                        : "Specific Departments"}
                    </strong>
                  </div>

                  <div>
                    <span>Positions</span>
                    <strong>{metrics.position_count}</strong>
                  </div>

                  <div>
                    <span>Candidates</span>
                    <strong>{metrics.candidate_count}</strong>
                  </div>

                </div>
              </section>


              {isAllDepartments && (
                <section className="analytics-modern-card department-card">
                  <div className="analytics-card-title">
                    <div>
                      <h2>Turnout by Department</h2>
                      <p>Percentage of eligible voters from each department that participated in the election</p>
                    </div>

                    <span className="analytics-card-icon">▥</span>
                  </div>

                  <DepartmentBarChart
                    departments={data.department_turnout}
                  />
                </section>
              )}

            </div>


            <div
              className={`analytics-bottom-grid${
                isAllDepartments
                  ? ""
                  : " analytics-bottom-single"
              }`}
            >

              <section className="analytics-modern-card activity-card">

                <div className="analytics-card-title activity-heading">
                  <div>
                    <h2>Voting Activity</h2>

                    <p>
                      Daily votes recorded across the election period (aggregate only).
                    </p>
                  </div>
                </div>

                <VotingActivityChart activity={activity} />

              </section>


              {isAllDepartments && (
                <section className="analytics-modern-card donut-card">

                  <div className="analytics-card-title">
                    <div>
                      <h2>Department Share of Total Participants</h2>

                      <p>
                        Shows how each department contributes to the total number of participating voters.
                      </p>
                    </div>

                    <span className="analytics-card-icon">
                      ◕
                    </span>
                  </div>

                  <DepartmentDonut
                    departments={data.department_turnout}
                    admin={false}
                  />

                </section>
              )}

            </div>
          </>
        )}

      </main>
    </Layout>
  );
}