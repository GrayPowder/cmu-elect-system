import React, {useEffect, useMemo, useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import {listElections, getElection} from "../../services/electionService";
import {Layout} from "../../components/layout/Layout";
import {useAuth} from "../../context/AuthContext";
import studentIcon from "../../assets/Student Male@2x.png";
import teacherIcon from "../../assets/Teacher.png";

function Icon({name, size = 22}) {
  const common = {width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", 'aria-hidden': true};
  const paths = {
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    user: <><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></>,
    building: <><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-4h6v4"/><path d="M9 9h.01M12 9h.01M15 9h.01M9 12h.01M12 12h.01M15 12h.01"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    wifi: <><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.5 16a6 6 0 0 1 7 0"/><path d="M12 20h.01"/></>,
    chart: <><path d="M4 19V5"/><path d="M4 19h16"/><path d="M8 16v-5"/><path d="M12 16V8"/><path d="M16 16V4"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    filter: <><path d="M4 5h16l-6 7v5l-4 2v-7z"/></>,
    arrow: <><path d="m9 18 6-6-6-6"/></>,
    shield: <><path d="M12 3 20 6v5c0 5-3.4 8.8-8 10-4.6-1.2-8-5-8-10V6z"/><path d="m9 12 2 2 4-4"/></>,
    people: <><circle cx="9" cy="8" r="3"/><circle cx="16.5" cy="9" r="2.5"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M14 20a5 5 0 0 1 7 0"/></>
  };
  return <svg {...common}>{paths[name]}</svg>;
}

function statusLabel(status) {
  if (status === "not_started") return "NOT STARTED";
  if (status === "ended") return "ENDED";
  return "ACTIVE";
}

export function Dashboard() {
  const [elections, setElections] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [accessError, setAccessError] = useState("");
  const [checkingElectionId, setCheckingElectionId] = useState(null);
  const navigate = useNavigate();
  const {user} = useAuth();

  useEffect(() => {
    setLoading(true);
    listElections()
      .then(setElections)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const departmentOptions = useMemo(() => {
    const map = new Map();

    elections.forEach(election => {
      if (election.department_scope !== "specific") return;

      (election.eligible_department_details || []).forEach(department => {
        map.set(String(department.id), department);
      });
    });

    return [...map.values()].sort((a, b) =>
      String(a.code || a.name || "").localeCompare(
        String(b.code || b.name || ""),
        undefined,
        { sensitivity: "base" }
      )
    );
  }, [elections]);

  const filteredElections = useMemo(() => {
    const term = search.trim().toLowerCase();

    return elections
      .filter(election => {
        const matchesSearch =
          !term ||
          [
            election.name,
            election.description,
            election.audience,
            ...(election.eligible_department_details || []).flatMap(
              department => [department.code, department.name]
            ),
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase()
            .includes(term);

        const matchesStatus =
          filter === "all" ||
          (filter === "active" && election.status === "active") ||
          (filter === "ended" && election.status === "ended") ||
          (filter === "not_started" && election.status === "not_started");

        /*
        * Department filtering:
        *
        * "all" = SHOW EVERY ELECTION.
        *
        * Specific department = show elections assigned
        * specifically to that department.
        */
        const matchesDepartment =
          departmentFilter === "all" ||
          (
            election.department_scope === "specific" &&
            (election.eligible_department_details || []).some(
              department =>
                String(department.id) === String(departmentFilter)
            )
          );

        return matchesSearch && matchesStatus && matchesDepartment;
      })

      /*
      * IMPORTANT:
      *
      * When All Departments is selected, don't remove
      * specific-department elections.
      *
      * Just put the All Departments elections first.
      */
      .sort((a, b) => {
        if (departmentFilter === "all") {
          if (a.department_scope === "all" && b.department_scope !== "all") {
            return -1;
          }

          if (a.department_scope !== "all" && b.department_scope === "all") {
            return 1;
          }
        }

        return String(a.name || "").localeCompare(
          String(b.name || ""),
          undefined,
          { sensitivity: "base" }
        );
      });
  }, [elections, search, filter, departmentFilter]);

  const activeCount = elections.filter(e => e.status === "active" && e.is_open).length;
  const endedCount = elections.filter(e => e.status === "ended").length;

  const handleElectionDetails = async (electionId) => {
    setAccessError("");
    setCheckingElectionId(electionId);
    try {
      await getElection(electionId);
      navigate(`/elections/${electionId}`);
    } catch (e) {
      setAccessError(e.message || "You are not eligible to access it.");
    } finally {
      setCheckingElectionId(null);
    }
  };

  return (
    <Layout>
      <div className="modern-dashboard-shell">
        <main className="dashboard modern-dashboard">
          <section className="modern-hero">
            <div className="hero-copy">
              <span className="hero-pill">CMU-ELECT</span>
              <h1>Voter Dashboard</h1>
              <p>Welcome, {user.username || "Voter"}. View elections you are eligible to participate in.</p>
              <div className="hero-benefits">
                <span><Icon name="shield" size={27}/> Secure Voting</span>
                <i />
                <span><Icon name="clock" size={27}/> Fast &amp; Convenient</span>
                <i />
                <span><Icon name="people" size={30}/> Your Voice Counts</span>
              </div>
            </div>
            <div className="hero-art" aria-hidden="true">
              <div className="hero-leaf leaf-one" />
              <div className="hero-leaf leaf-two" />
              <div className="ballot-box">
                <div className="ballot-paper"><span>✓</span></div>
                <div className="ballot-slot" />
                <div className="ballot-body" />
              </div>
              <div className="hero-slogan">Your Voice<br/>Matters<span /></div>
            </div>
          </section>

          {error && <div className="error modern-alert">{error}</div>}
          {loading && <div className="loading-state modern-loading"><span className="spinner" /> Loading elections...</div>}

          {!loading && !error && (
            <>
              <section className="modern-election-header">
                <div className="section-title-wrap">
                  <span className="modern-eyebrow"><b /> AVAILABLE ELECTIONS</span>
                  <h2>Choose an election to participate</h2>
                  <p>Stay informed. Make your voice heard. Vote for a better CMU.</p>
                </div>
                <div className="election-tools">
                  <label className="search-box">
                    <Icon name="search" size={22}/>
                    <input
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      placeholder="Search elections..."
                      aria-label="Search elections"
                    />
                  </label>

                  <label className="filter-box">
                    <Icon name="filter" size={20}/>
                    <select
                      value={departmentFilter}
                      onChange={e => setDepartmentFilter(e.target.value)}
                      aria-label="Filter by department"
                    >
                      <option value="all">All Departments</option>

                      {departmentOptions.map(department => (
                        <option key={department.id} value={department.id}>
                          {department.code}
                        </option>
                      ))}
                    </select>

                    <span className="select-chevron">⌄</span>
                  </label>

                  <label className="filter-box">
                    <Icon name="filter" size={20}/>
                    <select
                      value={filter}
                      onChange={e => setFilter(e.target.value)}
                      aria-label="Filter elections"
                    >
                      <option value="all">All Elections</option>
                      <option value="active">Active</option>
                      <option value="not_started">Not Started</option>
                      <option value="ended">Ended</option>
                    </select>

                    <span className="select-chevron">⌄</span>
                  </label>
                </div>
              </section>

              {filteredElections.length === 0 ? (
                <div className="message modern-empty">No elections match your search or filter.</div>
              ) : (
                <div className="election-list modern-election-list">
                  {filteredElections.map(election => {
                    const active = election.status === "active" && election.is_open;
                    const ended = election.status === "ended";
                    const departments = election.department_scope === "specific"
                      ? (election.eligible_department_details?.map(d => d.name).join(", ") || "Department information unavailable")
                      : "All Departments";

                    return (
                      <section className={`election-card modern-election-card ${active ? "is-active" : "is-ended"}`} key={election.id}>
                        <div className="modern-card-top">
                          <div className={`election-type-icon ${ended ? "purple" : "blue"}`}><Icon name={ended ? "users" : "people"} size={31}/></div>
                          <div className="modern-card-title">
                            <h3>{election.name}</h3>
                            <p>{election.description || "Participate in this election and make your voice heard."}</p>
                          </div>
                          <span className={`modern-status ${
                              election.has_voted
                                  ? "voted"
                                  : election.status === "not_started"
                                      ? "not-started"
                                      : active
                                          ? "active"
                                          : "ended"
                          }`}>
                              {election.has_voted ? "VOTED" : statusLabel(election.status)}
                          </span>
                        </div>

                        <div className="modern-info-panel">
                          <div><Icon name="user" size={20}/><span><strong>Voter Category:</strong> {election.eligible_voter_category_display || election.audience || "Not specified"}</span></div>
                          <div><Icon name="building" size={20}/><span><strong>Eligible Departments:</strong> {departments}</span></div>
                          <div><Icon name="clock" size={20}/><span><strong>Voting period:</strong> {new Date(election.start_datetime).toLocaleString()} — {new Date(election.end_datetime).toLocaleString()}</span></div>
                          <div><Icon name="wifi" size={20}/><span><strong>Availability:</strong> <em className={election.has_voted ? "unavailable" : active ? "available" : "unavailable"}>{election.has_voted ? "Already Voted" : active ? "Voting Available" : election.voting_availability === "not_started" ? "Voting Not Yet Available" : "Voting Ended"}</em></span></div>
                        </div>

                        <div className="modern-card-actions">
                          {ended ? (
                            <Link className="modern-primary-action" to={`/results/${election.id}`}>
                              <Icon name="chart" size={20}/> <span>View Results</span><Icon name="arrow" size={18}/>
                            </Link>
                          ) : (
                            <button
                              type="button"
                              className="modern-primary-action modern-primary-action-button"
                              onClick={() => handleElectionDetails(election.id)}
                              disabled={checkingElectionId === election.id}
                              aria-busy={checkingElectionId === election.id}
                            >
                              <span className="primary-action-content">
                                <Icon name="shield" size={19}/>
                                <span>{checkingElectionId === election.id ? "Checking access..." : "View Election Details"}</span>
                                <Icon name="arrow" size={19}/>
                              </span>
                            </button>
                          )}
                          <Link className="modern-secondary-action" to={`/analytics/${election.id}`}>
                            <Icon name="chart" size={20}/> <span>Live Analytics</span>
                          </Link>
                        </div>
                      </section>
                    );
                  })}
                </div>
              )}

              <div className="dashboard-summary" aria-label="Election summary">
                <span>{activeCount} active election{activeCount === 1 ? "" : "s"}</span>
                <span>{endedCount} completed</span>
              </div>
            </>
          )}
        </main>
      </div>


      {accessError && (
        <div className="access-error-overlay" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget) setAccessError("");
        }}>
          <div className="access-error-modal" role="alertdialog" aria-modal="true" aria-labelledby="access-error-title">
            <div className="access-error-icon" aria-hidden="true">
              <Icon name="shield" size={28}/>
            </div>
            <h2 id="access-error-title">Access Restricted</h2>
            <p>{accessError}</p>
            <button type="button" className="access-error-close" onClick={() => setAccessError("")}>
              OK
            </button>
          </div>
        </div>
      )}
    </Layout>
  );
}
