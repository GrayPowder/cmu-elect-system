import React, { useEffect, useState } from "react";
import { listAdminElections } from "../../services/adminService";
import { getElectionResults } from "../../services/electionService";
import { ResultsContent } from "../../components/common/ResultsContent";
import { AdminTopbar } from "../../components/layout/AdminTopbar";

export function AdminResults() {
  const [elections, setElections] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let mounted = true;

    listAdminElections("status=ended")
      .then((items) => {
        if (!mounted) return;
        const endedElections = items.filter((election) => election.status === "ended");
        setElections(endedElections);
        setSelectedId(endedElections.length ? String(endedElections[0].id) : "");
      })
      .catch((e) => {
        if (!mounted) return;
        setElections([]);
        setSelectedId("");
        setError(e.message);
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!selectedId) {
      setData(null);
      return;
    }

    let mounted = true;
    setLoading(true);
    setError("");

    getElectionResults(selectedId)
      .then((result) => {
        if (mounted) setData(result);
      })
      .catch((e) => {
        if (!mounted) return;
        setData(null);
        setError(e.message);
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [selectedId]);

  return (
    <div className="admin-results-screen">
      <AdminTopbar />

      <main className="admin-results-page">
        <section className="admin-results-hero" aria-labelledby="results-page-title">
          <div className="admin-results-hero-copy">
            <div className="admin-results-hero-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48" fill="none">
                <path d="M12 38V25M24 38V15M36 38V9" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
              </svg>
            </div>
            <div>
              <span className="admin-results-eyebrow">ELECTION RESULTS</span>
              <h1 id="results-page-title">Election Results</h1>
              <p>Accurate results calculated from actual vote records.</p>
            </div>
          </div>

          <div className="admin-results-hero-art" aria-hidden="true">
            <span className="results-laurel results-laurel-left">❯</span>
            <span className="results-ballot-paper">✓</span>
            <span className="results-ballot-box" />
            <span className="results-laurel results-laurel-right">❮</span>
          </div>
        </section>

        <section className="admin-results-selector-card">
          <label htmlFor="result-election">Select Election</label>
          {elections.length > 0 ? (
            <div className="admin-results-select-wrap">
              <select
                id="result-election"
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
              >
                {elections.map((election) => (
                  <option key={election.id} value={election.id}>
                    {election.name} — ended
                  </option>
                ))}
              </select>
              <span aria-hidden="true">⌄</span>
            </div>
          ) : (
            <div className="admin-results-empty-select">No ended elections are available.</div>
          )}
        </section>

        {loading && (
          <div className="admin-results-status">
            <span className="spinner" /> Loading results...
          </div>
        )}

        {error && <div className="admin-results-error">{error}</div>}

        {!loading && !error && data && <ResultsContent data={data} />}

        {!loading && !error && elections.length === 0 && (
          <div className="admin-results-no-results">
            <div className="admin-results-no-results-icon" aria-hidden="true">✓</div>
            <h2>No ended elections yet</h2>
            <p>Election results will appear here after an election has ended.</p>
          </div>
        )}
      </main>
    </div>
  );
}
