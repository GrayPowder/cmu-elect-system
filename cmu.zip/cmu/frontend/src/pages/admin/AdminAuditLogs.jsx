import React, { useCallback, useEffect, useMemo, useState } from "react";

import { getAuditLogs } from "../../services/adminService";
import { AdminTopbar } from "../../components/layout/AdminTopbar";

const PAGE_SIZE = 10;

const ACTION_META = {
  admin_login: { label: "Login", tone: "login" },
  voter_login: { label: "Login", tone: "login" },
  admin_logout: { label: "Logout", tone: "logout" },
  voter_logout: { label: "Logout", tone: "logout" },
  vote_submitted: { label: "Vote Submitted", tone: "vote" },
  account_created: { label: "Account Created", tone: "created" },
  account_modified: { label: "Account Modified", tone: "modified" },
  account_deactivated: { label: "Account Deactivated", tone: "danger" },
  password_reset: { label: "Password Reset", tone: "security" },
  security_login_failure: { label: "Login Failed", tone: "danger" },
};

function formatAction(action) {
  const meta = ACTION_META[action];
  if (meta) return meta.label;
  return String(action || "Unknown")
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function actionMeta(action) {
  return ACTION_META[action] || { label: formatAction(action), tone: "default" };
}

function formatDateTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const seconds = Math.max(0, Math.floor((now.getTime() - date.getTime()) / 1000));
  let relative = "just now";
  if (seconds >= 86400) {
    const days = Math.floor(seconds / 86400);
    relative = `${days} ${days === 1 ? "day" : "days"} ago`;
  } else if (seconds >= 3600) {
    const hours = Math.floor(seconds / 3600);
    relative = `${hours} ${hours === 1 ? "hour" : "hours"} ago`;
  } else if (seconds >= 60) {
    const minutes = Math.floor(seconds / 60);
    relative = `${minutes} ${minutes === 1 ? "minute" : "minutes"} ago`;
  }

  return {
    full: date.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit",
    }),
    relative,
  };
}

function getInitial(name) {
  return String(name || "S").trim().charAt(0).toUpperCase();
}

function Pagination({ page, totalPages, onPageChange }) {
  if (totalPages <= 1) return null;

  const pages = [];
  const add = (value) => pages.push(value);

  if (totalPages <= 7) {
    for (let i = 1; i <= totalPages; i += 1) add(i);
  } else {
    add(1);
    if (page > 4) add("ellipsis-left");

    const start = Math.max(2, page - 1);
    const end = Math.min(totalPages - 1, page + 1);
    for (let i = start; i <= end; i += 1) add(i);

    if (page < totalPages - 3) add("ellipsis-right");
    add(totalPages);
  }

  return (
    <div className="audit-pagination" aria-label="Audit log pagination">
      <button
        type="button"
        className="audit-page-arrow"
        disabled={page === 1}
        onClick={() => onPageChange(page - 1)}
        aria-label="Previous page"
      >
        ‹
      </button>

      {pages.map((item) =>
        typeof item === "number" ? (
          <button
            type="button"
            key={item}
            className={`audit-page-number${item === page ? " active" : ""}`}
            onClick={() => onPageChange(item)}
            aria-current={item === page ? "page" : undefined}
          >
            {item}
          </button>
        ) : (
          <span className="audit-page-ellipsis" key={item}>…</span>
        )
      )}

      <button
        type="button"
        className="audit-page-arrow"
        disabled={page === totalPages}
        onClick={() => onPageChange(page + 1)}
        aria-label="Next page"
      >
        ›
      </button>
    </div>
  );
}

export default function AdminAuditLogs() {
  const [logs, setLogs] = useState([]);
  const [actions, setActions] = useState([]);
  const [users, setUsers] = useState([]);

  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [action, setAction] = useState("");
  const [actor, setActor] = useState("");
  const [dateRange, setDateRange] = useState("7");
  const [page, setPage] = useState(1);

  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const pageSize = PAGE_SIZE;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);

    try {
      const q = new URLSearchParams();
      if (search.trim()) q.set("search", search.trim());
      if (action) q.set("action", action);
      if (actor) q.set("actor", actor);
      if (dateRange) q.set("date_range", dateRange);
      q.set("page", String(page));
      q.set("page_size", String(PAGE_SIZE));
      q.set("sort", "desc");

      const data = await getAuditLogs(q.toString());

      setLogs(data.logs || []);
      setActions(data.actions || []);
      setUsers(data.users || []);
      setTotal(Number(data.total || 0));
      setTotalPages(Math.max(1, Number(data.total_pages || 1)));
      setError("");
    } catch (e) {
      setError(e.message || "Unable to load audit logs.");
    } finally {
      setLoading(false);
    }
  }, [search, action, actor, dateRange, page]);

  useEffect(() => {
    load();
  }, [load]);

  const rangeLabel = useMemo(() => {
    if (dateRange === "30") return "Last 30 days";
    if (dateRange === "90") return "Last 90 days";
    if (dateRange === "all") return "All time";
    return "Last 7 days";
  }, [dateRange]);

  function applyFilters() {
    setPage(1);
    setSearch(searchInput);
  }

  function handleSearchKeyDown(event) {
    if (event.key === "Enter") applyFilters();
  }

  const start = total ? (page - 1) * pageSize + 1 : 0;
  const end = total ? Math.min(page * pageSize, total) : 0;

  return (
    <div className="audit-logs-screen">
      <AdminTopbar />

      <main className="audit-logs-page">
        <header className="audit-page-heading">
          <div className="audit-title-icon" aria-hidden="true">
            <svg viewBox="0 0 48 48" fill="none">
              <rect x="12" y="7" width="24" height="34" rx="4" stroke="currentColor" strokeWidth="2.8" />
              <path d="M18 5h12v6H18z" stroke="currentColor" strokeWidth="2.8" strokeLinejoin="round" />
              <path d="M19 19h10M19 25h10M19 31h7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
              <path d="m29 35 3 3 6-7" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div>
            <h1>Audit Logs</h1>
            <p>Review important system, administrator, voter, voting, and security events.</p>
          </div>
        </header>

        <section className="audit-filter-card" aria-label="Audit log filters">
          <div className="audit-search-field">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="2" />
              <path d="m16 16 4.5 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <input
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder="Search action, actor, or description..."
              aria-label="Search audit logs"
            />
          </div>

          <label className="audit-field">
            <span>Action</span>
            <select value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }}>
              <option value="">All actions</option>
              {actions.map((value) => (
                <option key={value} value={value}>{formatAction(value)}</option>
              ))}
            </select>
          </label>

          <label className="audit-field">
            <span>User</span>
            <select value={actor} onChange={(e) => { setActor(e.target.value); setPage(1); }}>
              <option value="">All users</option>
              {users.map((user) => (
                <option key={user.username} value={user.username}>{user.label}</option>
              ))}
            </select>
          </label>

          <label className="audit-field">
            <span>Date range</span>
            <select value={dateRange} onChange={(e) => { setDateRange(e.target.value); setPage(1); }}>
              <option value="7">Last 7 days</option>
              <option value="30">Last 30 days</option>
              <option value="90">Last 90 days</option>
              <option value="all">All time</option>
            </select>
          </label>

          <button type="button" className="audit-filter-button" onClick={applyFilters}>
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M4 6h16M7 12h10M10 18h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            Filter
          </button>
        </section>

        {error && <div className="error audit-error">{error}</div>}

        <section className="audit-log-card">
          <div className="audit-card-toolbar">
            <span>
              Showing <strong>{start}–{end}</strong> of <strong>{total}</strong> logs
            </span>
            <div className="audit-toolbar-right">
              <Pagination page={page} totalPages={totalPages} onPageChange={setPage} />
            </div>
          </div>

          {loading ? (
            <div className="audit-loading"><span className="spinner" /> Loading audit logs...</div>
          ) : !logs.length ? (
            <div className="audit-empty">No audit events match the current filters.</div>
          ) : (
            <>
              <div className="audit-table-wrap">
                <table className="audit-table audit-modern-table">
                  <thead>
                    <tr>
                      <th>Date &amp; Time</th>
                      <th>Actor</th>
                      <th>Action</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map((log) => {
                      const date = formatDateTime(log.timestamp);
                      const meta = actionMeta(log.action);
                      return (
                        <tr key={log.id}>
                          <td>
                            <div className="audit-datetime">
                              <span className="audit-clock" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none">
                                  <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.8" />
                                  <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                                </svg>
                              </span>
                              <div>
                                <strong>{date.full}</strong>
                                <small>{date.relative}</small>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div className="audit-actor">
                              <span className={`audit-avatar audit-avatar-${meta.tone}`}>{getInitial(log.actor)}</span>
                              <div>
                                <strong>{log.actor || "System"}</strong>
                                <small>{log.actor_role || "System"}</small>
                              </div>
                            </div>
                          </td>
                          <td>
                            <span className={`audit-action-pill ${meta.tone}`}>
                              <span className="audit-action-dot" aria-hidden="true" />
                              {meta.label}
                            </span>
                          </td>
                          <td className="audit-description">{log.description || "—"}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="audit-card-footer">
                <span className="audit-live-status">
                  <span className="audit-live-dot" />
                  Logs are automatically updated in real-time.
                </span>
              </div>
            </>
          )}
        </section>
      </main>
    </div>
  );
}
