import React from "react";
import { AdminTopbar } from "../../components/layout/AdminTopbar";

export function AdminModulePlaceholder({name}) {
  return <div>
    <AdminTopbar />
    <main className="dashboard">
      <div className="result-title"><h1>{name}</h1><p>This administrator module is reserved for its dedicated implementation phase.</p></div>
    </main>
  </div>;
}

