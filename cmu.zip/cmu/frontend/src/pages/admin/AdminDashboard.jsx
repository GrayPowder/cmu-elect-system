import React from "react";
import AdminAnalytics from "./AdminAnalytics";

// The administrator landing page is the real-time analytics dashboard.
// The existing /admin/analytics route remains available for compatibility.
export function AdminDashboard() {
  return <AdminAnalytics />;
}
