import React, {useCallback, useEffect, useState} from "react";
import {NavLink, useNavigate} from "react-router-dom";
import {listAdminElections} from "../../services/adminService";
import {getAdminAnalytics} from "../../services/analyticsService";
import {useAuth} from "../../context/AuthContext";
import logo from "../../assets/cmu-elect-logo.png";

function MetricCard({label, value, detail}) {
  return (
    <section className="analytics-metric-card">
      <span>{label}</span>
      <strong>{value}</strong>
      {detail && <small>{detail}</small>}
    </section>
  );
}

function TurnoutVisual({percentage}) {
  const safePercentage = Math.max(
    0,
    Math.min(100, Number(percentage) || 0)
  );

  return (
    <div className="turnout-layout">
      <div
        className="turnout-ring"
        style={{
          background: `conic-gradient(#3348c4 ${safePercentage}%, #e9edf5 0)`
        }}
        aria-label={`Turnout ${safePercentage}%`}
      >
        <div className="turnout-ring-center">
          <strong>{safePercentage.toFixed(2)}%</strong>
          <span>turnout</span>
        </div>
      </div>

      <div className="turnout-details">
        <p>
          Current overall voter turnout.
        </p>
      </div>
    </div>
  );
}

function DepartmentTurnout({departments}) {
  if (!departments?.length) {
    return null;
  }

  return (
    <section className="analytics-panel">
      <div className="analytics-panel-heading">
        <div>
          <h2>Turnout by Department</h2>
          <p>Current voter turnout for each department</p>
        </div>
      </div>

      <div className="analytics-stat-list">
        {departments.map(department => (
          <div key={department.id}>
            <span>{department.name}</span>
            <strong>
              {Number(department.turnout_percentage).toFixed(2)}%
            </strong>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function AdminAnalytics() {
  const nav = useNavigate();
  const {user, logout} = useAuth();
  const [elections, setElections] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);

  const loadElections = useCallback(async () => {
    const items = await listAdminElections();
    setElections(items);
    setSelectedId(current => current || (items.length ? String(items[0].id) : ""));
  }, []);

  const loadAnalytics = useCallback(async (showLoading = false) => {
    if (!selectedId) return;
    if (showLoading) setLoading(true);
    try {
      const result = await getAdminAnalytics(selectedId);
      setData(result);
      setLastUpdated(new Date(result.updated_at));
      setError("");
    } catch (err) {
      setError(err.message);
      if (showLoading) setData(null);
    } finally {
      if (showLoading) setLoading(false);
    }
  }, [selectedId]);

  useEffect(() => {
    loadElections().catch(err => {
      setError(err.message);
      setLoading(false);
    });
  }, [loadElections]);

  useEffect(() => {
    if (!selectedId) {
      setLoading(false);
      return undefined;
    }

    loadAnalytics(true);
    const interval = window.setInterval(() => loadAnalytics(false), 2000);
    return () => window.clearInterval(interval);
  }, [selectedId, loadAnalytics]);

  async function handleLogout() {
    await logout();
    nav("/login", {replace: true});
  }

  const metrics = data?.metrics;
  const election = data?.election;

  return (
    <div>
      <header className="topbar">
        <div className="topbar-brand">
          <img src={logo} alt="CMU-ELECT Logo" />
          <span>CMU-ELECT ADMIN</span>
        </div>
        <nav className="main-nav">
          <NavLink to="/admin" end className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Dashboard</NavLink>
          <NavLink to="/admin/users" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Voters</NavLink>
          <NavLink to="/admin/departments" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Departments</NavLink>
          <NavLink to="/admin/elections" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Elections</NavLink>
          <NavLink to="/admin/results" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Results</NavLink>
          <NavLink to="/admin/analytics" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Analytics</NavLink>
          <NavLink to="/admin/audit-logs" className={({isActive}) => `admin-nav-link${isActive ? " active" : ""}`}>Audit Logs</NavLink>
          <span className="user-chip">{user?.email}</span>
          <button onClick={handleLogout}>Logout</button>
        </nav>
      </header>

      <main className="dashboard analytics-page">
        <div className="admin-page-heading">
          <div>
            <h1>Real-Time Data Analytics</h1>
            <p>Live aggregate election activity without candidate standings.</p>
          </div>
          {data && (
            <div className="analytics-live-status">
              <span className="live-dot" /> Live · updates every 2 seconds
              {lastUpdated && <small>Last update: {lastUpdated.toLocaleTimeString()}</small>}
            </div>
          )}
        </div>

        <section className="result-selector analytics-selector">
          <label htmlFor="analytics-election">Select election</label>
          <select
            id="analytics-election"
            className="standalone-input"
            value={selectedId}
            onChange={e => setSelectedId(e.target.value)}
          >
            {elections.map(item => (
              <option key={item.id} value={item.id}>{item.name} — {item.status}</option>
            ))}
          </select>
        </section>

        {error && <div className="error">{error}</div>}
        {loading && <div className="center"><span className="spinner" /> Loading analytics...</div>}
        {!loading && !data && !error && <div className="message">No elections are available yet.</div>}

        {data && metrics && election && (
          <>
            <div className="analytics-metrics-grid">
              <MetricCard label="Positions" value={metrics.position_count} detail="Configured election positions" />
            </div>

            <div className="analytics-grid-two">
              <section className="analytics-panel">
                <div className="analytics-panel-heading">
                  <div><h2>Turnout</h2><p>Current voter participation</p></div>
                </div>
                <TurnoutVisual
                  percentage={metrics.turnout_percentage}
                />
              </section>

              <section className="analytics-panel">
                <div className="analytics-panel-heading">
                  <div><h2>Election Statistics</h2><p>Current configuration and activity</p></div>
                </div>

                <div className="analytics-stat-list">
                  <div><span>Status</span><strong className={`status-badge ${election.status}`}>{election.status}</strong></div>
                  <div><span>Schedule</span><strong>{election.schedule_status.replace("_", " ")}</strong></div>
                  <div><span>Voter Category</span><strong>{election.eligible_voter_category_display || election.eligible_voter_category}</strong></div>
                  <div><span>Department Scope</span><strong>{election.department_scope === "all"? "All Departments": "Specific Departments"}</strong></div>
                  <div><span>Positions</span><strong>{metrics.position_count}</strong></div>
                  <div><span>Candidates</span><strong>{metrics.candidate_count}</strong></div>
                  <div><span>Total vote entries</span><strong>{metrics.total_votes}</strong></div>
                </div>

              </section>
            </div>

            {election.department_scope === "all" && (
              <DepartmentTurnout
                departments={data.department_turnout}
              />
            )}
 
          </>
        )}

      </main>
    </div>
  );
}
