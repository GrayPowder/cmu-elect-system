import React, {useCallback, useEffect, useState} from "react";
import {listAdminElections, listDepartments} from "../../services/adminService";
import {getAdminAnalytics} from "../../services/analyticsService";
import {createAnalyticsSocket} from "../../services/analyticsSocket";
import { AdminTopbar } from "../../components/layout/AdminTopbar";
import {
  DepartmentBarChart,
  DepartmentDonut,
  TurnoutDonut,
  VotingActivityChart,
} from "../../components/analytics/AnalyticsCharts";

export default function AdminAnalytics() {
  const [elections, setElections] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [statusFilter, setStatusFilter] = useState("active");
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [departments, setDepartments] = useState([]);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState("connecting");

  const loadElections = useCallback(async () => {
    const params = new URLSearchParams();
    if (statusFilter) {
      params.set("schedule_status", statusFilter);
    } else {
      params.set("exclude_not_started", "1");
    }
    if (departmentFilter) params.set("department", departmentFilter);

    const items = await listAdminElections(params.toString());
    setElections(items);
    setSelectedId(current => {
      const stillAvailable = current && items.some(item => String(item.id) === String(current));
      return stillAvailable ? String(current) : (items.length ? String(items[0].id) : "");
    });
  }, [statusFilter, departmentFilter]);

  useEffect(() => {
    listDepartments("status=active")
      .then(items => setDepartments(Array.isArray(items) ? items : []))
      .catch(() => setDepartments([]));
  }, []);

  const loadAnalytics = useCallback(async (showLoading = false) => {
    if (!selectedId) return;
    if (showLoading) setLoading(true);
    try {
      const result = await getAdminAnalytics(selectedId);
      setData(result);
      setLastUpdated(new Date(result.updated_at));
      setError("");
    } catch (err) {
      setError(err.message);
      if (showLoading) setData(null);
    } finally {
      if (showLoading) setLoading(false);
    }
  }, [selectedId]);

  useEffect(() => {
    setData(null);
    setSelectedId("");
    setError("");
    setLoading(true);
    loadElections().catch(err => { setError(err.message); setLoading(false); });
  }, [loadElections]);

  useEffect(() => {
    if (!selectedId) {
      setLoading(false);
      return undefined;
    }

    let cancelled = false;
    let socketController;

    async function loadInitialAnalytics() {
      await loadAnalytics(true);
      if (cancelled) return;

      socketController = createAnalyticsSocket(selectedId, {
        onUpdate: () => loadAnalytics(false),
        onStatus: status => {
          if (!cancelled) setConnectionStatus(status);
        },
        onError: () => {
          if (!cancelled) setError(current => current || "Real-time connection unavailable.");
        },
      });
    }

    loadInitialAnalytics();

    return () => {
      cancelled = true;
      socketController?.close();
    };
  }, [selectedId, loadAnalytics]);

  const metrics = data?.metrics;
  const election = data?.election;
  const activity = data?.voting_activity;
  const isAllDepartments = election?.department_scope === "all";

  return (
    <div className="analytics-shell admin-analytics-dashboard">
      <AdminTopbar />

      <main className="dashboard analytics-page analytics-modern-page">
        <section className="admin-analytics-welcome" aria-label="Administrator welcome">
          <div className="admin-analytics-welcome-account">
            <div className="admin-analytics-avatar" aria-hidden="true">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="24" cy="17" r="8" fill="currentColor" />
                <path d="M9 40c1.7-8.2 7-12.3 15-12.3S37.3 31.8 39 40" fill="currentColor" />
              </svg>
            </div>
            <div className="admin-analytics-account-copy">
              <span>Good evening,</span>
              <strong>Admin <b aria-hidden="true">✓</b></strong>
              <small>System Administrator</small>
            </div>
          </div>

          <div className="admin-analytics-quote">
            <span className="admin-analytics-quote-mark" aria-hidden="true">“</span>
            <div>
              <strong>“Your vote is a voice.<br />Use it to build a better tomorrow.”</strong>
              <small>— CMU-ELECT</small>
            </div>
          </div>

          <div className="admin-analytics-welcome-message">
            <span className="admin-analytics-briefcase" aria-hidden="true">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="7" y="14" width="34" height="25" rx="4" stroke="currentColor" strokeWidth="3" />
                <path d="M17 14V10.5A3.5 3.5 0 0 1 20.5 7h7a3.5 3.5 0 0 1 3.5 3.5V14M7 23h34M22 23v4h4v-4" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
            <div>
              <strong>Every vote counts.</strong>
              <span>A stronger university<br />starts with you.</span>
            </div>
          </div>
        </section>
        <div className="analytics-page-heading">
          <div>
            <h1>Real-Time Election Analytics</h1>
            <p>Live aggregate election activity without candidate standings.</p>
          </div>
          {data && (
            <div className="analytics-live-status">
              <span className="live-dot" /> {connectionStatus === "connected"
                ? "Live · updates automatically"
                : connectionStatus === "reconnecting"
                  ? "Reconnecting to live analytics…"
                  : "Connecting to live analytics…"}
              {lastUpdated && <small>Last update: {lastUpdated.toLocaleTimeString()} · {lastUpdated.toLocaleDateString()}</small>}
            </div>
          )}
        </div>

        <section className="analytics-admin-selector" aria-label="Analytics filters">
          <div className="analytics-filter-field">
            <label htmlFor="analytics-status">Status</label>
            <select
              id="analytics-status"
              value={statusFilter}
              onChange={event => setStatusFilter(event.target.value)}
            >
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="ended">Ended</option>
            </select>
          </div>

          <div className="analytics-filter-field">
            <label htmlFor="analytics-department">Department</label>
            <select
              id="analytics-department"
              value={departmentFilter}
              onChange={event => setDepartmentFilter(event.target.value)}
            >
              <option value="">All Departments</option>
              {departments.map(department => (
                <option key={department.id} value={department.code}>
                  {department.code}
                </option>
              ))}
            </select>
          </div>

          <div className="analytics-filter-field analytics-election-field">
            <label htmlFor="analytics-election">Select election</label>
            <select
              id="analytics-election"
              value={selectedId}
              onChange={event => setSelectedId(event.target.value)}
              disabled={!elections.length}
            >
              {elections.length ? (
                elections.map(item => (
                  <option key={item.id} value={item.id}>
                    {item.name} — {item.status}
                  </option>
                ))
              ) : (
                <option value="">No matching elections</option>
              )}
            </select>
          </div>
        </section>

        {error && <div className="error">{error}</div>}
        {loading && <div className="loading-state"><span className="spinner" /> Loading analytics...</div>}
        {!loading && !data && !error && (
          <div className="message">
            No elections match the selected filters. Choose a different status, department, or election.
          </div>
        )}

        {data && metrics && election && (
          <>
            <section className="analytics-election-banner">
              <div className="analytics-election-icon">⌂</div>
              <div>
                <h2>{election.name}</h2>
                <p>This dashboard provides aggregate participation information. Candidate vote counts, percentages, rankings, and standings are not displayed in live analytics.</p>
              </div>
            </section>

            <div className="analytics-top-grid">
              <section className="analytics-modern-card turnout-card">
                <div className="analytics-card-title">
                  <div><h2>Turnout Overview</h2><p>Total voter participation</p></div>
                  <span className="analytics-card-icon">◔</span>
                </div>
                <TurnoutDonut percentage={metrics.turnout_percentage} admin={true} metrics={metrics} />
              </section>

              <section className="analytics-modern-card statistics-card">
                <div className="analytics-card-title">
                  <div><h2>Election Statistics</h2><p>Current configuration and aggregate activity</p></div>
                  <span className="analytics-card-icon">▤</span>
                </div>
                <div className="analytics-stat-grid">
                  <div><span>Status</span><strong className={`status-badge ${election.status}`}>{election.status}</strong></div>
                  <div><span>Schedule</span><strong>{election.schedule_status.replace("_", " ")}</strong></div>
                  <div><span>Voter Category</span><strong>{election.eligible_voter_category_display || election.eligible_voter_category}</strong></div>
                  <div><span>Department Scope</span><strong>{isAllDepartments ? "All Departments" : "Specific Departments"}</strong></div>
                  <div><span>Positions</span><strong>{metrics.position_count}</strong></div>
                  <div><span>Candidates</span><strong>{metrics.candidate_count}</strong></div>
                </div>
              </section>

              {isAllDepartments && (
                <section className="analytics-modern-card department-card">
                  <div className="analytics-card-title">
                    <div><h2>Turnout by Department</h2><p>Total voter turnout by department</p></div>
                    <span className="analytics-card-icon">▥</span>
                  </div>
                  <DepartmentBarChart departments={data.department_turnout} />
                </section>
              )}
            </div>

            <div className={`analytics-bottom-grid${isAllDepartments ? "" : " analytics-bottom-single"}`}>
              <section className="analytics-modern-card activity-card">
                <div className="analytics-card-title activity-heading">
                  <div><h2>Voting Activity</h2><p>Daily votes across the full election period (aggregate only).</p></div>
                </div>
                <VotingActivityChart activity={activity} />
              </section>

              {isAllDepartments && (
                <section className="analytics-modern-card donut-card">
                  <div className="analytics-card-title">
                    <div><h2>Turnout by Department (Donut)</h2><p>Department share of total turnout.</p></div>
                    <span className="analytics-card-icon">◕</span>
                  </div>
                  <DepartmentDonut departments={data.department_turnout} totalVotes={metrics.total_votes} admin />
                </section>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}
