import React, {useEffect, useState} from "react";
import {Link} from "react-router-dom";
import {mediaUrl} from "../../services/api";
import {createElection, updateElection, listAdminElections, getAdminElection, deleteElection, createPosition, updatePosition, listPositions, deletePosition, createCandidate, updateCandidate, listCandidates, deleteCandidate, listDepartments} from "../../services/adminService";
import { AdminTopbar } from "../../components/layout/AdminTopbar";

const CATEGORIES = [
  ["student", "Student"],
  ["alumni", "Alumni"],
  ["faculty", "Faculty"],
];

const CATEGORY_META = {
  student: { label: "Student", className: "student" },
  alumni: { label: "Alumni", className: "alumni" },
  faculty: { label: "Faculty", className: "faculty" },
};

function SvgIcon({ name, size = 20 }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", "aria-hidden": true };
  if (name === "search") return <svg {...common}><circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="2"/><path d="m16 16 4.2 4.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>;
  if (name === "building") return <svg {...common}><path d="M4 21h16M6 21V8l6-3 6 3v13M9 10v2M12 10v2M15 10v2M9 15v2M12 15v2M15 15v2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M3 8h18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>;
  if (name === "tag") return <svg {...common}><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H13l7 7-9 9-7-7V5.5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><circle cx="8" cy="8" r="1.2" fill="currentColor"/></svg>;
  if (name === "calendar") return <svg {...common}><rect x="4" y="5.5" width="16" height="15" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M8 3.5v4M16 3.5v4M4 10h16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>;
  if (name === "pencil") return <svg {...common}><path d="m14.5 5.5 4 4M5 19l3.3-.7L19.2 7.4a2.1 2.1 0 0 0-3-3L5.3 15.3 5 19Z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
  if (name === "eye") return <svg {...common}><path d="M3.2 12s3.2-5 8.8-5 8.8 5 8.8 5-3.2 5-8.8 5-8.8-5-8.8-5Z" stroke="currentColor" strokeWidth="1.8"/><circle cx="12" cy="12" r="2.2" stroke="currentColor" strokeWidth="1.8"/></svg>;
  if (name === "trash") return <svg {...common}><path d="M5 7h14M9 7V4h6v3M7 7l.7 13h8.6L17 7M10 11v5M14 11v5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
  if (name === "lock") return <svg {...common}><rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>;
  if (name === "plus") return <svg {...common}><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>;
  if (name === "chevron") return <svg {...common}><path d="m8 10 4 4 4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
  if (name === "cap") return <svg {...common}><path d="m3 10 9-5 9 5-9 5-9-5Z" fill="currentColor" opacity=".95"/><path d="M6.5 12.2V16c2.1 1.6 4 2.3 5.5 2.3s3.4-.7 5.5-2.3v-3.8M21 10v6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
  if (name === "users") return <svg {...common}><circle cx="9" cy="9" r="3.2" fill="currentColor"/><circle cx="16.5" cy="10" r="2.5" fill="currentColor" opacity=".75"/><path d="M3.8 19c.5-3.1 2.3-4.8 5.2-4.8s4.7 1.7 5.2 4.8M14 16c2.7-.1 4.6.9 5.2 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>;
  if (name === "user") return <svg {...common}><circle cx="12" cy="8" r="3.2" fill="currentColor"/><path d="M5.5 20c.6-4 2.8-6 6.5-6s5.9 2 6.5 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>;
  return null;
}

function ElectionCategoryIcon({ category }) {
  const meta = CATEGORY_META[category] || CATEGORY_META.student;
  const icon = category === "student" ? "cap" : category === "alumni" ? "users" : "user";
  return <span className={`election-category-icon ${meta.className}`} title={meta.label}><SvgIcon name={icon} size={34} /></span>;
}

function toLocalInputValue(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const pad = number => String(number).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function toApiDateTime(value) {
  if (!value) return "";
  return new Date(value).toISOString();
}

function displayDate(value) {
  return value ? new Date(value).toLocaleString() : "—";
}


function ElectionForm({election, onClose, onSaved}) {
  const [form, setForm] = useState({
    name: election?.name || "",
    description: election?.description || "",
    start_datetime: toLocalInputValue(election?.start_datetime),
    end_datetime: toLocalInputValue(election?.end_datetime),
    eligible_voter_category: election?.eligible_voter_category || "student",
    department_scope: election?.department_scope || "all",
    eligible_departments: election?.eligible_departments || [],
  });
  const [departments, setDepartments] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    listDepartments("status=active")
      .then(items => { if (mounted) setDepartments(items); })
      .catch(err => { if (mounted) setError(err.message); });
    return () => { mounted = false; };
  }, []);

  function update(field, value) {
    setForm(current => ({...current, [field]: value}));
  }

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!form.name.trim()) {
      setError("Election name cannot be empty or contain only spaces.");
      return;
    }
    if (new Date(form.start_datetime) >= new Date(form.end_datetime)) {
      setError("End date/time must be after the start date/time.");
      return;
    }
    if (form.department_scope === "specific" && form.eligible_departments.length === 0) {
      setError("Select at least one department for Specific Departments.");
      return;
    }
    setLoading(true);
    try {
      const payload = {
        name: form.name.trim().toUpperCase(),
        description: form.description.trim(),
        start_datetime: toApiDateTime(form.start_datetime),
        end_datetime: toApiDateTime(form.end_datetime),
        eligible_voter_category: form.eligible_voter_category,
        department_scope: form.department_scope,
        eligible_departments: form.department_scope === "specific" ? form.eligible_departments.map(Number) : [],
      };
      if (election) {
        await updateElection(election.id, payload);
      } else {
        await createElection(payload);
      }
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal election-edit-modal" role="dialog" aria-modal="true" aria-labelledby="election-form-title">
      <div className="election-modal-header">
        <div className="election-modal-title-wrap">
          <div className="election-modal-icon"><SvgIcon name="pencil" size={22} /></div>
          <div>
            <h2 id="election-form-title">{election ? "Edit Election" : "Create Election"}</h2>
            <p>Update the election details and settings below. Changes will be saved immediately.</p>
          </div>
        </div>
        <button className="modal-close election-modal-close" type="button" onClick={onClose} aria-label="Close">
          ×
        </button>
      </div>

      <form className="election-form" onSubmit={submit}>
        <div className="election-form-grid">
          <div className="election-field">
            <label htmlFor="election-name">Election Name <span className="required-mark">*</span></label>
            <div className="election-input-wrap">
              <span className="election-input-icon"><SvgIcon name="tag" size={18} /></span>
              <input
                id="election-name"
                className="election-input with-icon"
                value={form.name}
                onChange={e => update("name", e.target.value.toUpperCase())}
                required
                maxLength={120}
                placeholder="Enter election name"
              />
            </div>
            <small>Enter the name of the election. Use uppercase for consistency.</small>
          </div>

          <div className="election-field">
            <label htmlFor="eligible-voter-category">Eligible Voter Category <span className="required-mark">*</span></label>
            <div className="election-input-wrap">
              <span className="election-input-icon"><SvgIcon name="users" size={18} /></span>
              <select
                id="eligible-voter-category"
                className="election-input with-icon"
                value={form.eligible_voter_category}
                onChange={e => update("eligible_voter_category", e.target.value)}
              >
                {CATEGORIES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
              </select>
            </div>
            <small>Select which category of voters can participate in this election.</small>
          </div>
        </div>

        <div className="election-field description-field">
          <label htmlFor="election-description">Description</label>
          <div className="election-textarea-wrap">
            <span className="election-textarea-icon"><SvgIcon name="tag" size={18} /></span>
            <textarea
              id="election-description"
              className="election-textarea"
              value={form.description}
              onChange={e => update("description", e.target.value)}
              maxLength={500}
              rows="4"
              placeholder="Enter a brief description of the election..."
            />
          </div>
          <div className="character-count">{form.description.length}/500</div>
        </div>

        <div className="election-schedule-card">
          <div className="election-section-title">
            <span className="election-section-icon"><SvgIcon name="calendar" size={20} /></span>
            <h3>Election Schedule</h3>
          </div>
          <div className="election-form-grid">
            <div className="election-field">
              <label htmlFor="election-start">Start Date and Time <span className="required-mark">*</span></label>
              <div className="election-input-wrap">
                <span className="election-input-icon"><SvgIcon name="calendar" size={18} /></span>
                <input
                  id="election-start"
                  className="election-input with-icon"
                  type="datetime-local"
                  value={form.start_datetime}
                  onChange={e => update("start_datetime", e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="election-field">
              <label htmlFor="election-end">End Date and Time <span className="required-mark">*</span></label>
              <div className="election-input-wrap">
                <span className="election-input-icon"><SvgIcon name="calendar" size={18} /></span>
                <input
                  id="election-end"
                  className="election-input with-icon"
                  type="datetime-local"
                  value={form.end_datetime}
                  onChange={e => update("end_datetime", e.target.value)}
                  required
                />
              </div>
            </div>
          </div>
        </div>

        <div className="election-field department-field">
          <label htmlFor="department-scope">Department Scope <span className="required-mark">*</span></label>
          <div className="election-input-wrap">
            <span className="election-input-icon"><SvgIcon name="building" size={18} /></span>
            <select
              id="department-scope"
              className="election-input with-icon"
              value={form.department_scope}
              onChange={e => {
                const value = e.target.value;
                update("department_scope", value);
                if (value === "all") update("eligible_departments", []);
              }}
            >
              <option value="all">All Departments</option>
              <option value="specific">Specific Departments</option>
            </select>
          </div>
          <small>Select the department(s) that this election will cover.</small>
        </div>

        {form.department_scope === "specific" && <div className="specific-departments election-field">
          <label htmlFor="eligible-departments">Eligible Departments</label>
          <select
            id="eligible-departments"
            className="election-input department-multi-select"
            multiple
            size={Math.min(Math.max(departments.length, 3), 6)}
            value={form.eligible_departments.map(String)}
            onChange={e => update("eligible_departments", Array.from(e.target.selectedOptions, option => Number(option.value)))}
          >
            {departments.map(department => <option key={department.id} value={department.id}>{department.code} — {department.name}</option>)}
          </select>
          {departments.length === 0 && <small>No active departments are available.</small>}
          <small>Hold Ctrl (Windows) or Command (Mac) to select multiple departments.</small>
        </div>}

        {error && <div className="error election-form-error" role="alert">{error}</div>}

        <div className="modal-actions election-modal-actions">
          <button type="button" className="secondary election-cancel-button" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary modal-primary election-save-button" disabled={loading}>
            {loading ? "Saving..." : <><span className="save-button-icon">✓</span>{election ? "Save Changes" : "Create Election"}</>}
          </button>
        </div>
      </form>
    </section>
  </div>;

}

function getElectionStatusDisplay(status) {
  const statusMap = {
    not_started: { label: "Not Started", subtext: "Voting not started" },
    active: { label: "Active", subtext: "Voting open" },
    ended: { label: "Ended", subtext: "Voting closed" },
    inactive: { label: "Inactive", subtext: "Voting closed" },
  };
  return statusMap[status] || statusMap.inactive;
}

function ElectionDetails({election, onClose}) {
  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal small-modal">
      <div className="modal-header">
        <div><h2>Election Details</h2><p>{election.name}</p></div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <div className="detail-list">
        <div><span>Description</span><strong>{election.description || "No description"}</strong></div>
        <div><span>Eligible voters</span><strong>{CATEGORIES.find(([value]) => value === election.eligible_voter_category)?.[1] || election.eligible_voter_category}</strong></div>
        <div><span>Department scope</span><strong>{election.department_scope === "specific" ? `Specific (${(election.eligible_departments || []).length} departments)` : "All Departments"}</strong></div>
        <div><span>Start</span><strong>{displayDate(election.start_datetime)}</strong></div>
        <div><span>End</span><strong>{displayDate(election.end_datetime)}</strong></div>
        <div><span>Status</span><strong className={`status-badge ${election.status}`}>{getElectionStatusDisplay(election.status).label}</strong></div>
        <div><span>Voting currently allowed</span><strong>{election.is_open ? "Yes" : "No"}</strong></div>
        <div><span>Created</span><strong>{displayDate(election.created_date)}</strong></div>
      </div>
      <div className="modal-actions"><button className="secondary" onClick={onClose}>Close</button></div>
    </section>
  </div>;
}

function PositionForm({election, position, onClose, onSaved}) {
  const [name, setName] = useState(position?.name || "");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!name.trim()) {
      setError("Position name is required.");
      return;
    }

    setLoading(true);
    try {
      const payload = {name: name.trim()};
      if (position) {
        await updatePosition(position.id, payload);
      } else {
        await createPosition(election.id, payload);
      }
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal small-modal">
      <div className="modal-header">
        <div><h2>{position ? "Edit Position" : "Add Position"}</h2><p>{election.name}</p></div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <form onSubmit={submit}>
        <label>Position name</label>
        <input
          className="standalone-input"
          value={name}
          onChange={event => setName(event.target.value)}
          placeholder="e.g. President"
          maxLength={80}
          required
        />
    
        {error && <div className="error">{error}</div>}
        <div className="modal-actions">
          <button type="button" className="secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary modal-primary" disabled={loading}>{loading ? "Saving..." : position ? "Save Changes" : "Add Position"}</button>
        </div>
      </form>
    </section>
  </div>;
}

function CandidateForm({election, position, candidate, onClose, onSaved}) {
  const [name, setName] = useState(candidate?.name || "");
  const [partyList, setPartyList] = useState(candidate?.party_list || "");
  const [platform, setPlatform] = useState(candidate?.platform || "");
  const [photo, setPhoto] = useState(null);
  const [removePhoto, setRemovePhoto] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!name.trim()) {
      setError("Candidate name cannot be empty or contain only spaces.");
      return;
    }
    if (photo && photo.size > 5 * 1024 * 1024) {
      setError("Candidate photo must be 5 MB or smaller.");
      return;
    }
    if (photo && removePhoto) {
      setError("Choose a new photo or remove the current photo, not both.");
      return;
    }
    setLoading(true);
    try {
      const payload = new FormData();
      payload.append("name", name.trim());
      payload.append("party_list", partyList.trim());
      payload.append("platform", platform.trim());
      if (photo) payload.append("photo", photo);
      if (candidate && removePhoto) payload.append("remove_photo", "true");

      if (candidate) {
        await updateCandidate(candidate.id, payload);
      } else {
        await createCandidate(election.id, position.id, payload);
      }
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal small-modal">
      <div className="modal-header">
        <div><h2>{candidate ? "Edit Candidate" : "Add Candidate"}</h2><p>{election.name} · {position.name}</p></div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <form onSubmit={submit}>
        <label>Candidate name</label>
        <input className="standalone-input" value={name} onChange={event => setName(event.target.value)} placeholder="e.g. Juan Dela Cruz" maxLength={120} required />
        <label>Party List</label>
        <input className="standalone-input" value={partyList} onChange={event => setPartyList(event.target.value)} placeholder="e.g. Student Unity Party" maxLength={120} />
        <label>Candidate Photo</label>
        {candidate?.photo && !removePhoto && <div className="candidate-photo-preview"><img src={mediaUrl(candidate.photo)} alt={`${candidate.name} candidate`} /></div>}
        <input className="standalone-input" type="file" accept="image/jpeg,image/png,image/webp" onChange={event => { setPhoto(event.target.files?.[0] || null); setRemovePhoto(false); }} />
        <small className="field-help">Optional. JPG, PNG, or WebP. Maximum 5 MB.</small>
        {candidate?.photo && <label className="checkbox-row"><input type="checkbox" checked={removePhoto} onChange={event => { setRemovePhoto(event.target.checked); if (event.target.checked) setPhoto(null); }} /> Remove current photo</label>}
        <label>Biography / Platform</label>
        <textarea className="standalone-input" value={platform} onChange={event => setPlatform(event.target.value)} rows="5" placeholder="Candidate biography or platform" />
        {error && <div className="error">{error}</div>}
        <div className="modal-actions">
          <button type="button" className="secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary modal-primary" disabled={loading}>{loading ? "Saving..." : candidate ? "Save Changes" : "Add Candidate"}</button>
        </div>
      </form>
    </section>
  </div>;
}

function CandidateManagement({election, position, onClose}) {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);

  async function loadCandidates() {
    setLoading(true);
    setError("");
    try {
      setCandidates(await listCandidates(election.id, position.id));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadCandidates(); }, [election.id, position.id]);

  async function deleteCandidate(candidate) {
    if (!window.confirm(`Delete "${candidate.name}" from ${position.name}?`)) return;
    try {
      await deleteCandidate(candidate.id);
      await loadCandidates();
      setSuccess("Candidate deleted successfully.");
    } catch (err) {
      setError(err.message);
    }
  }

  function saved() {
    setCreating(false);
    setEditing(null);
    setSuccess("Candidate saved successfully.");
    loadCandidates();
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal position-modal">
      <div className="modal-header">
        <div><h2>Candidate Management</h2><p>{election.name} · {position.name}</p></div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <div className="position-toolbar">
        <span>Manage candidates for this position.</span>
        <button className="primary modal-primary" onClick={() => setCreating(true)}>+ Add Candidate</button>
      </div>
      {error && <div className="error">{error}</div>}
      {success && <div className="success" role="status">{success}</div>}
      {loading ? <div className="loading-state"><span className="spinner" /> Loading candidates...</div> : candidates.length === 0 ? <div className="empty-state">No candidates found. Add the first candidate for this position.</div> :
        <div className="table-scroll">
          <table className="admin-table position-table">
            <thead><tr><th>Photo</th><th>Candidate</th><th>Party List</th><th>Biography / Platform</th><th>Actions</th></tr></thead>
            <tbody>{candidates.map(candidate => <tr key={candidate.id}>
              <td>{candidate.photo ? <img className="candidate-table-photo" src={mediaUrl(candidate.photo)} alt="" /> : "—"}</td>
              <td><strong>{candidate.name}</strong></td>
              <td>{candidate.party_list || "Independent / No party list"}</td>
              <td>{candidate.platform || "No biography/platform provided"}</td>
              <td><div className="table-actions">
                <button className="link-button" onClick={() => setEditing(candidate)}>Edit</button>
                <button className="link-button danger-link" onClick={() => deleteCandidate(candidate)}>Delete</button>
              </div></td>
            </tr>)}</tbody>
          </table>
        </div>}
      <div className="modal-actions"><button className="secondary" onClick={onClose}>Close</button></div>
    </section>
    {creating && <CandidateForm election={election} position={position} onClose={() => setCreating(false)} onSaved={saved} />}
    {editing && <CandidateForm election={election} position={position} candidate={editing} onClose={() => setEditing(null)} onSaved={saved} />}
  </div>;
}

function PositionManagement({election, onClose}) {
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);
  const [candidatesPosition, setCandidatesPosition] = useState(null);

  async function loadPositions() {
    setLoading(true);
    setError("");
    try {
      setPositions(await listPositions(election.id));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadPositions(); }, [election.id]);

  async function deletePosition(position) {
    if (!window.confirm(`Delete "${position.name}" from this election?`)) return;
    try {
      await deletePosition(position.id);
      await loadPositions();
      setSuccess("Position deleted successfully.");
    } catch (err) {
      setError(err.message);
    }
  }

  function saved() {
    setCreating(false);
    setEditing(null);
    setSuccess("Position saved successfully.");
    loadPositions();
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal position-modal">
      <div className="modal-header">
        <div><h2>Position Management</h2><p>{election.name}</p></div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <div className="position-toolbar">
        <span>Manage the positions voters will see in this election.</span>
        <button className="primary modal-primary" onClick={() => setCreating(true)}>+ Add Position</button>
      </div>
      {error && <div className="error">{error}</div>}
      {success && <div className="success" role="status">{success}</div>}
      {loading ? <div className="loading-state"><span className="spinner" /> Loading positions...</div> : positions.length === 0 ? <div className="empty-state">No positions found. Add the first position for this election.</div> :
        <div className="table-scroll">
          <table className="admin-table position-table">
            <thead><tr><th>Position</th><th>Actions</th></tr></thead>
            <tbody>{positions.map(position => <tr key={position.id}>
              <td><strong>{position.name}</strong></td>
              <td><div className="table-actions">
                <button className="link-button" onClick={() => setCandidatesPosition(position)}>Candidates</button>
                <button className="link-button" onClick={() => setEditing(position)}>Edit</button>
                <button className="link-button danger-link" onClick={() => deletePosition(position)}>Delete</button>
              </div></td>
            </tr>)}</tbody>
          </table>
        </div>}
      <div className="modal-actions"><button className="secondary" onClick={onClose}>Close</button></div>
    </section>
    {creating && <PositionForm election={election} onClose={() => setCreating(false)} onSaved={saved} />}
    {editing && <PositionForm election={election} position={editing} onClose={() => setEditing(null)} onSaved={saved} />}
    {candidatesPosition && <CandidateManagement election={election} position={candidatesPosition} onClose={() => setCandidatesPosition(null)} />}
  </div>;
}

export default function AdminElections() {
  const [elections, setElections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [formElection, setFormElection] = useState(null);
  const [creating, setCreating] = useState(false);
  const [details, setDetails] = useState(null);
  const [positionsElection, setPositionsElection] = useState(null);
  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [departments, setDepartments] = useState([]);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 4;

  async function loadElections() {
    setLoading(true);
    setError("");
    try {
      setElections(await listAdminElections());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function loadDepartments() {
    try {
      const data = await listDepartments("status=active");
      setDepartments(data);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadElections();
    loadDepartments();
  }, []);

  async function viewDetails(election) {
    try {
      setDetails(await getAdminElection(election.id));
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteElection(election) {
    if (election.status === "active") return;
    if (!window.confirm(`Delete "${election.name}"? This cannot be undone.`)) return;
    try {
      await deleteElection(election.id);
      await loadElections();
      setSuccess("Election deleted successfully.");
    } catch (err) {
      setError(err.message);
    }
  }

  function saved() {
    setCreating(false);
    setFormElection(null);
    setSuccess("Election saved successfully.");
    loadElections();
  }

  const departmentMap = new Map(
    departments.map(department => [String(department.id), department])
  );

  const sortedDepartments = [...departments].sort((a, b) =>
    String(a.code || a.name || "").localeCompare(
      String(b.code || b.name || ""),
      undefined,
      { sensitivity: "base" }
    )
  );

  const filteredElections = elections
    .filter(election => {
      const query = search.trim().toLowerCase();

      const electionDepartmentNames = (election.eligible_departments || [])
        .map(departmentId => departmentMap.get(String(departmentId)))
        .filter(Boolean)
        .flatMap(department => [department.code, department.name]);

      const matchesSearch =
        !query ||
        [
          election.name,
          election.description,
          election.eligible_voter_category,
          election.department_scope,
          ...electionDepartmentNames,
        ]
          .filter(Boolean)
          .some(value => String(value).toLowerCase().includes(query));

      // "All Departments" shows every election.
      // Selecting a department shows ONLY elections explicitly assigned
      // to that department. Elections with scope="all" are not included.
      const matchesDepartment =
        departmentFilter === "all" ||
        (
          election.department_scope === "specific" &&
          (election.eligible_departments || []).some(
            departmentId => String(departmentId) === String(departmentFilter)
          )
        );

      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "inactive"
          ? election.status === "not_started"
          : election.status === statusFilter);

      return matchesSearch && matchesDepartment && matchesStatus;
    })
    .sort((a, b) => {
      // All Departments elections always come first.
      if (a.department_scope !== b.department_scope) {
        return a.department_scope === "all" ? -1 : 1;
      }

      // Within the same department scope, sort alphabetically by election name.
      return String(a.name || "").localeCompare(
        String(b.name || ""),
        undefined,
        { sensitivity: "base" }
      );
    });

  const totalPages = Math.max(1, Math.ceil(filteredElections.length / PAGE_SIZE));
  const visibleElections = filteredElections.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function resetPage() {
    if (page !== 1) setPage(1);
  }

  return <div className="admin-elections-screen">
    <AdminTopbar />
    <main className="dashboard admin-elections-page">
      <section className="election-hero">
        <div className="election-hero-icon"><SvgIcon name="building" size={42} /></div>
        <div className="election-hero-copy">
          <span className="election-hero-eyebrow">ELECTION MANAGEMENT</span>
          <h1>Manage Elections</h1>
          <p>Create and manage election schedules, positions, and eligible voter categories.</p>
        </div>
        <button className="election-create-button" onClick={() => setCreating(true)}>
          <SvgIcon name="plus" size={20} />
          <span>Create Election</span>
        </button>
      </section>

      {error && <div className="error">{error}</div>}
      {success && <div className="success" role="status">{success}</div>}

      <section className="election-filter-card">
        <div className="election-search-field">
          <SvgIcon name="search" size={22} />
          <input
            value={search}
            onChange={event => { setSearch(event.target.value); resetPage(); }}
            placeholder="Search elections by name, department, or status..."
            aria-label="Search elections"
          />
        </div>
        <label className="election-select-field">
          <span>
            <SvgIcon name="building" size={19} />
            Department
          </span>

          <select
            value={departmentFilter}
            onChange={event => {
              setDepartmentFilter(event.target.value);
              resetPage();
            }}
          >
            <option value="all">All Departments</option>

            {sortedDepartments.map(department => (
              <option key={department.id} value={department.id}>
                {department.code}
              </option>
            ))}
          </select>

          <SvgIcon name="chevron" size={18} />
        </label>
        <label className="election-select-field">
          <span><SvgIcon name="tag" size={19} /> Status</span>
          <select value={statusFilter} onChange={event => { setStatusFilter(event.target.value); resetPage(); }}>
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="ended">Ended</option>
            <option value="inactive">Inactive</option>
          </select>
          <SvgIcon name="chevron" size={18} />
        </label>
      </section>

      <section className="election-list-card">
        <div className="election-list-heading">
          <div className="election-list-title"><SvgIcon name="users" size={27} /><h2>Elections ({filteredElections.length})</h2></div>
          <span className="election-total-pill">{elections.length} total elections</span>
        </div>

        {loading ? <div className="loading-state"><span className="spinner" /> Loading elections...</div> : filteredElections.length === 0 ? (
          <div className="empty-state">
            {departmentFilter !== "all"
              ? `No elections found for ${departmentMap.get(String(departmentFilter))?.code || "this department"}.`
              : "No elections match your search or filters."}
          </div>
        ) :
          <div className="election-table-scroll">
            <table className="admin-table election-management-table">
              <thead><tr>
                <th>Title</th>
                <th>Department / Scope</th>
                <th>Start</th>
                <th>End</th>
                <th>Status</th>
                <th>Actions</th>
              </tr></thead>
              <tbody>{visibleElections.map(election => {
                const category = CATEGORY_META[election.eligible_voter_category] || CATEGORY_META.student;
                const canDelete = election.status !== "active";
                return <tr key={election.id}>
                  <td>
                    <div className="admin-election-cell">
                      <div className="admin-election-title-row">
                          <ElectionCategoryIcon category={election.eligible_voter_category} />

                          <div className="admin-election-title-content">
                              <strong>{election.name}</strong>

                              {election.description?.trim() && (
                                  <button
                                      type="button"
                                      className="admin-election-description-link"
                                      onClick={() => viewDetails(election)}
                                  >
                                      See description
                                  </button>
                              )}
                          </div>
                      </div>
                  </div>
                  </td>
                  <td>
                    <div className="election-scope-cell">
                      <SvgIcon name="building" size={20} />
                      <div>
                        <span>
                          {election.department_scope === "specific"
                            ? (election.eligible_departments || [])
                                .map(departmentId => departmentMap.get(String(departmentId))?.code)
                                .filter(Boolean)
                                .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }))
                                .join(", ") || "Specific Departments"
                            : "All Departments"}
                        </span>
                        <em className={`election-category-badge ${category.className}`}>{category.label}</em>
                      </div>
                    </div>
                  </td>
                  <td><div className="election-date-cell"><SvgIcon name="calendar" size={20} /><span>{displayDate(election.start_datetime)}</span></div></td>
                  <td><div className="election-date-cell"><SvgIcon name="calendar" size={20} /><span>{displayDate(election.end_datetime)}</span></div></td>
                  <td><div className="election-status-cell"><span className={`election-status-badge ${election.status}`}><i />{getElectionStatusDisplay(election.status).label}</span><small>{getElectionStatusDisplay(election.status).subtext}</small></div></td>
                  <td>
                    <div className="election-actions-cell">
                      <div className="election-action-icons">
                        <button className="election-icon-button edit" title="Edit election" aria-label={`Edit ${election.name}`} onClick={() => setFormElection(election)}><SvgIcon name="pencil" size={18} /></button>
                        <button className="election-icon-button view" title="View details" aria-label={`View details for ${election.name}`} onClick={() => viewDetails(election)}><SvgIcon name="eye" size={18} /></button>
                        <button className="election-icon-button delete" title={canDelete ? "Delete election" : "Delete locked while active"} aria-label={`Delete ${election.name}`} disabled={!canDelete} onClick={() => deleteElection(election)}><SvgIcon name="trash" size={18} /></button>
                      </div>
                      <div className="election-action-links">
                        <button className="election-action-link manage" onClick={() => setPositionsElection(election)}>Manage Positions &amp; Candidates</button>
                        <span className="election-action-separator" />
                        <button className={`election-action-link delete-text ${!canDelete ? "locked" : ""}`} disabled={!canDelete} onClick={() => deleteElection(election)}>
                          {!canDelete && <SvgIcon name="lock" size={14} />}
                          {canDelete ? "Delete" : "Delete Locked"}
                        </button>
                      </div>
                    </div>
                  </td>
                </tr>;
              })}</tbody>
            </table>
          </div>}

        {filteredElections.length > 0 && <div className="election-pagination">
          <span>Showing {((page - 1) * PAGE_SIZE) + 1}-{Math.min(page * PAGE_SIZE, filteredElections.length)} of {filteredElections.length} elections</span>
          <div>
            <button disabled={page === 1} onClick={() => setPage(current => Math.max(1, current - 1))} aria-label="Previous page">‹</button>
            {Array.from({length: totalPages}, (_, index) => index + 1).map(number => <button key={number} className={page === number ? "active" : ""} onClick={() => setPage(number)}>{number}</button>)}
            <button disabled={page === totalPages} onClick={() => setPage(current => Math.min(totalPages, current + 1))} aria-label="Next page">›</button>
          </div>
        </div>}
      </section>
    </main>
    {creating && <ElectionForm onClose={() => setCreating(false)} onSaved={saved} />}
    {formElection && <ElectionForm election={formElection} onClose={() => setFormElection(null)} onSaved={saved} />}
    {details && <ElectionDetails election={details} onClose={() => setDetails(null)} />}
    {positionsElection && <PositionManagement election={positionsElection} onClose={() => setPositionsElection(null)} />}
  </div>;
}
