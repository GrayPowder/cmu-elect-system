import React, {useEffect, useMemo, useState} from "react";
import {Link} from "react-router-dom";
import {createVoter, updateVoter, listVoters, resetVoterPassword, listDepartments} from "../../services/adminService";
import { AdminTopbar } from "../../components/layout/AdminTopbar";

const CATEGORIES = [
  ["", "All categories"],
  ["student", "Student"],
  ["alumni", "Alumni"],
  ["faculty", "Faculty"],
];

const STATUSES = [
  ["", "All statuses"],
  ["active", "Active"],
  ["inactive", "Inactive"],
];

function generatePassword() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
  const values = new Uint32Array(16);
  crypto.getRandomValues(values);
  return Array.from(values, value => alphabet[value % alphabet.length]).join("");
}

function SvgIcon({children, viewBox = "0 0 24 24", className = ""}) {
  return <svg className={className} viewBox={viewBox} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>;
}

function UsersIcon() { return <SvgIcon><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></SvgIcon>; }
function UserCheckIcon() { return <SvgIcon><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4"/><path d="m16 19 2 2 4-5"/></SvgIcon>; }
function UserMinusIcon() { return <SvgIcon><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4"/><path d="M16 19h6"/></SvgIcon>; }
function ShieldIcon() { return <SvgIcon><path d="M12 3 20 6v5c0 5-3.4 8.5-8 10-4.6-1.5-8-5-8-10V6l8-3Z"/><path d="m9 12 2 2 4-4"/></SvgIcon>; }
function SearchIcon() { return <SvgIcon><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></SvgIcon>; }
function FilterIcon() { return <SvgIcon><path d="M4 5h16M7 12h10M10 19h4"/></SvgIcon>; }
function ToggleIcon() { return <SvgIcon><rect x="3" y="7" width="18" height="10" rx="5"/><circle cx="8" cy="12" r="3"/></SvgIcon>; }
function ChevronIcon() { return <SvgIcon><path d="m7 10 5 5 5-5"/></SvgIcon>; }
function PlusIcon() { return <SvgIcon><path d="M12 5v14M5 12h14"/></SvgIcon>; }
function CalendarIcon() { return <SvgIcon><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 9h18"/></SvgIcon>; }
function EditIcon() { return <SvgIcon><path d="m4 16-.7 4.7L8 20l11-11a2.1 2.1 0 0 0-3-3L5 17Z"/><path d="m14 7 3 3"/></SvgIcon>; }
function ResetIcon() { return <SvgIcon><path d="M4 12a8 8 0 1 0 3-6.2"/><path d="M4 5v5h5"/></SvgIcon>; }
function TrashIcon() { return <SvgIcon><path d="M4 7h16M10 11v6M14 11v6M6 7l1 14h10l1-14M9 7V4h6v3"/></SvgIcon>; }
function CheckIcon() { return <SvgIcon><path d="m5 12 4 4L19 6"/></SvgIcon>; }


function VoterForm({voter, departments, onClose, onSaved}) {
  const editing = Boolean(voter);
  const [form, setForm] = useState(() => ({
    name: voter?.name || "",
    identifier: voter?.identifier || "",
    email: voter?.email || "",
    category: voter?.category || "student",
    department: voter?.department ?? "",
    status: voter?.status || "active",
    password: "",
  }));
  const [generated, setGenerated] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(key, value) {
    setForm(current => ({...current, [key]: value}));
  }

  function generate() {
    const password = generatePassword();
    update("password", password);
    setGenerated(true);
  }

  async function submit(event) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      const payload = {
        name: form.name.trim(),
        email: form.email.trim(),
      };

      if (!editing) {
        payload.identifier = form.identifier.trim();
        payload.category = form.category;
        payload.status = form.status;

        if (form.department !== "") {
          payload.department = Number(form.department);
        }

        payload.password = form.password;
      }

      const data = editing
        ? await updateVoter(voter.id, payload)
        : await createVoter(payload);
      onSaved(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal">
      <div className="modal-header">
        <div>
          <h2>{editing ? "Edit Voter" : "Create Voter"}</h2>
          <p>{editing ? "Update the voter's account information." : "Create an account for an authorized voter."}</p>
        </div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>

      <form onSubmit={submit}>
        <div className="form-grid">
          {/* Name - shown for both Create and Edit */}
          <div>
            <label>Name</label>
            <input
              value={form.name}
              onChange={e => update("name", e.target.value)}
              required
            />
          </div>

          {/* Email - shown for both Create and Edit */}
          <div>
            <label>Email</label>
            <input
              type="email"
              value={form.email}
              onChange={e => update("email", e.target.value)}
              required
            />
          </div>

          {/* These fields are only needed when creating a voter */}
          {!editing && (
            <>
              <div>
                <label>Username</label>
                <input
                  value={form.identifier}
                  onChange={e => update("identifier", e.target.value)}
                  required
                />
              </div>

              <div>
                <label>Voter category</label>
                <select
                  value={form.category}
                  onChange={e => update("category", e.target.value)}
                >
                  {CATEGORIES.slice(1).map(([value, label]) => (
                    <option value={value} key={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label>Department</label>
                <select
                  value={form.department}
                  onChange={e => update("department", e.target.value)}
                  required
                >
                  <option value="">Select a department</option>

                  {departments
                    .filter(department => department.is_active)
                    .map(department => (
                      <option
                        value={department.id}
                        key={department.id}
                      >
                        {department.code} — {department.name}
                      </option>
                    ))}
                </select>

                <p className="password-note">
                  Only active departments can be newly assigned.
                </p>
              </div>

              <div>
                <label>Account status</label>
                <select
                  value={form.status}
                  onChange={e => update("status", e.target.value)}
                >
                  {STATUSES.slice(1).map(([value, label]) => (
                    <option value={value} key={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="password-field">
                <label>Initial password</label>

                <div className="password-row">
                  <input
                    type="text"
                    value={form.password}
                    onChange={e => {
                      update("password", e.target.value);
                      setGenerated(false);
                    }}
                    minLength="8"
                    required
                  />

                  <button
                    type="button"
                    className="secondary"
                    onClick={generate}
                  >
                    Generate
                  </button>
                </div>

                {generated && (
                  <p className="password-note">
                    Generated in this browser. It is sent only when the
                    account is created and is never returned by the API.
                  </p>
                )}
              </div>
            </>
          )}
        </div>

        {error && <div className="error">{error}</div>}
        <div className="modal-actions">
          <button type="button" className="secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary modal-primary" disabled={loading}>{loading ? "Saving..." : editing ? "Save Changes" : "Create Voter"}</button>
        </div>
      </form>
    </section>
  </div>;
}

function PasswordResetModal({voter, onClose, onSaved}) {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [generated, setGenerated] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function generate() {
    const value = generatePassword();
    setPassword(value);
    setConfirmPassword(value);
    setGenerated(true);
  }

  async function submit(event) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      await resetVoterPassword(voter.id, {password, confirm_password: confirmPassword});
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return <div className="modal-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
    <section className="admin-modal small-modal">
      <div className="modal-header">
        <div>
          <h2>Reset Voter Password</h2>
          <p>{voter.name} · {voter.identifier}</p>
        </div>
        <button className="modal-close" type="button" onClick={onClose}>×</button>
      </div>
      <form onSubmit={submit}>
        <label>New password</label>
        <div className="password-row">
          <input type="text" value={password} onChange={e => {setPassword(e.target.value); setGenerated(false);}} minLength="8" required />
          <button type="button" className="secondary" onClick={generate}>Generate</button>
        </div>
        <label>Confirm password</label>
        <input className="standalone-input" type="text" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} minLength="8" required />
        {generated && <p className="password-note">Generated in this browser. The API never returns the password.</p>}
        {error && <div className="error">{error}</div>}
        <div className="modal-actions">
          <button type="button" className="secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="primary modal-primary" disabled={loading}>{loading ? "Resetting..." : "Reset Password"}</button>
        </div>
      </form>
    </section>
  </div>;
}

export default function AdminUsers() {
  const [voters, setVoters] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [department, setDepartment] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [editing, setEditing] = useState(null);
  const [resetting, setResetting] = useState(null);
  const [creating, setCreating] = useState(false);
  const [page, setPage] = useState(1);
  const rowsPerPage = 10;

  async function loadVoters() {
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("search", search.trim());
      if (category) params.set("category", category);
      if (department) {
        params.set("department", String(Number(department)));
      }
      if (status) params.set("status", status);
      const data = await listVoters(params.toString());
      setVoters(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function loadDepartments() {
    try {
      const data = await listDepartments();
      setDepartments(data);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadVoters();
    loadDepartments();
  }, []);

  const summary = useMemo(() => ({
    total: voters.length,
    active: voters.filter(voter => voter.status === "active").length,
    inactive: voters.filter(voter => voter.status === "inactive").length,
    departments: new Set(voters.map(voter => voter.department).filter(Boolean)).size,
  }), [voters]);

  const pageCount = Math.max(1, Math.ceil(voters.length / rowsPerPage));
  const paginatedVoters = useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    return voters.slice(start, start + rowsPerPage);
  }, [voters, page]);

  useEffect(() => {
    setPage(1);
  }, [search, category, department, status]);

  useEffect(() => {
    if (page > pageCount) setPage(pageCount);
  }, [page, pageCount]);

  function handleSaved() {
    setCreating(false);
    setEditing(null);
    setResetting(null);
    setSuccess("Voter account updated successfully.");
    loadVoters();
  }

  async function toggleStatus(voter) {
    const nextStatus = voter.status === "active" ? "inactive" : "active";
    const action = nextStatus === "active" ? "activate" : "deactivate";
    if (!window.confirm(`Are you sure you want to ${action} ${voter.name}?`)) return;
    try {
      await updateVoter(voter.id, {status: nextStatus});
      await loadVoters();
      setSuccess(`Voter account ${nextStatus === "active" ? "activated" : "deactivated"} successfully.`);
    } catch (err) {
      setError(err.message);
    }
  }

  return <div className="admin-users-screen">
    <AdminTopbar />
    <main className="dashboard admin-users-page">
      <div className="voter-page-heading">
        <div className="voter-title-wrap">
          <div className="voter-title-icon"><UsersIcon /></div>
          <div>
            <h1>Voter Account Management</h1>
            <p>Create and manage voter accounts. Public registration is not available.</p>
          </div>
        </div>
        <button className="primary voter-create-button" onClick={() => setCreating(true)}><PlusIcon /> Create Voter</button>
      </div>

      <div className="voter-summary-grid">
        <div className="voter-summary-card total-card">
          <div className="voter-stat-icon blue"><UsersIcon /></div>
          <div className="voter-stat-copy"><strong>{summary.total}</strong><span>Total Voters</span><small>Registered accounts in the system</small></div>
          <span className="stat-arrow">›</span>
        </div>
        <div className="voter-summary-card active-card">
          <div className="voter-stat-icon green"><UserCheckIcon /></div>
          <div className="voter-stat-copy"><strong>{summary.active}</strong><span>Active</span><small>Can participate in elections</small></div>
          <span className="stat-arrow">›</span>
        </div>
        <div className="voter-summary-card inactive-card">
          <div className="voter-stat-icon red"><UserMinusIcon /></div>
          <div className="voter-stat-copy"><strong>{summary.inactive}</strong><span>Inactive</span><small>Not allowed to vote</small></div>
          <span className="stat-arrow">›</span>
        </div>
        <div className="voter-summary-card department-card">
          <div className="voter-stat-icon purple"><ShieldIcon /></div>
          <div className="voter-stat-copy"><strong>{summary.departments}</strong><span>Departments</span><small>With registered voters</small></div>
          <span className="stat-arrow">›</span>
        </div>
      </div>

      <section className="voter-filter-panel">
        <div className="voter-search-field">
          <SearchIcon />
          <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === "Enter" && loadVoters()} placeholder="Search voters by name, identifier, or email..." aria-label="Search voters" />
        </div>
        <div className="voter-filter-select">
          <span className="filter-leading"><UsersIcon /></span>
          <label>Category</label>

          <select
            value={category}
            onChange={e => setCategory(e.target.value)}
          >
            {CATEGORIES.map(([value, label]) => (
              <option value={value} key={value}>
                {label}
              </option>
            ))}
          </select>

          <ChevronIcon />
        </div>

        <div className="voter-filter-select">
          <span className="filter-leading"><ShieldIcon /></span>
          <label>Department</label>

          <select
            value={department}
            onChange={e => setDepartment(e.target.value)}
          >
            <option value="">All departments</option>

            {departments
              .filter(department => department.is_active)
              .map(department => (
                <option
                  value={department.id}
                  key={department.id}
                >
                  {department.code}
                </option>
              ))}
          </select>

          <ChevronIcon />
        </div>

        <div className="voter-filter-select">
          <span className="filter-leading"><ToggleIcon /></span>
          <label>Status</label>

          <select
            value={status}
            onChange={e => setStatus(e.target.value)}
          >
            {STATUSES.map(([value, label]) => (
              <option value={value} key={value}>
                {label}
              </option>
            ))}
          </select>

          <ChevronIcon />
        </div>
        <button className="primary voter-filter-button" onClick={loadVoters}><FilterIcon /> Search / Filter</button>
      </section>

      {error && <div className="error voter-message">{error}</div>}
      {success && <div className="success voter-message" role="status">{success}</div>}

      <section className="voter-table-card">
        <div className="voter-table-heading">
          <div><UsersIcon /><strong>Voters ({voters.length})</strong></div>
          <span>Showing {voters.length === 0 ? 0 : ((page - 1) * rowsPerPage) + 1}-{Math.min(page * rowsPerPage, voters.length)} of {voters.length} voters</span>
        </div>
        {loading ? <div className="loading-state"><span className="spinner" /> Loading voters...</div> : voters.length === 0 ? <div className="empty-state">No voter accounts found.</div> : <div className="table-scroll">
          <table className="voter-management-table">
            <thead>
              <tr><th>Name</th><th>Username</th><th>Email</th><th>Category</th><th>Department</th><th>Status</th><th>Created Date</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {paginatedVoters.map(voter => {
                const initials = voter.name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join("").toUpperCase();
                const department = voter.department ? (departments.find(item => String(item.id) === String(voter.department))?.code || `Department #${voter.department}`) : "Not assigned";
                return <tr key={voter.id}>
                  <td><div className="voter-name-cell"><span className={`voter-avatar avatar-${voter.id % 6}`}>{initials}</span><strong>{String(voter.name || "").toLowerCase().replace(/\b\w/g, char => char.toUpperCase())}</strong></div></td>
                  <td>{voter.identifier}</td>
                  <td>{voter.email}</td>
                  <td><span className={`voter-category-pill ${voter.category}`}>{voter.category}</span></td>
                  <td>{department}</td>
                  <td><span className={`voter-status-pill ${voter.status}`}><span />{voter.status}</span></td>
                  <td><span className="created-date"><CalendarIcon />{new Date(voter.created_date).toLocaleString()}</span></td>
                  <td><div className="voter-action-buttons">
                    <button className="voter-action edit" title="Edit voter" aria-label={`Edit ${voter.name}`} onClick={() => setEditing(voter)}><EditIcon /></button>
                    <button className="voter-action reset" title="Reset password" aria-label={`Reset password for ${voter.name}`} onClick={() => setResetting(voter)}><ResetIcon /></button>
                    <button className={`voter-action ${voter.status === "active" ? "delete" : "activate"}`} title={voter.status === "active" ? "Deactivate voter" : "Activate voter"} aria-label={`${voter.status === "active" ? "Deactivate" : "Activate"} ${voter.name}`} onClick={() => toggleStatus(voter)}>{voter.status === "active" ? <TrashIcon /> : <CheckIcon />}</button>
                  </div></td>
                </tr>;
              })}
            </tbody>
          </table>
        </div>}
        {!loading && voters.length > 0 && <div className="voter-table-footer">
          <div className="rows-per-page">Rows per page: <select value={rowsPerPage} disabled><option>10</option></select></div>
          <div className="voter-pagination">
            <button disabled={page === 1} onClick={() => setPage(current => Math.max(1, current - 1))} aria-label="Previous page">‹</button>
            {Array.from({length: pageCount}, (_, index) => index + 1).slice(0, 5).map(number => <button key={number} className={number === page ? "current" : ""} onClick={() => setPage(number)}>{number}</button>)}
            <button disabled={page === pageCount} onClick={() => setPage(current => Math.min(pageCount, current + 1))} aria-label="Next page">›</button>
          </div>
        </div>}
      </section>
    </main>


    {creating && <VoterForm departments={departments} onClose={() => setCreating(false)} onSaved={handleSaved} />}
    {editing && <VoterForm voter={editing} departments={departments} onClose={() => setEditing(null)} onSaved={handleSaved} />}
    {resetting && <PasswordResetModal voter={resetting} onClose={() => setResetting(null)} onSaved={handleSaved} />}
  </div>;
}
