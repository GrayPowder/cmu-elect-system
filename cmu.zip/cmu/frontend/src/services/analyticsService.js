import {api} from "./api";

function withDate(path, selectedDate) {
  return selectedDate ? `${path}?date=${encodeURIComponent(selectedDate)}` : path;
}

export function getVoterAnalytics(electionId, selectedDate) {
  return api(withDate(`/elections/${electionId}/analytics/`, selectedDate));
}

export function getAdminAnalytics(electionId, selectedDate) {
  return api(withDate(`/admin/elections/${electionId}/analytics/`, selectedDate));
}
