import {getToken} from "../context/authStorage";

const API = (
  import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000/api"
).replace(/\/$/, "");

const BACKEND_ORIGIN = API.replace(/\/api$/, "");

function getWebSocketUrl(electionId) {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const token = getToken();

  if (!token) return null;

  return `${protocol}//${new URL(BACKEND_ORIGIN).host}/ws/analytics/${electionId}/?token=${encodeURIComponent(token)}`;
}

export function createAnalyticsSocket(electionId, {onUpdate, onStatus, onError} = {}) {
  let socket = null;
  let stopped = false;
  let reconnectTimer = null;
  let reconnectAttempt = 0;

  function connect() {
    if (stopped) return;

    const url = getWebSocketUrl(electionId);
    if (!url) {
      onStatus?.("unauthenticated");
      return;
    }

    onStatus?.("connecting");
    socket = new WebSocket(url);

    socket.onopen = () => {
      reconnectAttempt = 0;
      onStatus?.("connected");
    };

    socket.onmessage = event => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === "analytics_update") {
          onUpdate?.(message);
        }
      } catch (_) {
        // Ignore malformed WebSocket messages without breaking the connection.
      }
    };

    socket.onerror = event => {
      onError?.(event);
    };

    socket.onclose = () => {
      socket = null;
      if (stopped) return;

      onStatus?.("reconnecting");
      const delay = Math.min(1000 * 2 ** reconnectAttempt, 10000);
      reconnectAttempt += 1;
      reconnectTimer = window.setTimeout(connect, delay);
    };
  }

  connect();

  return {
    close() {
      stopped = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      if (socket) socket.close(1000, "Analytics page closed");
      socket = null;
    },
  };
}
