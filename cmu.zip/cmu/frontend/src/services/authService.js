import {api} from "./api";

export function login({email, password}) {
  return api("/auth/login/", {
    method: "POST",
    body: JSON.stringify({email: email.trim(), password}),
  });
}

export function logout({keepalive = false} = {}) {
  return api("/auth/logout/", {method: "POST", keepalive});
}

export function getCurrentUser() {
  return api("/auth/me/");
}

export function changePassword({current_password, new_password, confirm_password}) {
  return api("/auth/change-password/", {
    method: "POST",
    body: JSON.stringify({current_password, new_password, confirm_password}),
  });
}

export function requestPasswordReset(email) {
  return api("/auth/forgot-password/", {
    method: "POST",
    body: JSON.stringify({email: email.trim()}),
  });
}

export function verifyResetCode({email, code}) {
  return api("/auth/verify-code/", {
    method: "POST",
    body: JSON.stringify({email: email.trim(), code}),
  });
}

export function resendResetCode(email) {
  return api("/auth/resend-code/", {
    method: "POST",
    body: JSON.stringify({email: email.trim()}),
  });
}

export function resetPassword({email, reset_token, password, confirm_password}) {
  return api("/auth/reset-password/", {
    method: "POST",
    body: JSON.stringify({email, reset_token, password, confirm_password}),
  });
}

