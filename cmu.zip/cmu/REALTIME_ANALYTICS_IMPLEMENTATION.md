# CMU-ELECT Real-Time Analytics

The analytics pages now use WebSockets instead of 2-second polling.

## What changed

### Backend
- Added `config/asgi.py` for HTTP + WebSocket routing.
- Added `elections/middleware.py` to authenticate WebSocket connections using the existing DRF token.
- Secured `AnalyticsConsumer` so only active administrators or eligible active voters can subscribe to an election.
- Added a single analytics broadcast after a successful ballot transaction commits.
- Added Daphne to `backend/requirements.txt` for ASGI serving.

### Frontend
- Added `src/services/analyticsSocket.js`.
- Voter Analytics loads once through the existing REST API and refreshes only when a WebSocket event arrives.
- Admin Analytics does the same.
- Automatic WebSocket reconnection is included.
- The old 2-second `setTimeout`/`setInterval` polling was removed.

## Run

From `backend`:

```powershell
pip install -r requirements.txt
daphne -p 8000 config.asgi:application
```

From `frontend`:

```powershell
npm install
npm run dev
```

## Test

1. Log in as an eligible voter in one browser window.
2. Open that election's Analytics page.
3. Log in as an administrator in another browser/incognito window.
4. Open Admin Analytics and select the same election.
5. Submit a valid ballot from the voter window.
6. The analytics pages should refresh immediately after the successful vote transaction, without waiting for a 2-second polling interval.
7. The `Last update` time should change and the charts should update.

The WebSocket sends only an `analytics_update` notification. The existing analytics REST API remains the source of the actual aggregate numbers, so analytics calculation logic is not duplicated.

## Production note

The current project uses Django Channels' in-memory channel layer for development. For multiple production workers/instances, replace it with Redis. Use HTTPS/WSS in production.
